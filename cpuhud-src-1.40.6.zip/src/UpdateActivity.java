package com.dsh.cpuhud;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/**
 * 更新与安装。
 *
 * 两条路：
 *  1) 本地安装：直接把手机里的 APK（默认 /sdcard/dsh/cpuhud/cpuhud.apk）交给系统安装器
 *  2) 联网更新：查 version.json → 下载 → 校验 → 安装
 *
 * 都用 PackageInstaller，不需要 FileProvider、不需要 root / Shizuku，
 * 但需要系统「安装未知应用」权限（用户一次性授权）。
 */
public class UpdateActivity extends Activity {

    private static final String DEFAULT_APK = "/sdcard/dsh/cpuhud/cpuhud.apk";
    private static final int REQ_PICK = 3001;

    private TextView status, localInfo;
    private int themeSig;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        Theme.load(this);
        themeSig = Theme.sig();

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(28));

        root.addView(text("更新与安装", 24f, Theme.strong(), true));
        root.addView(text("安装 ADB 风格不需要电脑：直接读手机里的 APK 交给系统安装器。"
                + "第一次会要求「允许安装未知应用」，之后就只是点两下。", 11f, Theme.dim2(), false));

        status = text("", 12f, Theme.dim(), true);
        root.addView(status);

        // ---- 本地安装 ----
        root.addView(header("本地安装"));
        root.addView(text("默认读取：" + DEFAULT_APK, 10.5f, Theme.dim2(), false));
        localInfo = text("", 12f, Theme.text(), true);
        root.addView(localInfo);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button inst = wideBtn("安装这个 APK", new View.OnClickListener() {
            @Override public void onClick(View v) { installLocal(new File(DEFAULT_APK)); }
        });
        Button pick = wideBtn("选其他 APK", new View.OnClickListener() {
            @Override public void onClick(View v) { pickFile(); }
        });
        row1.addView(inst);
        row1.addView(pick);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(8);
        root.addView(row1, rp);

        Button perm = wideBtn("检查「安装未知应用」权限", new View.OnClickListener() {
            @Override public void onClick(View v) { checkInstallPerm(true); }
        });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42));
        pp.topMargin = dp(6);
        root.addView(perm, pp);

        // ---- 联网更新 ----
        root.addView(header("联网更新"));
        root.addView(text("检查远端 version.json，有新版就下载并安装。下载过程会在悬浮窗里显示进度。",
                10.5f, Theme.dim2(), false));
        Button check = wideBtn("检查更新", new View.OnClickListener() {
            @Override public void onClick(View v) { doCheck(); }
        });
        check.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { editJsonUrl(); return true; }
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        cp.topMargin = dp(6);
        root.addView(check, cp);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = wideBtn("恢复默认地址", new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences("hud", MODE_PRIVATE).edit().remove("update.url").apply();
                setStatus("已恢复默认地址（GitHub/jsDelivr）");
            }
        });
        Button showUrl = wideBtn("查看当前地址", new View.OnClickListener() {
            @Override public void onClick(View v) { setStatus("清单地址：" + jsonUrl()); }
        });
        row2.addView(reset);
        row2.addView(showUrl);
        LinearLayout.LayoutParams rp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp2.topMargin = dp(6);
        root.addView(row2, rp2);

        Button back = wideBtn("返回", new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        bp.topMargin = dp(20);
        root.addView(back, bp);

        root.addView(text("· 安装会话由系统管理，安装结果会 Toast 提示\n"
                + "· 签名必须与已装版本一致才能覆盖安装（我们用同一个签名）", 10.5f, Theme.dim2(), false));

        sc.addView(root);
        setContentView(sc);
        refreshLocal();
        updateStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); return; }
        refreshLocal();
        updateStatus();
    }

    // ---------------------------------------------------------------- 状态

    private String ver() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pi.versionName + " (" + pi.versionCode + ")";
        } catch (Throwable t) {
            return "?";
        }
    }

    /** 试读一个字节，判断 App 有没有权限直接读这个文件。 */
    private static boolean readable(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            in.read();
            in.close();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 页面上的最后一步结果，方便定位问题。 */
    private void setStatus(String s) {
        if (status == null) return;
        status.setText(s + "\n当前版本 " + ver());
        status.setTextColor(Theme.accent());
        android.util.Log.i("CPUHUD", "update: " + s);
    }

    private void updateStatus() {
        boolean ok = canInstall();
        status.setText("当前版本 " + ver() + (ok ? "" : "   ·   未授权安装未知应用"));
        status.setTextColor(ok ? Theme.good() : Theme.warn());
    }

    private boolean canInstall() {
        if (Build.VERSION.SDK_INT >= 26) {
            try { return getPackageManager().canRequestPackageInstalls(); } catch (Throwable t) { return true; }
        }
        return true;
    }

    private void refreshLocal() {
        File f = new File(DEFAULT_APK);
        if (!f.exists() || !readable(f)) {
            localInfo.setText(f.exists()
                    ? "文件在，但 App 读不到（分区存储限制）→ 点「安装这个 APK」会打开文件选择器"
                    : "没找到文件（还没构建过？）");
            localInfo.setTextColor(Theme.warn());
            return;
        }
        String info = size(f.length());
        try {
            PackageManager pm = getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (pi != null) {
                info += "  ·  " + pi.versionName + " (" + pi.versionCode + ")"
                        + (pi.packageName.equals(getPackageName()) ? "" : "  ·  包名 " + pi.packageName);
            }
        } catch (Throwable ignored) { }
        localInfo.setText(info);
        localInfo.setTextColor(Theme.text());
    }

    private static String size(long b) {
        if (b > 1024 * 1024) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%d KB", Math.max(1, b / 1024));
    }

    // ---------------------------------------------------------------- 联网更新

    /** 长按「检查更新」→ 改 version.json 地址（自建服务器 / 自己的仓库都能用）。 */
    private void editJsonUrl() {
        final android.widget.EditText et = new android.widget.EditText(this);
        et.setText(jsonUrl());
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        et.setSingleLine(false);
        new android.app.AlertDialog.Builder(this)
                .setTitle("版本清单地址")
                .setMessage("默认：" + UpdateChecker.DEFAULT_JSON)
                .setView(et)
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String u = et.getText().toString().trim();
                        getSharedPreferences("hud", MODE_PRIVATE).edit()
                                .putString("update.url", u.isEmpty() ? UpdateChecker.DEFAULT_JSON : u).apply();
                        setStatus("版本清单地址已保存");
                    }
                })
                .setNeutralButton("恢复默认", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        getSharedPreferences("hud", MODE_PRIVATE).edit()
                                .remove("update.url").apply();
                        setStatus("已恢复默认地址");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String jsonUrl() {
        String u = getSharedPreferences("hud", MODE_PRIVATE).getString("update.url", "");
        return u == null || u.trim().isEmpty() ? UpdateChecker.DEFAULT_JSON : u.trim();
    }

    private void doCheck() {
        setStatus("正在检查更新…");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final UpdateChecker.Info info =
                            UpdateChecker.check(UpdateActivity.this, jsonUrl(), true);
                    final int cur = curCode();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (info.versionCode <= cur) {
                                setStatus("已是最新版本（远端 " + info.versionName + "）");
                                Toast.makeText(UpdateActivity.this, "已是最新版本", Toast.LENGTH_SHORT).show();
                            } else {
                                setStatus("发现新版本 " + info.versionName + "：点「下载并安装」");
                                askDownload(info);
                            }
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            setStatus("检查更新失败：" + e.getMessage()
                                    + "（需要先把 version.json 传到仓库）");
                        }
                    });
                }
            }
        }).start();
    }

    private int curCode() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; }
        catch (Throwable t) { return 0; }
    }

    private void askDownload(final UpdateChecker.Info info) {
        new android.app.AlertDialog.Builder(this)
                .setTitle("发现新版本 " + info.versionName)
                .setMessage((info.notes.isEmpty() ? "" : info.notes + "\n\n") + "要现在下载并安装吗？")
                .setPositiveButton("下载并安装", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { doDownload(info); }
                })
                .setNegativeButton("稍后", null)
                .show();
    }

    /** 下载走进度悬浮窗，下载完点悬浮窗安装。 */
    private void doDownload(final UpdateChecker.Info info) {
        final UpdateOverlay ov = new UpdateOverlay(this);
        ov.progress("准备下载更新", info.versionName, -1);
        setStatus("正在下载 " + info.versionName + "…");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final File f = UpdateChecker.download(UpdateActivity.this, info,
                            new UpdateChecker.Progress() {
                                @Override public void onProgress(final int pct, final long done, final long total) {
                                    runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            ov.progress("正在下载更新 " + pct + "%",
                                                    size(done) + " / " + size(total), pct);
                                        }
                                    });
                                }
                            });
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            setStatus("下载完成（" + size(f.length()) + "），点悬浮窗或下面的按钮安装");
                            ov.ready("更新就绪 · 点此安装", info.versionName + " · " + size(f.length()),
                                    new Runnable() {
                                        @Override public void run() {
                                            ov.hide();
                                            installLocal(f);
                                        }
                                    });
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            setStatus("下载失败：" + e.getMessage());
                            ov.error(e.getMessage());
                        }
                    });
                }
            }
        }).start();
    }

    // ---------------------------------------------------------------- 安装

    private void checkInstallPerm(boolean jump) {
        if (canInstall()) {
            Toast.makeText(this, "已授权安装未知应用", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!jump) return;
        try {
            Intent i = new Intent(Build.VERSION.SDK_INT >= 26
                    ? Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                    : Settings.ACTION_SECURITY_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "打开「允许安装未知应用」后返回本页", Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "打不开设置：" + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void pickFile() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            Toast.makeText(this, "打不开文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            try {
                File dst = new File(getFilesDir(), "picked.apk");
                InputStream in = getContentResolver().openInputStream(data.getData());
                FileOutputStream out = new FileOutputStream(dst);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
                installLocal(dst);
            } catch (Throwable t) {
                Toast.makeText(this, "读取失败：" + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    /** 用 PackageInstaller 建会话并把 APK 写进去。每一步都写状态，失败能看清断在哪。 */
    private void installLocal(File apk) {
        if (apk == null || !apk.exists()) {
            setStatus("失败：找不到 APK（" + (apk == null ? "?" : apk.getAbsolutePath()) + "）");
            return;
        }
        if (!canInstall()) {
            setStatus("失败：还没有「安装未知应用」权限");
            checkInstallPerm(true);
            return;
        }
        String step = "1/5 读取 APK 信息";
        try {
            setStatus(step);
            // /sdcard 下的文件受分区存储限制，App 通常没有直接读权限 → 读不到就让用户从文件选择器挑
            if (!readable(apk)) {
                setStatus("读不到这个文件（系统存储权限限制），请在弹出的选择器里选它");
                pickFile();
                return;
            }
            PackageManager pm = getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), 0);
            if (pi == null) { setStatus("失败：这个文件不是有效的 APK"); return; }

            step = "2/5 创建安装会话";
            setStatus(step);
            PackageInstaller installer = pm.getPackageInstaller();
            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            params.setAppPackageName(pi.packageName);
            int sessionId = installer.createSession(params);
            setStatus("2/5 会话 #" + sessionId + " 已创建");

            step = "3/5 写入 APK";
            PackageInstaller.Session session = installer.openSession(sessionId);
            FileInputStream in = new FileInputStream(apk);
            OutputStream out = session.openWrite("base.apk", 0, apk.length());
            byte[] buf = new byte[16384];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); total += n; }
            session.fsync(out);
            in.close();
            out.close();
            setStatus("3/5 已写入 " + size(total));

            step = "4/5 提交会话";
            Intent cb = new Intent(this, InstallReceiver.class);
            PendingIntent pi2 = PendingIntent.getBroadcast(this, sessionId, cb,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            session.commit(pi2.getIntentSender());
            session.close();

            step = "5/5 等系统安装器";
            setStatus("已提交安装会话（" + size(total) + "），等系统安装器确认");
        } catch (Throwable t) {
            setStatus("失败于「" + step + "」：" + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    // ---------------------------------------------------------------- UI 小工具

    private TextView header(String s) {
        TextView v = text(s, 15f, Theme.good(), true);
        v.setPadding(0, dp(20), 0, dp(4));
        return v;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(3), 0, dp(3));
        return v;
    }

    private Button wideBtn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTextColor(Theme.text());
        b.setPadding(dp(6), 0, dp(6), 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }
}
