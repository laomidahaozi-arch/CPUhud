package com.dsh.cpuhud;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** 设备自检入口：屏幕 / 触摸 / 扬声器 / 马达 / 传感器 / 刷新率。 */
public class SelfTestActivity extends Activity {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private int themeSig;
    private LinearLayout body;
    private final java.util.Map<String, TextView> statusViews = new java.util.HashMap<>();

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        prefs = getSharedPreferences("selftest", MODE_PRIVATE);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(24), dp(18), dp(28));
        sc.addView(body);
        setContentView(sc);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); return; }
        refreshStatus();
    }

    private void build() {
        body.addView(text("设备自检", 24f, Theme.strong(), true));
        body.addView(text("能自动判的给结论；坏点、破音这种只能人眼人耳确认，你自己选「正常 / 有异常」。结果会记下来。",
                11f, Theme.dim2(), false));

        item("screen", "屏幕", "纯色 / 灰阶 / 渐变 / 色块，查坏点、漏光、色带", new Runnable() {
            @Override public void run() { startActivity(new Intent(SelfTestActivity.this, ScreenTestActivity.class)); }
        });

        item("touch", "触摸", "网格划一遍看覆盖率，多指同时按看最大触点数", new Runnable() {
            @Override public void run() { startActivity(new Intent(SelfTestActivity.this, TouchTestActivity.class)); }
        });

        item("speaker", "扬声器", "左 / 右 / 立体声 / 扫频，听单边无声和破音", new Runnable() {
            @Override public void run() { startActivity(new Intent(SelfTestActivity.this, SpeakerTestActivity.class)); }
        });

        item("sensor", "传感器", "加速度 / 陀螺 / 磁力 / 光线 / 距离实时读数 + 摇一摇", new Runnable() {
            @Override public void run() { startActivity(new Intent(SelfTestActivity.this, SensorTestActivity.class)); }
        });

        // 马达：就地测
        LinearLayout motorCard = card("马达", "点「震动一下」：应该有明显震感；支持力度控制的机型会先轻后重");
        LinearLayout mrow = new LinearLayout(this);
        mrow.setOrientation(LinearLayout.HORIZONTAL);
        Button vib = wideBtn("震动一下");
        vib.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doVibrate(); }
        });
        Button mok = wideBtn("正常");
        mok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save("vibrate", "pass", "震感明显" + ampNote()); }
        });
        Button mbad = wideBtn("异常");
        mbad.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save("vibrate", "fail", "无震感 / 震感异常"); }
        });
        mrow.addView(vib);
        mrow.addView(mok);
        mrow.addView(mbad);
        motorCard.addView(mrow);
        body.addView(motorCard);

        // 刷新率：就地测
        LinearLayout rCard = card("刷新率", "点「测 3 秒」：用 Choreographer 真实计帧，和系统当前档位对比");
        LinearLayout rrow = new LinearLayout(this);
        rrow.setOrientation(LinearLayout.HORIZONTAL);
        Button meas = wideBtn("测 3 秒");
        meas.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { measureRefresh((Button) v); }
        });
        Button rok = wideBtn("正常");
        rok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save("refresh", "pass", "实测帧率与设定档位一致"); }
        });
        rrow.addView(meas);
        rrow.addView(rok);
        rCard.addView(rrow);
        final TextView rres = text("", 11.5f, Theme.dim(), true);
        rCard.addView(rres);
        refreshTag.put("refresh_result", rres);
        body.addView(rCard);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = wideBtn("清空记录");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().clear().apply();
                refreshStatus();
                Toast.makeText(SelfTestActivity.this, "已清空", Toast.LENGTH_SHORT).show();
            }
        });
        Button back = wideBtn("返回");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        row.addView(reset);
        row.addView(back);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(20);
        body.addView(row, rp);

        body.addView(text("· 屏幕测试会全屏，返回键结束\n"
                + "· 扬声器测试会临时把媒体音量调到 70%，退出时还原\n"
                + "· 这里不申请麦克风权限，闭环频响（P2）再单独要", 10.5f, Theme.dim2(), false));
        refreshStatus();
    }

    private final java.util.Map<String, TextView> refreshTag = new java.util.HashMap<>();

    private void item(final String key, String title, String desc, final Runnable action) {
        LinearLayout c = card(title, desc);
        Button go = wideBtn("开始");
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42));
        lp.topMargin = dp(6);
        c.addView(go, lp);
        body.addView(c);
    }

    private LinearLayout card(String title, String desc) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card2());
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Theme.card());
        c.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        c.setLayoutParams(p);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 14f, Theme.strong(), true);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView st = text("未测", 11f, Theme.dim2(), false);
        head.addView(st);
        c.addView(head);
        c.addView(text(desc, 10.5f, Theme.dim2(), false));
        return c;
    }

    private void refreshStatus() {
        int i = 0;
        for (int idx = 0; idx < body.getChildCount(); idx++) {
            View v = body.getChildAt(idx);
            if (!(v instanceof LinearLayout)) continue;
            LinearLayout card = (LinearLayout) v;
            if (card.getChildCount() < 1) continue;
            View h = card.getChildAt(0);
            if (!(h instanceof LinearLayout)) continue;
            LinearLayout head = (LinearLayout) h;
            if (head.getChildCount() < 2) continue;
            TextView title = (TextView) head.getChildAt(0);
            TextView st = (TextView) head.getChildAt(1);
            String key = keyFor(title.getText().toString());
            if (key == null) continue;
            String val = prefs.getString(key, "");
            String note = prefs.getString(key + "_note", "");
            if ("pass".equals(val)) {
                st.setText("✔ 正常" + (note.isEmpty() ? "" : " · " + note));
                st.setTextColor(Theme.good());
            } else if ("fail".equals(val)) {
                st.setText("✖ 异常" + (note.isEmpty() ? "" : " · " + note));
                st.setTextColor(Theme.bad());
            } else if ("warn".equals(val)) {
                st.setText("⚠ " + (note.isEmpty() ? "待确认" : note));
                st.setTextColor(Theme.warn());
            } else {
                st.setText("未测");
                st.setTextColor(Theme.dim2());
            }
        }
    }

    private String keyFor(String title) {
        if ("屏幕".equals(title)) return "screen";
        if ("触摸".equals(title)) return "touch";
        if ("扬声器".equals(title)) return "speaker";
        if ("频响 / 失真".equals(title)) return "audio";
        if ("传感器".equals(title)) return "sensor";
        if ("马达".equals(title)) return "vibrate";
        if ("刷新率".equals(title)) return "refresh";
        return null;
    }

    private void save(String key, String val, String note) {
        prefs.edit().putString(key, val).putString(key + "_note", note)
                .putLong(key + "_ts", System.currentTimeMillis()).apply();
        refreshStatus();
        Toast.makeText(this, "已记录：" + ("pass".equals(val) ? "正常" : "异常"), Toast.LENGTH_SHORT).show();
    }

    private static String ampNote() {
        return "";
    }

    private void doVibrate() {
        try {
            Vibrator vib;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                vib = vm.getDefaultVibrator();
            } else {
                vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            }
            if (vib == null || !vib.hasVibrator()) {
                Toast.makeText(this, "这台设备没有振动马达", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean amp = ampSupported(vib);
            if (amp) {
                long[] timings = {0, 80, 120, 160, 120, 240};
                int[] amps = {0, 60, 0, 120, 0, 255};
                vib.vibrate(VibrationEffect.createWaveform(timings, amps, -1));
            } else {
                vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 100, 220}, -1));
            }
            Toast.makeText(this, "震动中" + (amp ? "（支持力度控制）" : "（不支持力度控制）"), Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "振动失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean ampSupported(Vibrator v) {
        try { return Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl(); } catch (Throwable t) { return false; }
    }

    private void measureRefresh(final Button btn) {
        btn.setEnabled(false);
        btn.setText("测量中…");
        final long start = System.nanoTime();
        final int[] frames = {0};
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            final Choreographer.FrameCallback self = this;
            @Override public void doFrame(long t) {
                frames[0]++;
                long elapsed = System.nanoTime() - start;
                if (elapsed < 3_000_000_000L) {
                    Choreographer.getInstance().postFrameCallback(self);
                } else {
                    double fps = frames[0] * 1_000_000_000.0 / elapsed;
                    float set = getWindowManager().getDefaultDisplay().getRefreshRate();
                    TextView res = refreshTag.get("refresh_result");
                    String txt = String.format(Locale.US, "实测 %.1f Hz  ·  系统档位 %.0f Hz", fps, set);
                    if (res != null) {
                        res.setText(txt);
                        res.setTextColor(Math.abs(fps - set) <= Math.max(3, set * 0.06) ? Theme.good() : Theme.warn());
                    }
                    btn.setEnabled(true);
                    btn.setText("再测一次");
                    if (Math.abs(fps - set) <= Math.max(3, set * 0.06)) {
                        save("refresh", "pass", String.format(Locale.US, "实测 %.0fHz / 档位 %.0fHz", fps, set));
                    }
                }
            }
        });
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(3), 0, dp(3));
        return v;
    }

    private Button wideBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        b.setTextColor(Theme.text());
        b.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }
}
