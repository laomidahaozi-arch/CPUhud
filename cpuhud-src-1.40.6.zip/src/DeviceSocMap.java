package com.dsh.cpuhud;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

/**
 * 机型 → 处理器 的「已核实」对照表。
 *
 * 为什么需要它：像 MT6878 这种基础码被 7300 / 7300-Ultra / 7400 / 7400-Ultra 共用，
 * 光看型号码和主频分不出到底是哪一颗；只有「机型码/代号」能唯一确定。
 * 这张表的条目都必须对着官方规格页核对过，因此优先级最高。
 */
public final class DeviceSocMap {

    public static final class Hit {
        public String device = "";
        public String soc = "";
        public String source = "";
        public String key = "";
    }

    private static JSONObject cache;

    private DeviceSocMap() { }

    public static Hit lookup(Context c, String... keys) {
        if (c == null || keys == null) return null;
        JSONObject root = load(c);
        if (root == null) return null;
        JSONObject entries = root.optJSONObject("entries");
        if (entries == null) return null;
        for (String k : keys) {
            if (k == null || k.trim().isEmpty()) continue;
            String key = k.trim().toUpperCase(Locale.US);
            JSONObject o = entries.optJSONObject(key);
            if (o == null) continue;
            Hit h = new Hit();
            h.key = key;
            h.device = o.optString("device", "");
            h.soc = o.optString("soc", "");
            h.source = o.optString("source", "");
            if (!h.soc.isEmpty()) return h;
        }
        return null;
    }

    private static synchronized JSONObject load(Context c) {
        if (cache != null) return cache;
        try {
            InputStream in = c.getAssets().open("device_soc.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            cache = new JSONObject(bo.toString("UTF-8"));
        } catch (Throwable t) {
            cache = null;
        }
        return cache;
    }
}
