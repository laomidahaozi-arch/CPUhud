package com.dsh.cpuhud;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** 传感器自检：加速度 / 陀螺仪 / 磁力 / 光线 / 距离 实时读数，摇一摇看加速度变化。 */
public class SensorTestActivity extends Activity implements SensorEventListener {

    private SensorManager sm;
    private TextView rowAcc, rowGyro, rowMag, rowLight, rowProx, shake;
    private boolean shakeDetected = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));

        TextView t = new TextView(this);
        t.setText("传感器自检");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f);
        t.setTextColor(Theme.strong());
        root.addView(t);
        root.addView(small("数值应当随手机姿态变化；摇一摇手机，看「摇一摇」那一行有没有变成已检测。"));

        rowAcc = addRow(root, "加速度", "—");
        rowGyro = addRow(root, "陀螺仪", "—");
        rowMag = addRow(root, "磁力", "—");
        rowLight = addRow(root, "光线", "—");
        rowProx = addRow(root, "距离", "—");
        shake = addRow(root, "摇一摇", "未检测（摇一下手机）");

        LinearLayout judge = new LinearLayout(this);
        judge.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams jp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        jp.topMargin = dp(24);
        judge.setLayoutParams(jp);
        Button ok = wideBtn("都正常");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { done("pass", "各传感器均有数据且随姿态变化"); }
        });
        Button bad = wideBtn("有异常");
        bad.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { done("fail", "某个传感器无数值 / 数值不动"); }
        });
        judge.addView(ok);
        judge.addView(bad);
        root.addView(judge);

        Button back = wideBtn("返回");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        bp.topMargin = dp(8);
        root.addView(back, bp);

        sc.addView(root);
        setContentView(sc);
    }

    private TextView addRow(LinearLayout parent, String label, String value) {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setPadding(0, dp(5), 0, dp(5));
        TextView k = new TextView(this);
        k.setText(label);
        k.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        k.setTextColor(Theme.dim2());
        k.setWidth(dp(76));
        line.addView(k);
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        v.setTypeface(Typeface.MONOSPACE);
        v.setTextColor(Theme.text());
        line.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        parent.addView(line);
        return v;
    }

    private TextView small(String s) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        v.setTextColor(Theme.dim2());
        v.setPadding(0, dp(6), 0, dp(10));
        return v;
    }

    @Override protected void onResume() {
        super.onResume();
        register(Sensor.TYPE_ACCELEROMETER);
        register(Sensor.TYPE_GYROSCOPE);
        register(Sensor.TYPE_MAGNETIC_FIELD);
        register(Sensor.TYPE_LIGHT);
        register(Sensor.TYPE_PROXIMITY);
    }

    private void register(int type) {
        try {
            Sensor s = sm.getDefaultSensor(type);
            if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
        } catch (Throwable ignored) { }
    }

    @Override protected void onPause() {
        super.onPause();
        try { sm.unregisterListener(this); } catch (Throwable ignored) { }
    }

    @Override public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER: {
                double mag = Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
                rowAcc.setText(String.format(Locale.US, "x %.2f  y %.2f  z %.2f   |a| %.2f m/s²",
                        e.values[0], e.values[1], e.values[2], mag));
                if (!shakeDetected && mag > 22) {
                    shakeDetected = true;
                    shake.setText("已检测 ● 摇动幅度 " + String.format(Locale.US, "%.1f m/s²", mag));
                    shake.setTextColor(Theme.good());
                }
                break;
            }
            case Sensor.TYPE_GYROSCOPE:
                rowGyro.setText(String.format(Locale.US, "x %.3f  y %.3f  z %.3f rad/s",
                        e.values[0], e.values[1], e.values[2]));
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                rowMag.setText(String.format(Locale.US, "x %.1f  y %.1f  z %.1f µT",
                        e.values[0], e.values[1], e.values[2]));
                break;
            case Sensor.TYPE_LIGHT:
                rowLight.setText(String.format(Locale.US, "%.1f lux", e.values[0]));
                break;
            case Sensor.TYPE_PROXIMITY:
                rowProx.setText(String.format(Locale.US, "%.1f cm", e.values[0]));
                break;
        }
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    private void done(String result, String note) {
        SharedPreferences p = getSharedPreferences("selftest", MODE_PRIVATE);
        p.edit().putString("sensor", result).putString("sensor_note", note)
                .putLong("sensor_ts", System.currentTimeMillis()).apply();
        Toast.makeText(this, "已记录", Toast.LENGTH_SHORT).show();
        finish();
    }

    private Button wideBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTextColor(Theme.text());
        b.setPadding(0, 0, 0, 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(46), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
