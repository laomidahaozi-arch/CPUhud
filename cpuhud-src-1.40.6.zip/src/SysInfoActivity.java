package com.dsh.cpuhud;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 系统信息（脱敏）：只放排查需要的字段，不含任何标识符。 */
public class SysInfoActivity extends Activity {
    private TextView body;
    private Button refresh;

    private String pkg = "";

    private void exportDiag() {
        android.widget.Toast.makeText(this, "正在导出（约 10 秒）…", android.widget.Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                String fg = pkg;
                try {
                    Snapshot snap = DataSource.fetch();
                    if (snap != null && snap.pkg != null && !snap.pkg.isEmpty()) fg = snap.pkg;
                } catch (Throwable ignored) { }
                String text = DiagExport.build(SysInfoActivity.this, fg);
                final String name = "cpuhud-diag-" + System.currentTimeMillis() + ".txt";
                String where = null;
                // 1) 首选 MediaStore → 下载目录（Android 10+ 免权限）
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    try {
                        android.content.ContentValues cv = new android.content.ContentValues();
                        cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                        cv.put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain");
                        cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,
                                android.os.Environment.DIRECTORY_DOWNLOADS);
                        android.net.Uri uri = getContentResolver()
                                .insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        if (uri != null) {
                            try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                                if (out != null) { out.write(text.getBytes("UTF-8")); where = "下载/" + name; }
                            }
                        }
                    } catch (Throwable ignored) { }
                }
                // 2) 回落：应用专属外部目录（不需要任何权限）
                if (where == null) {
                    try {
                        java.io.File dir = getExternalFilesDir(null);
                        if (dir == null) dir = getFilesDir();
                        java.io.File f = new java.io.File(dir, name);
                        try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
                            out.write(text.getBytes("UTF-8"));
                            where = f.getAbsolutePath();
                        }
                    } catch (Throwable ignored) { }
                }
                final String path = where;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        android.widget.Toast.makeText(SysInfoActivity.this,
                                path == null ? "导出失败：无可用写入位置（可用「联网获取」页面里的日志代替）"
                                             : "已导出到：" + path,
                                android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int themeSig;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(28));

        TextView t = new TextView(this);
        t.setText("系统信息（已脱敏）");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
        t.setTextColor(Theme.good());
        root.addView(t);

        TextView sub = new TextView(this);
        sub.setText("不含 IMEI / 序列号 / MAC / 账号 / 位置 / 已安装应用 —— 只有硬件与版本信息，方便排查");
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        sub.setTextColor(Theme.dim2());
        sub.setPadding(0, dp(4), 0, dp(10));
        root.addView(sub);

        body = new TextView(this);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        body.setTextColor(Theme.text());
        body.setTypeface(android.graphics.Typeface.MONOSPACE);
        body.setLineSpacing(dp(4), 1f);
        body.setText("读取中…");
        root.addView(body);

        refresh = new Button(this);
        refresh.setText("重新读取");
        refresh.setAllCaps(false);
        refresh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        refresh.setTextColor(Theme.text());
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(12));
        refresh.setBackground(bg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        bp.topMargin = dp(16);
        root.addView(refresh, bp);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { load(); }
        });

        Button diagBtn = new Button(this);
        diagBtn.setText("导出适配诊断（换机适配用）");
        diagBtn.setAllCaps(false);
        diagBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        diagBtn.setTextColor(Theme.accent());
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(Theme.card2());
        dbg.setCornerRadius(dp(12));
        diagBtn.setBackground(dbg);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        dlp.topMargin = dp(16);
        diagBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { exportDiag(); }
        });
        root.addView(diagBtn, dlp);

        // 映射表：拉取 / 设置地址（只读 GET，不上传任何东西）
        Button mapBtn = new Button(this);
        mapBtn.setText("芯片映射表：同步 / 设置地址");
        mapBtn.setAllCaps(false);
        mapBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        mapBtn.setTextColor(Theme.accent());
        GradientDrawable mbg = new GradientDrawable();
        mbg.setColor(Theme.card2());
        mbg.setCornerRadius(dp(12));
        mapBtn.setBackground(mbg);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        mlp.topMargin = dp(10);
        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { mapDialog(); }
        });
        root.addView(mapBtn, mlp);

        Button issueBtn = new Button(this);
        issueBtn.setText("提交新机型（发 GitHub Issue）");
        issueBtn.setAllCaps(false);
        issueBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        issueBtn.setTextColor(Theme.good());
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(Theme.card2());
        ibg.setCornerRadius(dp(12));
        issueBtn.setBackground(ibg);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        ilp.topMargin = dp(10);
        issueBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { submitModel(); }
        });
        root.addView(issueBtn, ilp);

        sc.addView(root);
        setContentView(sc);
        load();
    }

    /**
     * 把当前识别结果塞进 GitHub Issue 的标题和正文，用户点一下就发出。
     * 仓库地址从已配置的映射表 URL 里反推，不写死。
     */
    private void submitModel() {
        String slug = SocMap.repoSlug(this);
        if (slug.isEmpty()) {
            android.widget.Toast.makeText(this, "先设置映射表地址，才能知道提到哪个仓库",
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        SocProbe.Info si = SocProbe.get(this, false);
        String title = "新机型: " + si.raw + (si.market.isEmpty() ? "" : " (" + si.market + ")");
        String body = "App 没认出这颗芯片 / 信息有误，请补一条映射。\n\n"
                + "```json\n" + SocTrust.toJson(this) + "```\n\n"
                + "期望的 market 写法：\n```json\n\"" + si.raw + "\": \"\"\n```\n";
        try {
            String u = "https://github.com/" + slug + "/issues/new?title="
                    + java.net.URLEncoder.encode(title, "UTF-8")
                    + "&body=" + java.net.URLEncoder.encode(body, "UTF-8");
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)));
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "打不开浏览器: " + t.getClass().getSimpleName(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    /** 映射表地址设置 + 立即同步。 */
    private void mapDialog() {
        final android.widget.EditText et = new android.widget.EditText(this);
        et.setText(SocMap.url(this));
        et.setHint("https://raw.githubusercontent.com/你/仓库/main/soc.json");
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        et.setTextColor(Theme.text());
        et.setHintTextColor(Theme.dim2());

        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("芯片映射表地址")
                .setMessage("当前：" + SocMap.status(this)
                        + "\n\n填一个公开可 GET 的 JSON 地址（GitHub raw / gist 都行）。"
                        + "\n留空 = 只用内置表。只下载，不上传任何信息。")
                .setView(et)
                .setPositiveButton("同步", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        SocMap.setUrl(SysInfoActivity.this, et.getText().toString());
                        android.widget.Toast.makeText(SysInfoActivity.this, "正在同步…",
                                android.widget.Toast.LENGTH_SHORT).show();
                        new Thread(new Runnable() {
                            @Override public void run() {
                                final String r = SocMap.fetch(SysInfoActivity.this, true);
                                runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        android.widget.Toast.makeText(SysInfoActivity.this, r,
                                                android.widget.Toast.LENGTH_LONG).show();
                                        load();
                                    }
                                });
                            }
                        }).start();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void load() {
        body.setText("读取中…");
        new Thread(new Runnable() {
            @Override public void run() {
                final String text = build();
                runOnUiThread(new Runnable() {
                    @Override public void run() { body.setText(text); }
                });
            }
        }).start();
    }

    private String build() {
        StringBuilder b = new StringBuilder();
        b.append("【设备】\n");
        b.append("厂商   : ").append(Build.MANUFACTURER).append('\n');
        b.append("型号   : ").append(Build.MODEL).append('\n');
        b.append("系统   : Android ").append(Build.VERSION.RELEASE)
                .append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        b.append("补丁   : ").append(Build.VERSION.SECURITY_PATCH).append('\n');
        b.append("ABI    : ").append(Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?").append('\n');
        b.append("内核   : ").append(System.getProperty("os.version", "?")).append('\n');
        b.append("核心   : ").append(Runtime.getRuntime().availableProcessors()).append(" 核\n");

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        b.append("屏幕   : ").append(dm.widthPixels).append('x').append(dm.heightPixels)
                .append(" @").append((int) dm.densityDpi).append("dpi\n");

        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            b.append("App    : v").append(pi.versionName).append(" (").append(pi.versionCode).append(")\n");
        } catch (Throwable ignored) { }

        SocProbe.Info si = SocProbe.get(this, false);
        if (si != null) {
            b.append("\n【芯片识别】\n");
            b.append("原始值 : ").append(si.raw).append('\n');
            b.append("来源   : ").append(si.source).append('\n');
            if (si.vendor != null && !si.vendor.isEmpty())
                b.append("厂商   : ").append(si.vendor).append('\n');
            if (si.market != null && !si.market.isEmpty())
                b.append("型号名 : ").append(si.market).append('\n');
            if (si.deviceMarket != null && !si.deviceMarket.isEmpty())
                b.append("手机名 : ").append(si.deviceMarket).append('\n');

            SocTrust.Result tr = SocTrust.check(this);
            b.append("识别   : ").append(tr.degrade.isEmpty() ? "完整（已读系统属性）" : "降级（仅 Build 字段）").append('\n');
            if (!tr.degrade.isEmpty()) b.append("         ").append(tr.degrade).append('\n');
            b.append("映射表 : ").append(SocMap.status(this)).append('\n');
            b.append("内置表 : ").append(BuiltinMap.size(this)).append(" 条").append('\n');
            b.append("数据源 : 型号表整理自 YAWAsau/backup_script（GPL-3.0）").append('\n');
            b.append("可信度 : ").append(tr.levelText()).append('\n');
            for (String n : tr.notes) b.append("         · ").append(n).append('\n');
        }

        b.append("\n【Shizuku】\n");
        int perm = ShizukuShell.perm();
        b.append("状态   : ").append(perm < 0 ? "未连接" : (perm == PackageManager.PERMISSION_GRANTED ? "已授权" : "未授权")).append('\n');
        b.append("数据源 : ").append(
                "root".equals(DataSource.lastSource()) ? "Root 直读"
                : "shizuku".equals(DataSource.lastSource()) ? "Shizuku 本地" : "容器后端").append('\n');
        b.append("Root   : ").append(Shell.hasRoot()
                ? "已获取（" + (Shell.rootVia().isEmpty() ? "su" : Shell.rootVia()) + "）"
                : "未获取（" + Shell.err() + "）").append('\n');
        b.append("采样   : ").append(DataSource.diag()).append('\n');
        b.append("帧率源 : ").append(DataSource.fpsDebug()).append('\n');
        b.append("前台   : ").append(DataSource.fgPkg().isEmpty() ? "（拿不到）" : DataSource.fgPkg()).append('\n');

        String powerInfo = DataSource.powerInfo();
        b.append("功耗源 : ").append(powerInfo == null || powerInfo.isEmpty() ? "—" : powerInfo).append('\n');

        b.append("\n【电源】\n");
        try {
            android.os.BatteryManager bm = (android.os.BatteryManager) getSystemService(BATTERY_SERVICE);
            Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int lv = bi.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int tp = bi.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1);
                int vt = bi.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, -1);
                int st = bi.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
                int hl = bi.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, -1);
                b.append("电量   : ").append(lv >= 0 ? lv + "%" : "—").append('\n');
                b.append("电池温 : ").append(tp > 0
                        ? String.format(java.util.Locale.US, "%.1f °C", tp / 10.0) : "—").append('\n');
                // 有的 ROM 给 mV（4239），有的直接给 V（4）——按量级判断
                b.append("电压   : ").append(vt > 0
                        ? String.format(java.util.Locale.US, "%.3f V", vt >= 100 ? vt / 1000.0 : vt) : "—").append('\n');
                b.append("状态   : ").append(st == android.os.BatteryManager.BATTERY_STATUS_CHARGING ? "充电中"
                        : st == android.os.BatteryManager.BATTERY_STATUS_FULL ? "已充满"
                        : st == android.os.BatteryManager.BATTERY_STATUS_DISCHARGING ? "放电中"
                        : st == android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING ? "未充电" : "—").append('\n');
                b.append("健康   : ").append(hl == android.os.BatteryManager.BATTERY_HEALTH_GOOD ? "良好"
                        : hl == android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT ? "过热"
                        : hl == android.os.BatteryManager.BATTERY_HEALTH_COLD ? "过冷" : "一般").append('\n');
            }
        } catch (Throwable t) {
            b.append("读取失败: ").append(t.getMessage()).append('\n');
        }
        b.append("节点   : ").append(DataSource.powerDevs()).append('\n');

        b.append("\n【内存】\n");
        String mem = Shell.exec("grep -E '^(MemTotal|MemAvailable):' /proc/meminfo", 3000);
        if (mem != null) b.append(mem.trim()).append('\n');

        b.append("\n【温度传感器】\n");
        String ts = Shell.exec(
                "dumpsys thermalservice 2>/dev/null | sed -n '/Current temperatures from HAL/,/Current cooling/p' | head -14", 5000);
        b.append(ts == null ? "（读不到）\n" : ts.trim() + "\n");

        b.append("\n【刷新率】\n");
        double dr = DataSource.dispRate();
        b.append(dr > 0 ? String.format(java.util.Locale.US, "当前刷新率 : %.0f Hz（采样值）\n", dr) : "（读不到）\n");
        String rr = Shell.exec("dumpsys SurfaceFlinger --timestats -dump 2>/dev/null | grep -m3 '^displayRefreshRate'", 4000);
        if (rr != null) b.append("图层上报 : ").append(rr.trim().replace("\n", " / ")).append('\n');

        return b.toString();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); }
    }
}
