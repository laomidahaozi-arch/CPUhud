package com.dsh.cpuhud;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 二级页：权限、Shizuku、防误触、游戏模式与名单、更新日志 —— 让主界面只留最常用的几个按钮。 */
public class MoreActivity extends Activity {

    private SharedPreferences prefs;
    private TextView shizukuView;
    private Button lockBtn, gameBtn;
    private int themeSig;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        prefs = getSharedPreferences("hud", MODE_PRIVATE);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(28));

        TextView t = text("更多设置", 24f, Theme.strong(), false, true);
        t.setPadding(0, 0, 0, dp(2));
        root.addView(t);
        root.addView(text("权限、手势、游戏名单都在这里；主界面只留最常用的操作。", 11.5f, Theme.dim2(), false, false));

        // ---------------- 权限 ----------------
        root.addView(header("权限与连接"));
        LinearLayout r1 = row();
        Button perm = btn("悬浮窗权限", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                }
            }
        });
        Button shz = btn("授予 Shizuku 权限", new View.OnClickListener() {
            @Override public void onClick(View v) {
                ShizukuShell.request();
                toast("已请求，去 Shizuku 弹窗点允许");
            }
        });
        r1.addView(perm);
        r1.addView(shz);
        root.addView(r1);

        shizukuView = text("", 11.5f, Theme.dim2(), true, false);
        shizukuView.setPadding(0, dp(6), 0, 0);
        root.addView(shizukuView);

        // ---------------- 手势 ----------------
        root.addView(header("悬浮窗手势"));
        LinearLayout r2 = row();
        lockBtn = btn("", new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !prefs.getBoolean("touchLock", false);
                prefs.edit().putBoolean("touchLock", on).apply();
                refreshLock();
                toast(on ? "已锁定：点击/拖动会穿透到下面" : "已解锁：可以拖动和点击了");
            }
        });
        gameBtn = btn("", new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !prefs.getBoolean("gameForce", false);
                prefs.edit().putBoolean("gameForce", on).apply();
                refreshGame();
                toast(on ? "已强制游戏模式" : "游戏模式：自动识别");
            }
        });
        r2.addView(lockBtn);
        r2.addView(gameBtn);
        root.addView(r2);
        root.addView(text("· 防误触：开启后点击/拖动全部穿透到下面的游戏，不会误触\n"
                + "· 游戏模式：横屏全屏自动开启（曲线变大、显示帧时间与卡顿），也可以强制常开",
                10.5f, Theme.dim2(), false, false));

        // ---------------- 游戏名单 ----------------
        root.addView(header("游戏名单"));
        LinearLayout r3 = row();
        Button addGame = btn("当前应用加入名单", new View.OnClickListener() {
            @Override public void onClick(View v) { gameList("add"); }
        });
        Button rmGame = btn("移出名单", new View.OnClickListener() {
            @Override public void onClick(View v) { gameList("rm"); }
        });
        r3.addView(addGame);
        r3.addView(rmGame);
        root.addView(r3);
        root.addView(text("名单里的应用一打开就进游戏模式，不用横屏判断。", 10.5f, Theme.dim2(), false, false));

        // ---------------- 其他 ----------------
        root.addView(header("其他"));
        LinearLayout r4 = row();
        Button dev = btn("设备信息", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MoreActivity.this, DeviceInfoActivity.class));
            }
        });
        Button test = btn("设备自检", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MoreActivity.this, SelfTestActivity.class));
            }
        });
        Button upd = btn("更新与安装", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MoreActivity.this, UpdateActivity.class));
            }
        });
        Button ver = btn("更新日志", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MoreActivity.this, VersionActivity.class));
            }
        });
        Button sys = btn("系统信息", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MoreActivity.this, SysInfoActivity.class));
            }
        });
        r4.addView(dev);
        r4.addView(test);
        LinearLayout r4b = row();
        r4b.addView(upd);
        r4b.addView(sys);
        root.addView(r4b);
        root.addView(r4);
        LinearLayout r5 = row();
        r5.addView(ver);
        root.addView(r5);

        Button back = btn("返回", new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        blp.topMargin = dp(20);
        root.addView(back, blp);

        sc.addView(root);
        setContentView(sc);
        refreshLock();
        refreshGame();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); return; }
        if (shizukuView != null) refreshShizuku();
    }

    private void refreshShizuku() {
        int p = ShizukuShell.perm();
        if (p < 0) {
            shizukuView.setText(Shell.hasRoot() ? "Root：已获取（本地直读模式）" : "Shizuku 直连：未连接（数据走容器后端）");
            shizukuView.setTextColor(Theme.dim2());
        } else if (p == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            shizukuView.setText(Shell.hasRoot() ? "Root + Shizuku：已连接（优先走 Root 直读）"
                    : "Shizuku：已连接 · 已授权（本地采样可用）");
            shizukuView.setTextColor(Theme.good());
        } else {
            shizukuView.setText("Shizuku：已连接 · 未授权（点上面按钮）");
            shizukuView.setTextColor(Theme.warn());
        }
    }

    private void refreshLock() {
        if (lockBtn != null) lockBtn.setText(prefs.getBoolean("touchLock", false) ? "防误触：开" : "防误触：关");
    }

    private void refreshGame() {
        if (gameBtn != null) gameBtn.setText(prefs.getBoolean("gameForce", false) ? "游戏模式：强制开" : "游戏模式：自动");
    }

    private void gameList(final String op) {
        final Snapshot s = HudService.lastSnapshot;
        final String pkg = s != null ? s.pkg : "";
        if (pkg == null || pkg.isEmpty()) {
            toast("还没识别到前台应用");
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    MetricsClient.gameCmd(op, pkg);
                    runOnUiThread(new Runnable() { @Override public void run() { toast("已更新名单：" + pkg); } });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() { @Override public void run() { toast("失败：" + e.getMessage()); } });
                }
            }
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(4);
        r.setLayoutParams(p);
        return r;
    }

    private TextView header(String s) {
        TextView v = text(s, 14f, Theme.good(), false, true);
        v.setPadding(0, dp(20), 0, dp(4));
        return v;
    }

    private TextView text(String s, float sp, int color, boolean mono, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (mono) v.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL);
        v.setPadding(0, dp(3), 0, dp(3));
        return v;
    }

    private Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        b.setTextColor(Theme.text());
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }
}
