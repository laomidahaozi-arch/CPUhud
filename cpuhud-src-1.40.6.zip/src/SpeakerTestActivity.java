package com.dsh.cpuhud;

import android.app.Activity;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 扬声器自检：左 / 右 / 立体声 / 扫频。
 * 会临时把媒体音量拉到 ~70%，退出时还原（异常退出也尽力还原）。
 */
public class SpeakerTestActivity extends Activity {

    private static final int SR = 44100;
    private AudioManager am;
    private int savedVolume = -1;
    private Tone tone;
    private TextView state;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        savedVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));

        TextView t = new TextView(this);
        t.setText("扬声器自检");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f);
        t.setTextColor(Theme.strong());
        root.addView(t);

        TextView sub = new TextView(this);
        sub.setText("先听左声道、再听右声道：两边都出声才是真立体声。\n扫频段从 100Hz 到 16kHz，注意有没有破音、咔哒声或某个频段完全听不到。\n音量会自动调到约 70%，退出时还原。");
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setTextColor(Theme.dim2());
        sub.setPadding(0, dp(6), 0, dp(12));
        root.addView(sub);

        state = new TextView(this);
        state.setText("未播放");
        state.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        state.setTextColor(Theme.dim());
        state.setPadding(0, 0, 0, dp(10));
        root.addView(state);

        root.addView(btnRow(new String[]{"左声道", "右声道"}, new int[]{0, 1}));
        root.addView(btnRow(new String[]{"立体声", "扫频 100→16kHz"}, new int[]{2, 3}));

        Button stop = wideBtn("停止");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopTone(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        lp.topMargin = dp(8);
        root.addView(stop, lp);

        LinearLayout judge = new LinearLayout(this);
        judge.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams jp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        jp.topMargin = dp(20);
        judge.setLayoutParams(jp);
        Button ok = wideBtn("都正常");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { done("pass", "左右声道都出声，无破音"); }
        });
        Button bad = wideBtn("有异常");
        bad.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { done("fail", "有破音 / 单边无声 / 频段缺失"); }
        });
        judge.addView(ok);
        judge.addView(bad);
        root.addView(judge);

        Button back = wideBtn("返回");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        bp.topMargin = dp(8);
        root.addView(back, bp);

        sc.addView(root);
        setContentView(sc);
    }

    private View btnRow(String[] labels, int[] modes) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(6);
        row.setLayoutParams(rp);
        for (int i = 0; i < labels.length; i++) {
            final int mode = modes[i];
            final String label = labels[i];
            Button b = wideBtn(label);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startTone(mode, label);
                }
            });
            row.addView(b);
        }
        return row;
    }

    private void startTone(int mode, String label) {
        stopTone();
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(1, (int) (max * 0.7)), 0);
        tone = new Tone(mode);
        tone.start();
        state.setText("正在播放：" + label + "（音量 " + am.getStreamVolume(AudioManager.STREAM_MUSIC) + "/" + max + "）");
    }

    private void stopTone() {
        if (tone != null) {
            tone.stopPlaying();
            tone = null;
        }
        if (state != null) state.setText("已停止");
    }

    private void done(String result, String note) {
        SharedPreferences p = getSharedPreferences("selftest", MODE_PRIVATE);
        p.edit().putString("speaker", result).putString("speaker_note", note)
                .putLong("speaker_ts", System.currentTimeMillis()).apply();
        Toast.makeText(this, "已记录", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override protected void onDestroy() {
        stopTone();
        if (savedVolume >= 0) {
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }

    /** 简易正弦 / 扫频发生器，左右声道单独可控。 */
    private static class Tone extends Thread {
        private final int mode;          // 0 左, 1 右, 2 立体声, 3 扫频(立体声)
        private volatile boolean running = true;
        private AudioTrack track;

        Tone(int mode) { this.mode = mode; setPriority(Thread.NORM_PRIORITY + 1); }

        void stopPlaying() {
            running = false;
        }

        @Override public void run() {
            int chMask = AudioFormat.CHANNEL_OUT_STEREO;
            int bufFrames = 2048;
            try {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SR)
                                .setChannelMask(chMask).build())
                        .setBufferSizeInBytes(bufFrames * 2 * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build();
                track.play();
            } catch (Throwable t) {
                return;
            }
            short[] buf = new short[bufFrames * 2];
            double phase = 0;
            double sweepPos = 0;
            while (running) {
                for (int i = 0; i < bufFrames; i++) {
                    double freq;
                    if (mode == 3) {
                        sweepPos += 1.0 / SR;
                        if (sweepPos > 6.0) sweepPos = 0;       // 6 秒扫一轮
                        freq = 100 * Math.pow(16000.0 / 100.0, sweepPos / 6.0);
                    } else {
                        freq = 440;
                    }
                    phase += 2 * Math.PI * freq / SR;
                    if (phase > Math.PI * 2) phase -= Math.PI * 2;
                    short s = (short) (Math.sin(phase) * 7000);
                    boolean left = mode != 1, right = mode != 0;
                    buf[i * 2] = (short) (left ? s : 0);
                    buf[i * 2 + 1] = (short) (right ? s : 0);
                }
                try {
                    int w = track.write(buf, 0, buf.length);
                    if (w < 0) break;
                } catch (Throwable t) {
                    break;
                }
            }
            try { track.stop(); } catch (Throwable ignored) { }
            try { track.release(); } catch (Throwable ignored) { }
        }
    }

    private Button wideBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTextColor(Theme.text());
        b.setPadding(0, 0, 0, 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(46), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
