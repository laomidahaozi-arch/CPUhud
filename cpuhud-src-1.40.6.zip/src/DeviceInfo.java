package com.dsh.cpuhud;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.display.DisplayManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.SizeF;
import android.view.Display;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 设备信息采集：能用系统 API 的一律走 API，API 不给的再借 shell（Shizuku / root）。
 * 读不到的一律写「n/a · 系统未开放」，不编数据。
 */
public final class DeviceInfo {

    public static final class Section {
        public final String title, query;
        public final List<String[]> rows = new ArrayList<>();
        Section(String t, String q) { title = t; query = q; }
        void add(String k, String v) { rows.add(new String[]{k, v == null ? "" : v}); }
        void addIf(String k, String v) { if (v != null && !v.isEmpty() && !"—".equals(v)) rows.add(new String[]{k, v}); }
    }

    public static final class Result {
        public final List<Section> sections = new ArrayList<>();
        public final List<String[]> compare = new ArrayList<>();   // {项目, 实测, 标称, 状态}
        public String model = "", market = "", specName = "", specStatus = "", searchUrl = "";
        public boolean hasSpec = false;
    }

    private DeviceInfo() { }

    public static String searchUrl(String q) {
        return "https://www.bing.com/search?q=" + Uri.encode(q);
    }

    public static Result collect(Context ctx) {
        Result r = new Result();
        r.model = nz(Build.MODEL);
        SocProbe.Info soc = SocProbe.get(ctx, false);
        JSONObject spec = SpecMap.entry(ctx, r.model);
        JSONObject socSpec = spec == null ? SpecMap.soc(ctx, soc.raw) : SpecMap.soc(ctx, soc.raw);
        if (spec == null) spec = SpecMap.entry(ctx, nz(Build.PRODUCT));
        r.hasSpec = spec != null;
        r.specStatus = SpecMap.status(ctx);
        if (spec != null) {
            r.specName = spec.optString("name", "");
            r.market = r.specName;
        } else {
            r.market = soc.deviceMarket == null ? "" : soc.deviceMarket;
        }
        // 注意：之前这里把「芯片名」当成了手机市场名，导致显示「25080RABDC（天玑 7200）」
        if (r.market != null && (r.market.equalsIgnoreCase(soc.market) || r.market.equalsIgnoreCase(soc.raw))) {
            r.market = "";
        }
        r.searchUrl = searchUrl(r.market.isEmpty() ? r.model : (r.market + " " + r.model));

        identity(ctx, r, soc, spec);
        processor(ctx, r, soc, socSpec);
        screen(ctx, r, spec, socSpec);
        battery(ctx, r, spec);
        storage(ctx, r);
        audio(ctx, r, spec);
        camera(ctx, r, spec);
        sensors(ctx, r);
        network(ctx, r);
        security(ctx, r);
        compare(ctx, r, spec, socSpec, soc);
        return r;
    }

    // ---------------------------------------------------------------- 身份

    private static void identity(Context ctx, Result r, SocProbe.Info soc, JSONObject spec) {
        Section s = new Section("设备身份", r.model + " 手机 参数");
        s.add("品牌", cap(Build.BRAND) + " / " + cap(Build.MANUFACTURER));
        boolean sameMarket = r.market == null || r.market.isEmpty()
                || r.market.equalsIgnoreCase(r.model);
        s.add("型号", sameMarket ? r.model : (r.model + "（" + r.market + "）"));
        // 没有任何 shell / Shizuku 时，把「为什么有些项是空的」直接写在页面上
        boolean shellOk = Shell.hasRoot() || ShizukuShell.granted();
        if (!shellOk) {
            s.add("数据源", "仅系统 API（未授权 Shizuku / 无 root：功耗、CPU 频率、循环次数等读不到）");
        }
        s.add("代号 / 产品", Build.DEVICE + " / " + Build.PRODUCT);
        s.add("主板 / 硬件", Build.BOARD + " / " + Build.HARDWARE);
        s.add("Android", Build.VERSION.RELEASE + "  ·  SDK " + Build.VERSION.SDK_INT
                + (Build.VERSION.PREVIEW_SDK_INT > 0 ? " (preview)" : ""));
        s.addIf("安全补丁", nz(Build.VERSION.SECURITY_PATCH));
        s.addIf("内核", System.getProperty("os.version"));
        s.add("构建时间", fmt(Build.TIME));
        s.add("CPU 架构", join(Build.SUPPORTED_ABIS, ", "));
        if (spec != null) s.addIf("上市时间", spec.optString("release", ""));
        s.add("系统指纹", nz(Build.FINGERPRINT));
        s.add("序列号", "已隐藏（隐私）");
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- SoC

    private static void processor(Context ctx, Result r, SocProbe.Info soc, JSONObject socSpec) {
        Section s = new Section("处理器 SoC", soc.raw + " 参数 架构");
        s.add("型号", (soc.market.isEmpty() ? "未知" : soc.market) + "（" + nz(soc.raw) + "）");
        s.add("厂商", nz(soc.vendor));
        s.addIf("识别来源", soc.source);
        s.addIf("校正说明", soc.note);
        try {
            SocVerify.Verdict v = SocVerify.cached(ctx, soc.raw);
            if (v != null && v.name != null && !v.name.isEmpty()) {
                s.add("交叉验证", v.name + "（置信度 " + v.confidence + "）");
                for (String[] ev : v.evidence) {
                    s.add("· " + ev[0], ev[1] + "   " + ev[2]);
                }
                s.addIf("验证说明", v.note);
            }
        } catch (Throwable ignored) { }
        if (!soc.candidates.isEmpty()) {
            StringBuilder cb = new StringBuilder();
            for (java.util.Map.Entry<String, String> e : soc.candidates.entrySet()) {
                if (cb.length() > 0) cb.append("\n");
                cb.append("· ").append(e.getKey()).append(" = ").append(e.getValue());
            }
            s.add("候选属性", cb.toString());
        }
        if (socSpec != null) {
            s.addIf("工艺", socSpec.optString("node", ""));
            s.addIf("核心构成", socSpec.optString("cores", ""));
        }
        String[] freq = cpuClusters();
        if (freq != null) s.add("核心 / 最高频率", freq[0]);
        String gpu = HwInfo.gpuRenderer();
        s.add("GPU", gpu);
        if (socSpec != null) {
            String gpuSpec = socSpec.optString("gpu", "");
            if (!gpuSpec.isEmpty() && !gpuSpec.equalsIgnoreCase(gpu)) s.add("标称 GPU", gpuSpec);
        }
        s.add("指令集", nz(Build.SUPPORTED_64_BIT_ABIS.length > 0 ? "64 位" : "32 位")
                + " · " + System.getProperty("os.arch"));
        r.sections.add(s);
    }

    /** 从 /sys 读每核最高频率，按频率合并成簇。 */
    private static String[] cpuClusters() {
        String out = Shell.exec("for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do "
                + "n=$(echo \"$f\" | sed 's#.*/cpu\\([0-9]*\\)/cpufreq.*#\\1#'); echo \"$n $(cat $f 2>/dev/null)\"; done", 4000);
        if (out == null || out.trim().isEmpty()) return null;
        Map<Long, List<Integer>> byFreq = new LinkedHashMap<>();
        int total = 0;
        for (String line : out.split("\\n")) {
            String[] p = line.trim().split("\\s+");
            if (p.length < 2) continue;
            try {
                int id = Integer.parseInt(p[0]);
                long khz = Long.parseLong(p[1]);
                if (khz <= 0) continue;
                List<Integer> l = byFreq.get(khz);
                if (l == null) { l = new ArrayList<>(); byFreq.put(khz, l); }
                l.add(id);
                total++;
            } catch (Throwable ignored) { }
        }
        if (byFreq.isEmpty()) return null;
        List<Long> keys = new ArrayList<>(byFreq.keySet());
        java.util.Collections.sort(keys);
        StringBuilder sb = new StringBuilder();
        for (Long k : keys) {
            List<Integer> ids = byFreq.get(k);
            java.util.Collections.sort(ids);
            if (sb.length() > 0) sb.append(" + ");
            sb.append(ids.size()).append("× ").append(String.format(Locale.US, "%.2f", k / 1000000.0)).append("GHz");
        }
        return new String[]{total + " 核 · " + sb, byFreq.toString()};
    }

    // ---------------------------------------------------------------- 屏幕

    private static void screen(Context ctx, Result r, JSONObject spec, JSONObject socSpec) {
        Section s = new Section("屏幕", r.model + " 屏幕 参数");
        Display d0 = null;
        try {
            DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
            Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
            d0 = d;
            DisplayMetrics m = new DisplayMetrics();
            d.getRealMetrics(m);
            s.add("分辨率", m.widthPixels + " × " + m.heightPixels + " px");
            s.add("密度", m.densityDpi + " dpi（逻辑）· "
                    + String.format(Locale.US, "%.1f", m.xdpi) + " dpi（物理）");
            double inch = Math.sqrt(Math.pow(m.widthPixels / (double) m.xdpi, 2)
                    + Math.pow(m.heightPixels / (double) m.ydpi, 2));
            s.add("估算尺寸", String.format(Locale.US, "%.2f 英寸", inch));
            s.add("当前刷新率", String.format(Locale.US, "%.0f Hz", d.getRefreshRate()));

            Display.Mode[] modes = d.getSupportedModes();
            if (modes != null && modes.length > 0) {
                Set<Integer> hzSet = new java.util.TreeSet<>(java.util.Collections.reverseOrder());
                Set<String> res = new LinkedHashSet<>();
                float max = 0;
                for (Display.Mode mo : modes) {
                    hzSet.add(Math.round(mo.getRefreshRate()));
                    res.add(mo.getPhysicalWidth() + "×" + mo.getPhysicalHeight());
                    max = Math.max(max, mo.getRefreshRate());
                }
                StringBuilder hzStr = new StringBuilder();
                for (Integer h : hzSet) {
                    if (hzStr.length() > 0) hzStr.append(" / ");
                    hzStr.append(h);
                }
                s.add("支持档位", hzStr + " Hz");
                s.add("最高刷新率", String.format(Locale.US, "%.0f Hz", max));
                if (res.size() > 1) s.add("支持分辨率", join(res.toArray(new String[0]), " / "));
            }
            // 色域 / HDR / 挖孔：这一版 Android SDK 的 stub 里没有对应方法，统一从 dumpsys 里取
            String dump = Shell.exec("D=$(dumpsys display 2>/dev/null); "
                    + "echo \"C:$(echo \"$D\" | grep -o 'supportedColorModes \\[[^]]*\\]' | head -1)\"; "
                    + "echo \"H:$(echo \"$D\" | grep -o 'mSupportedHdrTypes=\\[[^]]*\\]' | head -1)\"; "
                    + "echo \"L:$(echo \"$D\" | grep -o 'mMaxAverageLuminance=[0-9.]*' | head -1)\"; "
                    + "echo \"K:$(echo \"$D\" | grep -o 'cutout DisplayCutout{insets=Rect([^)]*)' | head -1)\"", 7000);
            if (dump != null) {
                for (String line : dump.split("\n")) {
                    line = line.trim();
                    if (line.startsWith("C:") && line.length() > 3) {
                        String nums = between(line, "[", "]");
                        StringBuilder sb = new StringBuilder();
                        for (String n : nums.split(",")) {
                            try {
                                if (sb.length() > 0) sb.append(" / ");
                                sb.append(colorModeName(Integer.parseInt(n.trim())));
                            } catch (Throwable ignored) { }
                        }
                        if (sb.length() > 0) s.add("色域模式", sb.toString());
                    } else if (line.startsWith("H:") && line.contains("[")) {
                        String nums = between(line, "[", "]");
                        StringBuilder sb = new StringBuilder();
                        for (String n : nums.split(",")) {
                            try {
                                if (sb.length() > 0) sb.append(" / ");
                                sb.append(hdrName(Integer.parseInt(n.trim())));
                            } catch (Throwable ignored) { }
                        }
                        s.addIf("HDR", sb.toString());
                    } else if (line.startsWith("L:") && line.contains("=")) {
                        String v = line.substring(line.indexOf('=') + 1).trim();
                        if (!v.isEmpty() && !v.equals("0")) s.add("峰值亮度", v.replace(".0", "") + " nit");
                    } else if (line.startsWith("K:") && line.contains("Rect(")) {
                        String ins = between(line, "Rect(", ")").replace(" - ", ",");
                        String[] nums = ins.split(",");
                        if (nums.length >= 2) {
                            try {
                                int top = (int) Double.parseDouble(nums[1].trim());
                                if (top > 0) {
                                    s.add("挖孔 / 刘海", "顶部凹槽深 " + top + " px");
                                }
                            } catch (Throwable ignored) { }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            s.add("读取", "失败：" + t.getMessage());
        }
        // 没 shell（未授权 Shizuku / 无 root）时 dumpsys 全空 —— 色域 / HDR / 挖孔改走系统 API
        apiScreenFallback(s, d0);
        String edidAll = Shell.exec("dumpsys display 2>/dev/null | grep -o 'deviceProductInfo DeviceProductInfo{[^}]*}'", 4000);
        String edid = null;
        if (edidAll != null) {
            for (String line : edidAll.split("\n")) {
                String nm = between(line, "name=", ",").trim();
                // MTKDEV / generic / 空 都是 MTK 的通用占位，不是真面板
                if (nm.isEmpty() || nm.equalsIgnoreCase("MTKDEV") || nm.equalsIgnoreCase("generic")
                        || nm.equalsIgnoreCase("unknown")) continue;
                edid = line;
                break;
            }
        }
        if (edid != null && edid.contains("name=")) {
            String name = between(edid, "name=", ",");
            String manu = between(edid, "manufacturerPnpId=", ",");
            String pid = between(edid, "productId=", ",");
            String week = between(edid, "week=", ",");
            String year = between(edid, "year=", "}");
            StringBuilder sb = new StringBuilder(nz(name));
            if (!manu.isEmpty()) sb.append("  ·  PnP ").append(manu);
            if (!pid.isEmpty()) sb.append("  ·  PID ").append(pid);
            if (!week.isEmpty() || !year.isEmpty()) sb.append("  ·  ").append(year).append(" 第 ").append(week).append(" 周");
            s.add("面板信息", sb.toString());
        }
        if (spec != null) {
            JSONObject sc = spec.optJSONObject("screen");
            if (sc != null) {
                s.addIf("标称尺寸", sc.optString("size", "") + " 英寸");
                s.addIf("标称面板", sc.optString("panel", ""));
                s.addIf("标称触控采样率", sc.optString("touch_hz", "") + " Hz");
            }
        }
        r.sections.add(s);
    }

    /** 用系统 API 补屏幕的能力参数（反射调用，老 SDK 根上没有这些方法也不会崩）。 */
    private static void apiScreenFallback(Section s, Display d) {
        if (d == null) return;
        boolean hasColor = false, hasHdr = false, hasCut = false;
        for (String[] row : s.rows) {
            if ("色域模式".equals(row[0])) hasColor = true;
            if ("HDR".equals(row[0])) hasHdr = true;
            if ("挖孔 / 刘海".equals(row[0])) hasCut = true;
        }
        if (!hasColor) {
            Object cm = call(d, "getSupportedColorModes");
            if (cm instanceof int[]) {
                StringBuilder sb = new StringBuilder();
                for (int c : (int[]) cm) {
                    if (sb.length() > 0) sb.append(" / ");
                    sb.append(colorModeName(c));
                }
                if (sb.length() > 0) s.add("色域模式", sb.toString());
            }
        }
        if (!hasHdr) {
            Object hdr = call(d, "getHdrCapabilities");
            if (hdr != null) {
                Object types = call(hdr, "getSupportedHdrTypes");
                if (types instanceof int[]) {
                    StringBuilder sb = new StringBuilder();
                    for (int t : (int[]) types) {
                        if (sb.length() > 0) sb.append(" / ");
                        sb.append(hdrName(t));
                    }
                    Object lum = call(hdr, "getMaxAverageLuminance");
                    if (lum instanceof Number) {
                        sb.append("  ·  峰值 ").append(Math.round(((Number) lum).doubleValue())).append(" nit");
                    }
                    if (sb.length() > 0) s.add("HDR", sb.toString());
                }
            }
        }
        if (!hasCut) {
            Object cut = call(d, "getCutout");
            if (cut != null) {
                Object rects = call(cut, "getBoundingRects");
                if (rects instanceof java.util.List && !((java.util.List<?>) rects).isEmpty()) {
                    Object rc = ((java.util.List<?>) rects).get(0);
                    try {
                        int h = (int) rc.getClass().getMethod("height").invoke(rc);
                        if (h > 0) s.add("挖孔 / 刘海", "顶部凹槽深 " + h + " px");
                    } catch (Throwable ignored) { }
                }
            }
        }
    }

    private static Object call(Object obj, String method) {
        try { return obj.getClass().getMethod(method).invoke(obj); } catch (Throwable t) { return null; }
    }

    // ---------------------------------------------------------------- 电池 / 充电

    private static void battery(Context ctx, Result r, JSONObject spec) {
        Section s = new Section("电池与充电", r.model + " 电池 容量 充电");
        BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
        int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        s.add("电量", level + " %");
        int st = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
        String stName = st == BatteryManager.BATTERY_STATUS_CHARGING ? "充电中"
                : st == BatteryManager.BATTERY_STATUS_FULL ? "已充满"
                : st == BatteryManager.BATTERY_STATUS_DISCHARGING ? "放电中" : "—";
        Intent ib = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (ib != null) {
            int mv = ib.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            int tenth = ib.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            int plug = ib.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            if (tenth > 0) s.add("温度", String.format(Locale.US, "%.1f °C", tenth / 10.0));
            s.add("充电状态", stName + (plug == 0 ? "（未接电源）"
                    : plug == BatteryManager.BATTERY_PLUGGED_AC ? " · 充电器"
                    : plug == BatteryManager.BATTERY_PLUGGED_USB ? " · USB"
                    : plug == BatteryManager.BATTERY_PLUGGED_WIRELESS ? " · 无线" : ""));
            int health = ib.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            s.add("电池状态", health == BatteryManager.BATTERY_HEALTH_GOOD ? "良好"
                    : health == BatteryManager.BATTERY_HEALTH_OVERHEAT ? "过热"
                    : health == BatteryManager.BATTERY_HEALTH_DEAD ? "已损坏" : "未知");
        }
        // 电压 / 电流：ColorOS 的广播把 mV 当 V 给（0.004V），统一改读 /sys
        String vraw = val(Shell.exec("cat /sys/class/power_supply/battery/voltage_now 2>/dev/null", 2000));
        double volts = toVolts(vraw);
        if (volts > 0.5) s.add("电压", String.format(Locale.US, "%.3f V", volts));
        String iraw = val(Shell.exec("cat /sys/class/power_supply/battery/current_now 2>/dev/null", 2000));
        double ma = toMilliAmp(iraw);
        if (ma > 0.5) {
            boolean charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            s.add("电流", String.format(Locale.US, "%.0f mA（%s）", ma, charging ? "充电" : "放电"));
        }

        // /sys：不同机型节点位置不一样（battery / bms / main_battery / bms_1 …），整片扫一遍。
        // 老版本只读 /sys/class/power_supply/battery/，在别的机器上就全空。
        String dump = Shell.exec("for d in /sys/class/power_supply/*; do n=${d##*/}; "
                + "for f in charge_full charge_full_design cycle_count charge_counter; do "
                + "v=$(cat $d/$f 2>/dev/null); [ -n \"$v\" ] && echo \"$n/$f=$v\"; done; done", 4000);
        java.util.LinkedHashMap<String, String> ps = new java.util.LinkedHashMap<>();
        if (dump != null) {
            for (String line : dump.split("\n")) {
                int eq = line.indexOf('=');
                if (eq > 0) ps.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim());
            }
        }
        String cycle = bySuffix(ps, "/cycle_count");
        String full = bySuffix(ps, "/charge_full");
        String des = bySuffix(ps, "/charge_full_design");
        String counter = bySuffix(ps, "/charge_counter");
        if (!cycle.isEmpty()) s.add("循环次数", cycle + " 次");
        long cFull = mAh(full), cDes = mAh(des);
        long cDesRaw = cDes;
        cDes = alignScale(cDes, cFull);          // 设计容量与满容量单位/量级对齐
        boolean estimated = false;
        if (counter.isEmpty() && level > 0 && cFull <= 0 && cDes <= 0) {
            // 小米这类机型 /sys 里根本没有 charge_counter，改用 BatteryManager 的值（µAh）
            try {
                long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                if (cc > 0) counter = String.valueOf(cc);
            } catch (Throwable ignored) { }
        }
        if (cDes <= 0 && !counter.isEmpty() && level > 0) {
            // 没有设计容量：用「当前电量 µAh ÷ 电量百分比」估算一个
            long est = Math.round(mAh(counter) * 100.0 / level);
            if (est > 500 && est < 30000) {
                cDes = est;
                estimated = true;
            }
        }
        if (cDes > 0) {
            s.add("设计容量", estimated ? (cDes + " mAh（用当前电量估算）") : (cDes + " mAh"));
        }
        if (cFull > 0) s.add("当前满容量", cFull + " mAh");
        if (cDes > 0 && cFull > 0) {
            int pct = (int) Math.round(cFull * 100.0 / cDes);
            if (pct >= 40 && pct <= 160) {
                s.add("容量健康度", pct + " %（满容量 / 设计容量）");
            } else {
                s.add("容量健康度", "—（数据异常，可能是两条节点单位不同）");
            }
        }
        if (!full.isEmpty() || !des.isEmpty()) {
            s.add("容量原始值", "charge_full=" + full + "  charge_full_design=" + des
                    + (cDes != cDesRaw ? "（已按 " + cDes + " mAh 对齐量级）" : ""));
        }
        if (cycle.isEmpty() && cFull <= 0 && cDes <= 0) {
            java.util.Set<String> dirs = new java.util.LinkedHashSet<>();
            for (String k : ps.keySet()) {
                int i = k.indexOf('/');
                if (i > 0) dirs.add(k.substring(0, i));
            }
            s.add("容量 / 循环", "系统未开放（扫了 " + Math.max(1, dirs.size()) + " 个 power_supply 目录，"
                    + "都没有 charge_full / charge_full_design / cycle_count / charge_counter）");
        }
        String used = bySuffixKey(ps, "/charge_full");
        if (!used.isEmpty()) s.add("容量来源", "/sys/class/power_supply/" + used);
        if (spec != null) {
            JSONObject b = spec.optJSONObject("battery");
            if (b != null) {
                s.addIf("标称容量", b.optString("capacity", "") + " mAh");
                s.addIf("标称电芯", b.optString("cells", "") + " 芯");
                s.addIf("标称充电", b.optString("charge_w", "") + " W  ·  " + b.optString("protocol", ""));
            }
        }
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 存储 / 内存

    private static void storage(Context ctx, Result r) {
        Section s = new Section("存储与内存", r.model + " 存储 内存");
        try {
            StatFs df = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total = df.getTotalBytes(), free = df.getAvailableBytes();
            s.add("数据分区", gb(total) + " 总 / " + gb(free) + " 可用");
            s.add("已使用", gb(total - free) + "（" + (int) Math.round((total - free) * 100.0 / total) + "%）");
        } catch (Throwable t) {
            s.add("数据分区", "读取失败");
        }
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        s.add("运行内存", gb(mi.totalMem) + " 总 / " + gb(mi.availMem) + " 可用");
        s.add("可用比例", (int) Math.round(mi.availMem * 100.0 / mi.totalMem) + " %"
                + (mi.lowMemory ? "  ·  内存紧张" : ""));
        String mem = val(Shell.exec("grep MemTotal /proc/meminfo 2>/dev/null", 2000));
        if (mem.contains(":")) s.addIf("MemTotal", mem.split(":")[1].trim());
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 音频

    private static void audio(Context ctx, Result r, JSONObject spec) {
        Section s = new Section("声音与音频", r.model + " 扬声器 音频");
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        s.addIf("输出采样率", am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) + " Hz");
        s.addIf("每缓冲帧数", am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
        s.add("媒体音量", am.getStreamVolume(AudioManager.STREAM_MUSIC) + " / "
                + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        String sp = Shell.exec("dumpsys audio 2>/dev/null | grep -m1 -i 'isSpatializerEnabled'", 3000);
        if (sp != null && !sp.trim().isEmpty()) {
            s.add("空间音频", sp.contains("true") ? "已开启" : "关闭");
        }
        String ht = Shell.exec("dumpsys audio 2>/dev/null | grep -m1 -i 'HeadTrackingSupported'", 3000);
        if (ht != null && !ht.trim().isEmpty()) {
            s.add("头部追踪", ht.contains("true") ? "支持" : "不支持");
        }
        if (spec != null) {
            JSONObject au = spec.optJSONObject("audio");
            if (au != null) {
                s.addIf("标称立体声", au.optBoolean("stereo", false) ? "双扬（立体声）" : "单扬");
                s.addIf("标称空间音频", au.optBoolean("spatial", false) ? "支持" : "不支持");
            }
        }
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 摄像头

    private static void camera(Context ctx, Result r, JSONObject spec) {
        Section s = new Section("摄像头", r.model + " 摄像头 参数 传感器");
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        try {
            String[] ids = cm.getCameraIdList();
            s.add("数量", ids.length + " 颗（系统暴露）");
            for (String id : ids) {
                try {
                    CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                    Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                    Size sz = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                    float[] focal = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                    float[] ap = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
                    SizeF phys = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
                    Integer lvl = ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
                    android.util.Range<Integer>[] fps = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                    int maxFps = 0;
                    if (fps != null) for (android.util.Range<Integer> rr : fps) maxFps = Math.max(maxFps, rr.getUpper());
                    StringBuilder sb = new StringBuilder();
                    sb.append(facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT ? "前摄" : "后摄");
                    if (sz != null) sb.append(" · ").append(sz.getWidth()).append("×").append(sz.getHeight());
                    if (focal != null && focal.length > 0) sb.append(" · ").append(String.format(Locale.US, "%.2fmm", focal[0]));
                    if (ap != null && ap.length > 0) sb.append(" · f/").append(String.format(Locale.US, "%.1f", ap[0]));
                    if (phys != null) sb.append(" · 传感器 ").append(String.format(Locale.US, "%.1f×%.1fmm", phys.getWidth(), phys.getHeight()));
                    if (maxFps > 0) sb.append(" · 最高 ").append(maxFps).append("fps");
                    if (lvl != null) sb.append(" · ").append(camLevel(lvl));
                    s.add("ID " + id, sb.toString());
                } catch (Throwable t) {
                    s.add("ID " + id, "读取受限");
                }
            }
        } catch (Throwable t) {
            s.add("读取", "失败：" + t.getMessage());
        }
        if (spec != null) {
            JSONObject ca = spec.optJSONObject("camera");
            if (ca != null) {
                s.addIf("标称主摄", ca.optString("main", ""));
                s.addIf("标称超广角", ca.optString("ultrawide", ""));
                s.addIf("标称前摄", ca.optString("selfie", ""));
            }
        }
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 传感器

    private static void sensors(Context ctx, Result r) {
        Section s = new Section("传感器", r.model + " 传感器 型号");
        SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> list = sm.getSensorList(Sensor.TYPE_ALL);
        s.add("数量", list.size() + " 个");
        for (Sensor sen : list) {
            String hz = sen.getMinDelay() > 0
                    ? String.format(Locale.US, "%.0fHz", 1_000_000.0 / sen.getMinDelay()) : "on-change";
            s.add(typeName(sen.getType()),
                    sen.getName() + "  ·  " + sen.getVendor() + "  ·  " + hz
                            + "  ·  量程 " + trim(sen.getMaximumRange()) + (sen.isWakeUpSensor() ? "  ·  wakeup" : ""));
        }
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 网络

    private static void network(Context ctx, Result r) {
        Section s = new Section("网络与连接", r.model + " 网络 蓝牙 NFC");
        PackageManager pm = ctx.getPackageManager();
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            s.add("WiFi", wm == null ? "不支持" : (wm.isWifiEnabled() ? "已开启" : "已关闭"));
        } catch (Throwable ignored) { }
        ConnectivityManager cmgr = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkCapabilities nc = cmgr.getNetworkCapabilities(cmgr.getActiveNetwork());
            if (nc != null) {
                StringBuilder sb = new StringBuilder();
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) sb.append("WiFi");
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) sb.append(sb.length() > 0 ? " + 蜂窝" : "蜂窝");
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) sb.append(" + 以太网");
                if (nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) sb.append(" · 已联网");
                s.add("当前网络", sb.toString());
                s.add("下行估算", nc.getLinkDownstreamBandwidthKbps() / 1000 + " Mbps（系统估算）");
            } else {
                s.add("当前网络", "无");
            }
        } catch (Throwable ignored) { }
        TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
        try {
            String op = tm.getNetworkOperatorName();
            if (op != null && !op.isEmpty()) s.add("运营商", op);
        } catch (Throwable ignored) { }
        s.add("蓝牙", pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH) ? "支持" : "不支持");
        s.add("NFC", pm.hasSystemFeature(PackageManager.FEATURE_NFC) ? "支持" : "不支持");
        s.add("GPS", pm.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS) ? "支持" : "不支持");
        s.add("USB Host", pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST) ? "支持（OTG）" : "不支持");
        s.add("红外", pm.hasSystemFeature("android.hardware.consumerir") ? "支持" : "不支持");
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 安全

    private static void security(Context ctx, Result r) {
        Section s = new Section("安全与识别", r.model + " 指纹 解锁");
        PackageManager pm = ctx.getPackageManager();
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
            s.add("锁屏", km != null && km.isDeviceSecure() ? "已设置（密码 / 图案）" : "未设置");
        } catch (Throwable ignored) { }
        s.add("指纹", pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT) ? "支持" : "不支持");
        s.add("人脸", pm.hasSystemFeature(PackageManager.FEATURE_FACE) ? "支持" : "不支持");
        String se = val(Shell.exec("getenforce 2>/dev/null", 2000));
        if (!se.isEmpty()) s.add("SELinux", se);
        s.add("Root", Shell.hasRoot() ? "已获取" : "未获取");
        String adb = val(Shell.exec("settings get global adb_enabled 2>/dev/null", 2000));
        if (!adb.isEmpty()) s.add("USB 调试", "1".equals(adb) ? "已开启" : "未开启");
        r.sections.add(s);
    }

    // ---------------------------------------------------------------- 实测 vs 标称

    private static void compare(Context ctx, Result r, JSONObject spec, JSONObject socSpec, SocProbe.Info soc) {
        if (spec == null && socSpec == null) return;
        try {
            DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
            Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
            DisplayMetrics m = new DisplayMetrics();
            d.getRealMetrics(m);
            if (spec != null) {
                JSONObject sc = spec.optJSONObject("screen");
                if (sc != null && sc.has("hz")) {
                    float max = 0;
                    for (Display.Mode mo : d.getSupportedModes()) max = Math.max(max, mo.getRefreshRate());
                    r.compare.add(new String[]{"屏幕刷新率", String.format(Locale.US, "%.0fHz(支持)", max),
                            sc.optString("hz") + "Hz", max >= sc.optDouble("hz", 0) - 1 ? "✔" : "⚠"});
                }
                JSONObject b = spec.optJSONObject("battery");
                if (b != null && b.has("capacity")) {
                    String des = val(Shell.exec("cat /sys/class/power_supply/battery/charge_full_design 2>/dev/null", 2000));
                    long c = mAh(des);
                    String shown = c > 0 ? c + "mAh" : "n/a";
                    boolean ok = c <= 0 || Math.abs(c - b.optInt("capacity")) <= b.optInt("capacity") * 0.05;
                    r.compare.add(new String[]{"电池容量", shown, b.optString("capacity") + "mAh", ok ? "✔" : "⚠"});
                }
                JSONObject ca = spec.optJSONObject("camera");
                if (ca != null && ca.has("count")) {
                    int n = 0;
                    try {
                        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                        n = cm.getCameraIdList().length;
                    } catch (Throwable ignored) { }
                    r.compare.add(new String[]{"摄像头数", n + " 颗", ca.optString("count") + " 颗",
                            n == ca.optInt("count") ? "✔" : "⚠"});
                }
                String sName = spec.optString("name", "");
                if (!sName.isEmpty()) {
                    r.compare.add(new String[]{"机型", Build.MODEL, sName, "✔"});
                }
            }
            if (socSpec != null) {
                String sm = soc.market.isEmpty() ? soc.raw : soc.market;
                String sn = socSpec.optString("name", "");
                if (!sn.isEmpty()) {
                    String smN = sm.replace(" ", "").toLowerCase(Locale.US);
                    String snN = sn.replace(" ", "").toLowerCase(Locale.US);
                    r.compare.add(new String[]{"SoC", sm, sn,
                            (smN.contains(snN) || snN.contains(smN)) ? "✔" : "⚠"});
                }
                r.compare.add(new String[]{"核心构成", "见处理器", socSpec.optString("cores", ""), "ⓘ"});
            }
        } catch (Throwable ignored) { }
    }

    // ---------------------------------------------------------------- 工具

    private static String nz(String s) { return s == null || s.isEmpty() ? "—" : s; }

    private static String cap(String s) {
        if (s == null || s.isEmpty()) return "—";
        return s.substring(0, 1).toUpperCase(Locale.US) + s.substring(1);
    }

    private static String val(String s) { return s == null ? "" : s.trim(); }

    /**
     * 设计容量和满容量的单位经常不一致（比如一条是 µAh、一条被缩了 10 倍），
     * 拿满容量当基准把量级对齐；对不齐就原样返回，由调用方标「数据异常」。
     */
    private static long alignScale(long des, long full) {
        if (des <= 0 || full <= 0) return des;
        if (des >= full * 0.6 && des <= full * 1.6) return des;
        long[] mult = {10, 100, 1000};
        for (long m : mult) {
            long c = des * m;
            if (c >= full * 0.7 && c <= full * 1.4) return c;
        }
        long[] div = {10, 100, 1000};
        for (long d : div) {
            long c = des / d;
            if (c > 0 && c >= full * 0.7 && c <= full * 1.4) return c;
        }
        return des;
    }

    /** 按后缀取第一个非空值（节点可能在 battery/ 也可能在 bms/）。 */
    private static String bySuffix(java.util.LinkedHashMap<String, String> m, String suffix) {
        for (java.util.Map.Entry<String, String> e : m.entrySet()) {
            if (e.getKey().endsWith(suffix) && e.getValue() != null && !e.getValue().trim().isEmpty()) {
                return e.getValue().trim();
            }
        }
        return "";
    }

    private static String bySuffixKey(java.util.LinkedHashMap<String, String> m, String suffix) {
        for (String k : m.keySet()) if (k.endsWith(suffix)) return k;
        return "";
    }

    /** /sys 的电压单位各家不同：V / mV / µV 都见过，按量级判断。 */
    private static double toVolts(String raw) {
        double v = Math.abs(num(raw));
        if (v > 1000000) return v / 1000000.0;   // µV
        if (v > 1000) return v / 1000.0;         // mV
        return v;                                 // V
    }

    /** 电流同理：mA 或 µA。 */
    private static double toMilliAmp(String raw) {
        double v = Math.abs(num(raw));
        if (v > 10000) return v / 1000.0;        // µA
        return v;                                 // mA
    }

    private static double num(String raw) {
        try { return Double.parseDouble(raw.trim()); } catch (Throwable t) { return 0; }
    }

    private static String fmt(long ms) {
        if (ms <= 0) return "—";
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(ms));
    }

    private static String join(String[] a, String sep) {
        if (a == null || a.length == 0) return "—";
        StringBuilder sb = new StringBuilder();
        for (String s : a) { if (sb.length() > 0) sb.append(sep); sb.append(s); }
        return sb.toString();
    }

    private static String gb(long b) {
        return String.format(Locale.US, "%.1f GB", b / 1024.0 / 1024 / 1024);
    }

    private static String trim(float f) {
        if (f == Math.rint(f)) return String.valueOf((long) f);
        return String.format(Locale.US, "%.2f", f);
    }

    /** 满容量 / 设计容量常见单位是 µAh，超过 10 万就按 µAh 处理。 */
    private static long mAh(String raw) {
        try {
            long v = Long.parseLong(raw.trim());
            if (v > 100000) v = v / 1000;
            return v;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static String between(String s, String a, String b) {
        if (s == null) return "";
        int i = s.indexOf(a);
        if (i < 0) return "";
        i += a.length();
        int j = s.indexOf(b, i);
        if (j < 0) j = s.length();
        return s.substring(i, Math.min(j, s.length())).trim();
    }

    private static String colorModeName(int c) {
        switch (c) {
            case 0: return "默认";
            case 1: return "BT601-625";
            case 2: return "BT601-525";
            case 3: return "BT709";
            case 4: return "DCI-P3";
            case 5: return "sRGB";
            case 6: return "AdobeRGB";
            case 7: return "Display-P3";
            case 8: return "BT2020";
            case 9: return "BT2100-PQ";
            case 10: return "BT2100-HLG";
            default: return "模式" + c;
        }
    }

    private static String hdrName(int t) {
        switch (t) {
            case 1: return "HDR10";
            case 2: return "HDR10+";
            case 3: return "HLG";
            case 4: return "Dolby Vision";
            default: return "HDR" + t;
        }
    }

    private static String camLevel(int lvl) {
        switch (lvl) {
            case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY: return "LEGACY";
            case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED: return "LIMITED";
            case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL: return "FULL";
            case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3: return "LEVEL_3";
            case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL: return "EXTERNAL";
            default: return "级别" + lvl;
        }
    }

    private static String typeName(int t) {
        switch (t) {
            case Sensor.TYPE_ACCELEROMETER: return "加速度";
            case Sensor.TYPE_GYROSCOPE: return "陀螺仪";
            case Sensor.TYPE_MAGNETIC_FIELD: return "磁力";
            case Sensor.TYPE_LIGHT: return "光线";
            case Sensor.TYPE_PROXIMITY: return "距离";
            case Sensor.TYPE_GRAVITY: return "重力";
            case Sensor.TYPE_LINEAR_ACCELERATION: return "线性加速度";
            case Sensor.TYPE_ROTATION_VECTOR: return "旋转矢量";
            case Sensor.TYPE_ORIENTATION: return "方向";
            case Sensor.TYPE_PRESSURE: return "气压";
            case Sensor.TYPE_AMBIENT_TEMPERATURE: return "环境温度";
            case Sensor.TYPE_RELATIVE_HUMIDITY: return "湿度";
            case Sensor.TYPE_STEP_COUNTER: return "计步";
            case Sensor.TYPE_STEP_DETECTOR: return "步伐检测";
            case Sensor.TYPE_HEART_RATE: return "心率";
            case Sensor.TYPE_GAME_ROTATION_VECTOR: return "游戏旋转向量";
            case Sensor.TYPE_SIGNIFICANT_MOTION: return "显著运动";
            case Sensor.TYPE_ACCELEROMETER_UNCALIBRATED: return "未校准加速度";
            case Sensor.TYPE_GYROSCOPE_UNCALIBRATED: return "未校准陀螺";
            case Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED: return "未校准磁力";
            default: return "厂商私有 " + t;
        }
    }
}
