package com.dsh.cpuhud;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * 从手机本身取色。
 *
 * <p>两条路：
 * <ul>
 *   <li>Material You 动态配色（Android 12+，android.R.color.system_accent1_* / system_neutral1_*）；
 *       注意这只是「框架配色」，ColorOS / OriginOS 这类 ROM 的「主题色」不一定真的写进这套资源。</li>
 *   <li>从当前壁纸里抽主色 —— 国产 ROM 的主题色基本都是壁纸取色的结果，这条路反而最容易对上。</li>
 * </ul>
 */
public final class SysTheme {

    /** 语义色（正常 / 警告 / 错误 / 高亮橙），不同明暗主题各一套。 */
    private static final int[] SEM_DARK = {0xFF7CFFB2, 0xFFFFE066, 0xFFFF8F8F, 0xFFFFB25A};
    private static final int[] SEM_LIGHT = {0xFF12855C, 0xFFB26A00, 0xFFC62828, 0xFFD35400};

    private static int[] cacheWall, cacheMat;
    private static long tsWall, tsMat;

    private SysTheme() { }

    public static boolean isDark(Context c) {
        int m = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return m == Configuration.UI_MODE_NIGHT_YES;
    }

    /** a 往 b 靠 t（0=a，1=b）。 */
    public static int mix(int a, int b, float t) {
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        int r = Math.round(((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t);
        int g = Math.round(((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t);
        int bl = Math.round((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int frameworkColor(Context c, int id) {
        try {
            return c.getResources().getColor(id, null);
        } catch (Throwable t) {
            return -1;
        }
    }

    // ---------------------------------------------------------------- Material You

    /** Material You 调色板；系统不支持（<12）或全是基线紫时返回 null。 */
    public static synchronized int[] material(Context c) {
        long now = System.currentTimeMillis();
        if (cacheMat != null && now - tsMat < 5 * 60_000L) return cacheMat;
        int[] p = buildMaterial(c);
        cacheMat = p;
        tsMat = now;
        return p;
    }

    private static int[] buildMaterial(Context c) {
        if (Build.VERSION.SDK_INT < 31) return null;
        boolean dark = isDark(c);
        int accent = frameworkColor(c, dark ? android.R.color.system_accent1_200 : android.R.color.system_accent1_500);
        int n0 = frameworkColor(c, android.R.color.system_neutral1_0);
        int n50 = frameworkColor(c, android.R.color.system_neutral1_50);
        int n100 = frameworkColor(c, android.R.color.system_neutral1_100);
        int n200 = frameworkColor(c, android.R.color.system_neutral1_200);
        int n300 = frameworkColor(c, android.R.color.system_neutral1_300);
        int n400 = frameworkColor(c, android.R.color.system_neutral1_400);
        int n600 = frameworkColor(c, android.R.color.system_neutral1_600);
        int n700 = frameworkColor(c, android.R.color.system_neutral1_700);
        int n800 = frameworkColor(c, android.R.color.system_neutral1_800);
        int n900 = frameworkColor(c, android.R.color.system_neutral1_900);
        if (accent < 0 || n900 < 0) return null;
        // AOSP 基线紫（动态配色没生效时系统给的就是这几个值），当作“不支持”
        if (accent == 0xFFD0BCFF || accent == 0xFF6750A4) return null;

        if (dark) {
            return new int[]{n900, n800, mix(n900, n800, 0.5f),
                    n100, n50, n300, n400,
                    accent, SEM_DARK[0], SEM_DARK[1], SEM_DARK[2], SEM_DARK[3]};
        }
        return new int[]{n50, n0, n100,
                n900, n900, n700, n600,
                accent, SEM_LIGHT[0], SEM_LIGHT[1], SEM_LIGHT[2], SEM_LIGHT[3]};
    }

    // ---------------------------------------------------------------- 壁纸取色

    /** 从当前壁纸抽主色并生成整套配色；拿不到壁纸返回 null。 */
    public static synchronized int[] wallpaper(Context c) {
        long now = System.currentTimeMillis();
        if (cacheWall != null && now - tsWall < 5 * 60_000L) return cacheWall;
        int accent = wallpaperAccent(c);
        int[] p = accent == 0 ? null : fromAccent(accent, isDark(c));
        cacheWall = p;
        tsWall = now;
        return p;
    }

    /** 清缓存（换壁纸 / 改主题后点按钮用）。 */
    public static synchronized void invalidate() {
        cacheWall = null;
        cacheMat = null;
        tsWall = tsMat = 0;
    }

    private static Bitmap loadWallpaper(Context c) {
        WallpaperManager wm = WallpaperManager.getInstance(c);
        try {
            Drawable d = wm.getDrawable();
            if (d != null) {
                int w = Math.max(1, Math.min(256, d.getIntrinsicWidth()));
                int h = Math.max(1, Math.min(256, d.getIntrinsicHeight()));
                Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(bm);
                d.setBounds(0, 0, w, h);
                d.draw(cv);
                return bm;
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** 壁纸主色（按色相分桶，取饱和度高、占比大的那一桶）。 */
    public static int wallpaperAccent(Context c) {
        Bitmap src = loadWallpaper(c);
        if (src == null) return 0;
        try {
            int n = 48;
            Bitmap small = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(small);
            cv.drawBitmap(src, new android.graphics.Rect(0, 0, src.getWidth(), src.getHeight()),
                    new android.graphics.Rect(0, 0, n, n), new Paint());
            float[] hsv = new float[3];
            float[] wBin = new float[24];
            float[] rSum = new float[24], gSum = new float[24], bSum = new float[24];
            for (int y = 0; y < n; y++) {
                for (int x = 0; x < n; x++) {
                    int p = small.getPixel(x, y);
                    Color.colorToHSV(p, hsv);
                    float h = hsv[0], s = hsv[1], v = hsv[2];
                    if (v < 0.10f || v > 0.99f) continue;      // 太黑/太白
                    if (s < 0.16f) continue;                    // 灰调不计
                    int bin = (int) (h / 15f) % 24;
                    float w = s * s * (0.4f + 0.6f * (1f - Math.abs(v - 0.55f) / 0.55f));
                    wBin[bin] += w;
                    rSum[bin] += w * ((p >> 16) & 0xFF);
                    gSum[bin] += w * ((p >> 8) & 0xFF);
                    bSum[bin] += w * (p & 0xFF);
                }
            }
            int best = -1;
            float bw = 0;
            for (int i = 0; i < 24; i++) if (wBin[i] > bw) { bw = wBin[i]; best = i; }
            if (best < 0 || bw <= 0) return 0;
            int r = Math.round(rSum[best] / bw), g = Math.round(gSum[best] / bw), b = Math.round(bSum[best] / bw);
            int col = 0xFF000000 | (r << 16) | (g << 8) | b;
            // 稍微提一点饱和度 / 亮度，避免取出来发灰
            Color.colorToHSV(col, hsv);
            hsv[1] = Math.min(1f, Math.max(0.35f, hsv[1] * 1.15f));
            hsv[2] = Math.min(1f, Math.max(0.45f, hsv[2] * 1.05f));
            return Color.HSVToColor(hsv);
        } catch (Throwable t) {
            return 0;
        } finally {
            try { src.recycle(); } catch (Throwable ignored) { }
        }
    }

    /** 用一个主色生成整套 12 色（深色 / 浅色各一套推导规则）。 */
    public static int[] fromAccent(int accent, boolean dark) {
        if (dark) {
            return new int[]{
                    mix(accent, 0xFF000000, 0.90f),   // 背景
                    mix(accent, 0xFF000000, 0.82f),   // 卡片 / 按钮
                    mix(accent, 0xFF000000, 0.86f),   // 深层卡片
                    mix(accent, 0xFFFFFFFF, 0.88f),   // 正文
                    mix(accent, 0xFFFFFFFF, 0.95f),   // 标题
                    mix(accent, 0xFFFFFFFF, 0.58f),   // 次要文字
                    mix(accent, 0xFFFFFFFF, 0.42f),   // 提示文字
                    mix(accent, 0xFFFFFFFF, 0.28f),   // 强调色
                    SEM_DARK[0], SEM_DARK[1], SEM_DARK[2], SEM_DARK[3]};
        }
        return new int[]{
                mix(accent, 0xFFFFFFFF, 0.92f),
                mix(accent, 0xFFFFFFFF, 0.985f),
                mix(accent, 0xFFFFFFFF, 0.95f),
                mix(accent, 0xFF000000, 0.70f),
                mix(accent, 0xFF000000, 0.78f),
                mix(accent, 0xFF000000, 0.42f),
                mix(accent, 0xFF000000, 0.30f),
                mix(accent, 0xFF000000, 0.18f),
                SEM_LIGHT[0], SEM_LIGHT[1], SEM_LIGHT[2], SEM_LIGHT[3]};
    }
}
