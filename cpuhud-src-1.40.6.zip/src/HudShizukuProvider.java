package com.dsh.cpuhud;

import android.content.Context;
import android.content.pm.ProviderInfo;
import android.util.Log;

import rikka.shizuku.ShizukuProvider;

/**
 * 自带的 Shizuku provider：先打印系统实际给到的 ProviderInfo，再把 exported 兜成 true。
 * （这台机器上系统把清单里的 android:exported 读丢了，ShizukuProvider 会直接抛异常。）
 */
public class HudShizukuProvider extends ShizukuProvider {
    @Override
    public void attachInfo(Context context, ProviderInfo info) {
        Log.e("CPUHUD", "provider attach: exported=" + info.exported
                + " multiprocess=" + info.multiprocess
                + " enabled=" + info.enabled
                + " readPerm=" + info.readPermission
                + " authorities=" + info.authority);
        if (!info.exported) info.exported = true;
        super.attachInfo(context, info);
    }
}
