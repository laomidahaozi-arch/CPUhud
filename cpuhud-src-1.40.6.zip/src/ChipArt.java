package com.dsh.cpuhud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.BitmapShader;
import android.graphics.BlurMaskFilter;
import android.graphics.Matrix;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** 品牌芯片大图：按厂商配色画一块芯片，叠上厂商字样和型号（纯 Canvas，无图片资源）。 */
public class ChipArt extends View {
    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pWord = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.text.TextPaint pModel = new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final android.text.TextPaint pSpec = new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pArrow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pFade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF die = new RectF();

    private String word = "SoC", model = "", spec = "";
    private Bitmap logo;
    private Bitmap render;
    private String socModel;
    private int coreCount = 8;
    private Bitmap softFg, softBlur;
    private int softW, softH;
    private boolean monoWhite = false;
    private static final Map<String, Bitmap> CACHE = new HashMap<>();
    private static final Map<String, Bitmap> RCACHE = new HashMap<>();
    private static long customMtime = -1;

    public static void clearRenderCache() { RCACHE.clear(); }

    /** 已缓存到本地的图片文件名（供下载后写入）。 */
    public static String remoteFileName(String soc) {
        return "chip_remote_" + (soc == null ? "" : soc.toLowerCase(Locale.US).replace(" ", "")) + ".png";
    }
    private int c1 = 0xFF2C6BED, c2 = 0xFF5AD1FF;
    private boolean lightText = true;

    public ChipArt(Context c) {
        super(c);
        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(d(1f));
        pWord.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        pWord.setLetterSpacing(0.08f);
        pModel.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        pArrow.setTextAlign(Paint.Align.RIGHT);
        pArrow.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private float d(float v) {
        return getResources().getDisplayMetrics().density * v;
    }

    /** SoC 型号 → 市场名（MediaTek/Qualcomm 常见型号）。 */
    /** 内置芯片图清单：显示名, 资源 key。 */
    public static final String[][] BUILTIN = {
        {"天玑 9600 Pro", "dimensity_9600_pro"},
        {"天玑 9600M", "dimensity_9600m"},
        {"天玑 9500", "dimensity_9500"},
        {"天玑 9500s", "dimensity_9500s"},
        {"天玑 9400", "dimensity_9400"},
        {"天玑 9400+", "dimensity_9400_plus"},
        {"天玑 9400e", "dimensity_9400e"},
        {"天玑 9300", "dimensity_9300"},
        {"天玑 9300+", "dimensity_9300_plus"},
        {"天玑 9200", "dimensity_9200"},
        {"天玑 9200+", "dimensity_9200_plus"},
        {"天玑 9000", "dimensity_9000"},
        {"天玑 9000+", "dimensity_9000_plus"},
        {"天玑 8500 Ultra", "dimensity_8500_ultra"},
        {"天玑 8400 Ultra", "dimensity_8400_ultra"},
        {"天玑 7300 Ultra", "dimensity_7300_ultra"},
        {"天玑 8400", "mt6899"},
        {"天玑 8300", "mt6897"},
        {"天玑 7300", "mt6835"},
        {"Helio G99", "mt6789"},
        {"天玑 1200", "dimensity_1200"},
        {"天玑 1100", "dimensity_1100"},
        {"天玑 1000+", "dimensity_1000_plus"},
        {"天玑 1000", "dimensity_1000"},
        {"天玑 900", "dimensity_900"},
        {"天玑 8100", "dimensity_8100"},
        {"天玑 8200", "dimensity_8200"},
        {"天玑 7200", "dimensity_7200"},
        {"天玑 7050", "dimensity_7050"},
        {"麒麟 9000", "kirin_9000"},
        {"骁龙 888", "snapdragon_888"},
        {"骁龙 778G", "snapdragon_778g"},
        {"骁龙 7 Gen1", "snapdragon_7_gen1"},
        {"骁龙 7+ Gen2", "snapdragon_7_plus_gen2"},
        {"骁龙 6 Gen3", "snapdragon_6_gen3"},
        {"骁龙 6 Gen1", "snapdragon_6_gen1"},
        {"骁龙 8 至尊版 Gen6", "snapdragon_8_elite_gen6"},
        {"骁龙 8 超级至尊版 Gen6", "snapdragon_8_super_elite_gen6"},
        {"骁龙 8 Elite Gen5", "snapdragon_8_elite_gen5"},
        {"骁龙 8 Elite", "snapdragon_8_elite"},
        {"骁龙 8 Gen 3", "snapdragon_8_gen3"},
        {"骁龙 8 Gen 2", "snapdragon_8_gen2"},
        {"骁龙 8 Gen 1", "snapdragon_8_gen1"},
        {"骁龙 8s Gen 3", "snapdragon_8s_gen3"},
        {"骁龙 7+ Gen 3", "snapdragon_7_plus_gen3"},
        {"骁龙 8 系列", "snapdragon_8_series"},
        {"骁龙 7 系列", "snapdragon_7_series"},
    };

    /** 手动指定内置芯片图（空 = 自动）。 */
    public static void setLocal(String key) {
        LOCAL_KEY = key == null ? "" : key;
        RCACHE.clear();
    }
    private static String LOCAL_KEY = null;

    /** 供外部（下载器）使用：型号 → 市场名。 */
    /** 内置 key 是否属于同一厂商家族（防止手动选错成别家）。 */
    private static boolean sameFamily(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return true;
        java.util.function.Predicate<String> mtk =
                k -> k.startsWith("dimension") || k.startsWith("mt") || k.startsWith("helio");
        java.util.function.Predicate<String> qc = k -> k.startsWith("snapdragon");
        if (mtk.test(a) && mtk.test(b)) return true;
        if (qc.test(a) && qc.test(b)) return true;
        return a.equals(b);
    }

    public static String marketName(String soc) {
        // 交叉验证的结论最优先（含机型库）；没有再用远端表 / 内置表
        try {
            android.content.Context c = DataSource.appContext();
            if (c != null) {
                SocVerify.Verdict v = SocVerify.cached(c, soc);
                if (v != null && v.name != null && !v.name.isEmpty()) return v.name;
                DeviceSocMap.Hit h = DeviceSocMap.lookup(c, android.os.Build.MODEL,
                        android.os.Build.DEVICE);
                if (h != null) return h.soc;
            }
        } catch (Throwable ignored) { }
        return tableName(soc);
    }

    /**
     * 只查「型号码 → 名字」的表（远端增量表 → 内置 1013 条 → 老手写表）。
     * 不含机型库和交叉验证结论，SocProbe 打分时用这个，避免自己套自己。
     */
    public static String tableName(String soc) {
        String remote = SocMap.lookup(soc);      // 1) 远端增量表
        if (!remote.isEmpty()) return remote;
        String builtin = BuiltinMap.name(DataSource.appContext(), soc);   // 2) 内置大表
        if (builtin != null && !builtin.isEmpty()) return builtin;
        return friendly(soc == null ? "" : soc); // 3) 老的手写表
    }

    /** 市场名 → 资源文件名（天玑 9400+ → dimensity_9400_plus）。 */
    public static String assetKeyOf(String marketName, String soc) {
        String n = marketName == null ? "" : marketName.trim();
        if (n.isEmpty()) return "";
        String k = n.replace("超级至尊版", "super_elite").replace("至尊版", "elite")
                .replace("天玑", "dimensity").replace("骁龙", "snapdragon")
                .replace("瀚铠", "snapdragon").replace("+", "_plus")
                .replaceAll("\\s+", "_").toLowerCase(Locale.US)
                .replaceAll("[^a-z0-9_]", "");
        return k;
    }

    /** 主频（GHz），用于区分 9300 / 9300+ 这类同代码不同型号。 */
    private static float maxGhz = 0f;
    public void setMaxGhz(float g) { maxGhz = g; }

    private static String friendly(String s) {
        if (s == null) return "";
        String u = s.toUpperCase(Locale.US);
        switch (u) {
            case "MT6993": return "天玑 9500";
            case "MT6991": return maxGhz >= 3.70f ? "天玑 9400+" : "天玑 9400";
            case "MT6989": return maxGhz >= 3.35f ? "天玑 9300+" : "天玑 9300";
            case "MT6985": return "天玑 9200";
            case "MT6983": return "天玑 9000";
            case "MT6897": return "天玑 8300";
            case "MT6899": return "天玑 8400";
            case "MT6835": return "天玑 7300";
            case "MT6789": return "Helio G99";
            case "MT6886": return "天玑 930";
            case "MT6889": return "天玑 1000+";
            case "MT6885": return "天玑 1000";
            case "MT6891": return "天玑 1100";
            case "MT6893": return "天玑 1200";
            case "MT6877": return "天玑 900";
            case "MT6878": return "天玑 7200";
            case "MT6855": return "天玑 7050";
            case "MT6895": return "天玑 8200";
            case "MT6880": return "天玑 8100";
            case "SM8750": return "骁龙 8 Elite";
            case "SM8850": return "骁龙 8 Elite Gen5";
            case "SM8950": return "骁龙 8 至尊版 Gen6";
            case "SM8975": return "骁龙 8 超级至尊版 Gen6";
            case "SUN2": return "骁龙 8 Elite Gen5";
            case "SUN": return "骁龙 8 Elite";
            case "PINEAPPLE": return "骁龙 8 Gen3";
            case "KALAMA": return "骁龙 8 Gen2";
            case "KAILUA": return "骁龙 8+ Gen1";
            case "TARO": return "骁龙 8 Gen1";
            case "CROW": return "骁龙 7 Gen3";
            case "SM8635": return "骁龙 8s Gen3";
            case "SM6450": return "骁龙 6 Gen1";
            case "SM6225": return "骁龙 680";
            case "SM6115": return "骁龙 662";
            case "SM7125": return "骁龙 720G";
            case "SM7150": return "骁龙 730G";
            case "SM8735": return "骁龙 8s Gen4";
            case "SM8650": return "骁龙 8 Gen3";
            case "SM8550": return "骁龙 8 Gen2";
            case "SM8475": return "骁龙 8+ Gen1";
            case "SM8450": return "骁龙 8 Gen1";
            case "SM7675": return "骁龙 7+ Gen3";
            case "SM7635": return "骁龙 7s Gen3";
            case "SM7550": return "骁龙 7 Gen3";
            case "SM7325": return "骁龙 778G";
            case "SM6375": return "骁龙 695";
            case "SM7475": return "骁龙 7 Gen1";
            default: return "";
        }
    }

    public void bind(String soc, String gpu, int cores) {
        String s = soc == null ? "" : soc.toUpperCase(Locale.US);
        socModel = soc;
        coreCount = cores;
        String nice = friendly(soc);
        String manualName = getContext().getSharedPreferences("chipdl", android.content.Context.MODE_PRIVATE)
                .getString("localName", "");
        if (!manualName.isEmpty()) nice = manualName;
        if (nice.isEmpty() && s != null && (s.contains("KIRIN") || s.contains("EXYNOS") || s.contains("TENSOR"))) {
            nice = soc;                                  // 麒麟等：型号本身当市场名
        }
        model = soc == null || soc.isEmpty() ? "未知芯片" : (nice.isEmpty() ? soc : nice);
        String key = null;
        monoWhite = false;
        if (s.startsWith("MT")) {              // MediaTek
            logo = null; c1 = 0xFF1A1206; c2 = 0xFFB35A00;
            key = null;
        }
        // 先定厂商配色与 logo
        if (s.startsWith("MT") || s.contains("DIMENSITY") || s.contains("HELIO")) {
            word = "MEDIATEK"; c1 = 0xFF14100A; c2 = 0xFFFF9F1C; key = "mediatek";
        } else if (s.startsWith("SM") || s.startsWith("SDM") || s.contains("SNAPDRAGON")
                || s.equals("SUN") || s.equals("PINEAPPLE") || s.equals("KALAMA")
                || s.equals("KAILUA") || s.equals("TARO") || s.equals("CROW")) {
            word = "Snapdragon"; c1 = 0xFF160A0C; c2 = 0xFFC8102E; key = "snapdragon";
        } else if (s.contains("EXYNOS")) {
            word = "SAMSUNG Exynos"; c1 = 0xFF0A0F1E; c2 = 0xFF2F5BD0; key = "samsung";
        } else if (s.contains("KIRIN")) {
            word = "HUAWEI Kirin"; c1 = 0xFF140A0A; c2 = 0xFFC0392B; key = null;
        } else if (s.contains("XRING") || s.equals("O1") || s.startsWith("O1 ") || s.startsWith("O2")) {
            word = "XRING"; c1 = 0xFF120A1A; c2 = 0xFF7B4FD8; key = "xiaomi";
        } else if (s.contains("TENSOR")) {
            word = "Google Tensor"; c1 = 0xFF0A1210; c2 = 0xFF1A73E8; key = null;
        } else if (s.contains("APPLE") || s.startsWith("A1") || s.startsWith("A2") || s.startsWith("M1")
                || s.startsWith("M2") || s.startsWith("M3") || s.startsWith("M4")) {
            word = "Apple silicon"; c1 = 0xFF101214; c2 = 0xFF5A5A60; key = "apple"; monoWhite = true;
        } else if (s.contains("UNISOC") || s.startsWith("SC9")) {
            word = "UNISOC"; c1 = 0xFF080F1C; c2 = 0xFF2F6BE0; key = null;
        } else if (s.contains("RK") || s.contains("ROCKCHIP")) {
            word = "Rockchip"; c1 = 0xFF0A1016; c2 = 0xFF2E7FB8; key = null;
        } else {
            word = "SoC"; c1 = 0xFF10151C; c2 = 0xFF2F6B8A; key = null;
        }
        loadLogo(key);
        loadRender(key);

        softFg = null; softBlur = null; softW = 0; softH = 0;
        spec = (soc == null ? "" : soc + " · ") + cores + " 核"
                + (gpu != null && !gpu.equals("—") ? " · " + gpu : "");
        invalidate();
    }

    /** 厂商芯片渲染图（assets/chips/&lt;key&gt;_chip.png 或用户自定义）。 */
    /** 强制自绘（不加载任何图片）。 */
    public static void setDrawMode(Context c, boolean on) {
        c.getSharedPreferences("chipdl", Context.MODE_PRIVATE)
                .edit().putBoolean("chipDraw", on).apply();
        RCACHE.clear();
    }

    public static boolean isDrawMode(Context c) {
        return c.getSharedPreferences("chipdl", Context.MODE_PRIVATE).getBoolean("chipDraw", false);
    }

    private void loadRender(String key) {
        render = null;
        if (getContext().getSharedPreferences("chipdl", Context.MODE_PRIVATE)
                .getBoolean("chipDraw", false)) {
            return;                                  // 自绘模式：不加载图片
        }
        String socKey = socModel == null ? null : socModel.toLowerCase(Locale.US).replace(" ", "");
        if (LOCAL_KEY == null) {
            LOCAL_KEY = getContext().getSharedPreferences("chipdl", android.content.Context.MODE_PRIVATE)
                    .getString("localKey", "");
        }
        if (LOCAL_KEY != null && !LOCAL_KEY.isEmpty()) {
        }
        if (LOCAL_KEY != null && !LOCAL_KEY.isEmpty()) {
            Bitmap lk = RCACHE.get("local_" + LOCAL_KEY);
            if (lk != null) { render = lk; return; }
            Bitmap lb = loadAsset("chips/" + LOCAL_KEY + "_chip.webp", "chips/" + LOCAL_KEY + "_chip.png");
            if (lb != null) { RCACHE.put("local_" + LOCAL_KEY, lb); render = lb; return; }
        }
        java.io.File custom = new java.io.File(getContext().getFilesDir(), "chip_custom.png");
        if (custom.exists()) {
            long mt = custom.lastModified();
            Bitmap c = RCACHE.get("custom");
            if (c == null || mt != customMtime) {           // 文件变了就重新解码
                c = BitmapFactory.decodeFile(custom.getAbsolutePath());
                if (c != null) { RCACHE.put("custom", c); customMtime = mt; }
            }
            if (c != null) { render = c; return; }
        }
        // 1) 联网下载缓存的图（最高优先，点过就用它）
        java.io.File remote = new java.io.File(getContext().getFilesDir(),
                "chip_remote_" + socKey + ".png");
        if (remote.exists()) {
            Bitmap rc = RCACHE.get("remote");
            if (rc == null) {
                rc = BitmapFactory.decodeFile(remote.getAbsolutePath());
                if (rc != null) RCACHE.put("remote", rc);
            }
            if (rc != null) { render = rc; return; }
        }
        // 2) 市场名图（天玑 9400 → dimensity_9400_chip.webp）
        String mKey = assetKeyOf(friendly(socModel), socModel);
        if (mKey != null && !mKey.isEmpty()) {
            Bitmap mck = RCACHE.get(mKey);
            if (mck != null) { render = mck; return; }
            Bitmap mb = loadAsset("chips/" + mKey + "_chip.webp", "chips/" + mKey + "_chip.png");
            if (mb != null) { RCACHE.put(mKey, mb); render = mb; return; }
            if (mKey.startsWith("snapdragon")) {                 // 精确图没有 → 按系列回落
                String series = mKey.contains("8") ? "snapdragon_8_series"
                        : mKey.contains("7") ? "snapdragon_7_series" : null;
                if (series != null) {
                    Bitmap sb = loadAsset("chips/" + series + "_chip.webp", "chips/" + series + "_chip.png");
                    if (sb != null) { RCACHE.put(series, sb); render = sb; return; }
                }
                Bitmap logo2 = loadAsset("chips/snapdragon.png", "chips/snapdragon_chip.webp");
                if (logo2 != null) { RCACHE.put("snapdragon_logo", logo2); render = logo2; return; }
            }
        }
        // 3) 具体型号图（如 mt6993_chip.png）
        if (socKey != null) {
            Bitmap mc = RCACHE.get(socKey);
            if (mc != null) { render = mc; return; }
            Bitmap bm = loadAsset("chips/" + socKey + "_chip.webp", "chips/" + socKey + "_chip.png");
            if (bm != null) { RCACHE.put(socKey, bm); render = bm; return; }
        }
        // 4) 厂商通用图
        if (key == null) return;
        Bitmap cached = RCACHE.get(key);
        if (cached != null) { render = cached; return; }
        Bitmap bm2 = loadAsset("chips/" + key + "_chip.webp", "chips/" + key + "_chip.png");
        if (bm2 != null) { RCACHE.put(key, bm2); render = bm2; }
    }

    /** 缩图 + 多次 box blur，得到「虚化底」。 */
    private static Bitmap blurred(Bitmap src, int maxSide, int radius) {
        float sc = Math.min(1f, maxSide / (float) Math.max(src.getWidth(), src.getHeight()));
        int w = Math.max(2, (int) (src.getWidth() * sc));
        int h = Math.max(2, (int) (src.getHeight() * sc));
        Bitmap small = Bitmap.createScaledBitmap(src, w, h, true);
        int[] pix = new int[w * h];
        small.getPixels(pix, 0, w, 0, 0, w, h);
        int[] out = new int[w * h];
        for (int pass = 0; pass < 2; pass++) {
            // 横向
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int a = 0, r = 0, g = 0, b = 0, n = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int xx = Math.max(0, Math.min(w - 1, x + k));
                        int c = pix[y * w + xx];
                        a += (c >>> 24); r += (c >> 16) & 0xFF; g += (c >> 8) & 0xFF; b += c & 0xFF; n++;
                    }
                    out[y * w + x] = ((a / n) << 24) | ((r / n) << 16) | ((g / n) << 8) | (b / n);
                }
            }
            // 纵向
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int a = 0, r = 0, g = 0, b = 0, n = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int yy = Math.max(0, Math.min(h - 1, y + k));
                        int c = out[yy * w + x];
                        a += (c >>> 24); r += (c >> 16) & 0xFF; g += (c >> 8) & 0xFF; b += c & 0xFF; n++;
                    }
                    pix[y * w + x] = ((a / n) << 24) | ((r / n) << 16) | ((g / n) << 8) | (b / n);
                }
            }
        }
        small.recycle();
        return Bitmap.createBitmap(pix, w, h, Bitmap.Config.ARGB_8888);
    }

    /** 四边等距羽化：圆角矩形 mask 模糊后做 DST_IN，四条边淡出一致。 */
    private Bitmap feathered(Bitmap src, int w, int h) {
        if (w <= 2 || h <= 2) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setFilterBitmap(true);
        cv.drawBitmap(src, null, new RectF(0, 0, w, h), p);

        int mw = Math.max(12, w / 3), mh = Math.max(12, h / 3);
        Bitmap mask = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888);
        Canvas mc = new Canvas(mask);
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
        mp.setColor(0xFFFFFFFF);
        float inset = mw * 0.05f;
        mc.drawRoundRect(new RectF(inset, inset, mw - inset, mh - inset), mw * 0.18f, mh * 0.18f, mp);
        Bitmap soft = blurred(mask, Math.max(mw, mh), 2);
        mask.recycle();

        Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
        dp.setFilterBitmap(true);
        dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        cv.drawBitmap(soft, null, new RectF(0, 0, w, h), dp);
        return out;
    }

    /** 生成「边缘渐隐」的副本：中心实体，边缘 alpha 渐变到 0，避免生硬的方块边界。 */
    private Bitmap softCopy(Bitmap src, int w, int h, float solidTo, int alpha) {
        if (w <= 1 || h <= 1) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setFilterBitmap(true);
        p.setAlpha(alpha);
        cv.drawBitmap(src, null, new RectF(0, 0, w, h), p);
        Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
        mask.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.72f,
                new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0xF0FFFFFF, 0x00000000},
                new float[]{0f, solidTo, 0.97f, 1f}, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        cv.drawRect(0, 0, w, h, mask);
        return out;
    }

    private void buildSoft(int w, int h) {
        if (softFg != null && softW == w && softH == h) return;
        softW = w; softH = h;
        softFg = softCopy(render, w, h, 0.80f, 255);      // 前景软边（外圈 20% 渐隐）
        softBlur = blurred(render, 140, 4);               // 虚化底
    }

    private Bitmap loadAsset(String first, String second) {
        for (String path : new String[]{first, second}) {
            try (InputStream in = getContext().getAssets().open(path)) {
                Bitmap bm = BitmapFactory.decodeStream(in);
                if (bm != null) return bm;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private void loadLogo(String key) {
        if (key == null) { logo = null; return; }
        Bitmap cached = CACHE.get(key);
        if (cached != null) { logo = cached; return; }
        try (InputStream in = getContext().getAssets().open("chips/" + key + ".png")) {
            Bitmap bm = BitmapFactory.decodeStream(in);
            if (bm != null) {
                CACHE.put(key, bm);
                logo = bm;
                return;
            }
        } catch (Throwable ignored) { }
        logo = null;
    }

    /** 实时软边：BitmapShader + BlurMaskFilter，每帧由绘制管线计算，不缓存。 */
    /** 型号 → 稳定的伪随机种子（同一颗芯片每次画出来都一样）。 */
    private int seed() {
        String s = (socModel == null ? "" : socModel) + "|" + model;
        int h = s.hashCode();
        return h ^ (h >>> 16);
    }

    /** 色相小幅偏移：同厂商保持同一色系，不同型号能看出差异。 */
    private static int tint(int color, float deg) {
        float[] hsv = new float[3];
        android.graphics.Color.colorToHSV(color, hsv);
        hsv[0] = (hsv[0] + deg + 360f) % 360f;
        return android.graphics.Color.HSVToColor(android.graphics.Color.alpha(color), hsv);
    }

    /**
     * 没有官方图时的自绘芯片。
     * 引脚 5~8 根/边、色相 ±14°、核心按 大核/中核/小核 分组画成块，
     * 所以 8 核的 天玑 9500 和 8 核的 骁龙 8 Gen3 也只有颜色和细节不同 —— 核心数不同则布局明显不同。
     */
    /**
     * 同核心数下的几种常见排布，按型号哈希选一种。
     * 总数恒等于真实核心数，所以图不会撒谎；但排布会随芯片不同而变。
     */
    private static int[] coreGroups(int n, int seed) {
        int[][] pool;
        switch (n) {
            case 12: pool = new int[][]{{4, 4, 4}, {2, 2, 8}, {4, 8}}; break;
            case 10: pool = new int[][]{{1, 3, 6}, {2, 2, 6}, {4, 6}, {2, 8}}; break;
            case 9:  pool = new int[][]{{1, 3, 5}, {4, 5}, {2, 2, 5}}; break;
            case 8:  pool = new int[][]{{1, 3, 4}, {2, 2, 4}, {4, 4}, {1, 2, 5}, {2, 6}}; break;
            case 6:  pool = new int[][]{{2, 4}, {6}, {2, 2, 2}, {1, 1, 4}}; break;
            case 4:  pool = new int[][]{{4}, {2, 2}, {1, 3}}; break;
            default: {
                int[] one = new int[]{Math.max(n, 1)};
                return one;
            }
        }
        return pool[seed % pool.length];
    }

    private void drawGenericDie(Canvas c, float w, float h) {
        int sd = seed();
        int rnd = Math.abs(sd);
        int pinN = 5 + rnd % 4;                       // 每边 5~8 根引脚
        float hue = (rnd % 29) - 14f;                 // ±14° 色相偏移
        float cw = w * 0.34f, ch = Math.min(h * 0.68f, w * 0.34f);
        float cx = w - cw * 0.60f - d(10), cy = h * 0.5f;
        float half = ch / 2f;
        RectF body = new RectF(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2);
        int accent = tint((c2 & 0x00FFFFFF) | 0xFF000000, hue);

        // 引脚
        pLine.setColor((accent & 0x00FFFFFF) | (0x55000000 + 0));  // 低透明度
        pLine.setColor((accent & 0x00FFFFFF) | 0x66000000);
        pLine.setStrokeWidth(d(1.4f));
        for (int i = 0; i < pinN; i++) {
            float off = -half + ch * (i + 0.5f) / pinN;
            c.drawLine(cx - cw / 2, cy + off, cx - cw / 2 - d(7), cy + off, pLine);
            c.drawLine(cx + cw / 2, cy + off, cx + cw / 2 + d(7), cy + off, pLine);
        }

        // 本体
        pFill.setColor(0x22000000);
        c.drawRoundRect(body, d(6), d(6), pFill);
        pLine.setColor((accent & 0x00FFFFFF) | 0xCC000000);
        pLine.setStrokeWidth(d(1.6f));
        c.drawRoundRect(body, d(6), d(6), pLine);
        pLine.setStrokeWidth(d(1.4f));

        // 核心簇：总数 = 真实核心数，排布由型号决定（手选别的芯片时布局会跟着变）
        int n = coreCount <= 0 ? 8 : Math.min(coreCount, 12);
        int[] groups = coreGroups(n, rnd);

        float pad = d(4);
        float innerTop = body.top + pad, innerBot = body.bottom - pad;
        float rowH = (innerBot - innerTop) / groups.length;
        for (int gi = 0; gi < groups.length; gi++) {
            int count = groups[gi];
            float top = innerTop + rowH * gi;
            float boxW = (body.width() - pad * 2) / Math.max(count, 1);
            float boxH = Math.min(rowH - d(2), boxW);
            float y = top + (rowH - boxH) / 2f;
            for (int i = 0; i < count; i++) {
                float x = body.left + pad + boxW * i + d(0.8f);
                float bw = Math.max(boxW - d(1.6f), d(2));
                int alpha = gi == 0 ? 0xE6 : (gi == 1 ? 0x99 : 0x55);
                pFill.setShader(null);
                pFill.setColor((accent & 0x00FFFFFF) | (alpha << 24));
                c.drawRoundRect(new RectF(x, y, x + bw, y + boxH), d(1.5f), d(1.5f), pFill);
            }
        }
        pFill.setShader(null);
    }

    private void drawChipRealtime(Canvas c, RectF dst) {
        BitmapShader sh = new BitmapShader(render, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        Matrix m = new Matrix();
        m.setRectToRect(new RectF(0, 0, render.getWidth(), render.getHeight()), dst, Matrix.ScaleToFit.FILL);
        sh.setLocalMatrix(m);

        float r = d(16);
        // 1) 外圈光晕（更大模糊、低透明度）
        Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        halo.setShader(sh);
        halo.setAlpha(60);
        halo.setMaskFilter(new BlurMaskFilter(d(22), BlurMaskFilter.Blur.NORMAL));
        float g = d(10);
        c.drawRoundRect(new RectF(dst.left - g, dst.top - g, dst.right + g, dst.bottom + g), r + g, r + g, halo);
        halo.setShader(null);

        // 2) 主体：羽化边缘由 BlurMaskFilter 实时生成
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setShader(sh);
        p.setColorFilter(monoWhite ? new PorterDuffColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN) : null);
        p.setMaskFilter(new BlurMaskFilter(d(9), BlurMaskFilter.Blur.NORMAL));
        c.drawRoundRect(dst, r, r, p);
        p.setMaskFilter(null);
        p.setColorFilter(null);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        rect.set(0, 0, w, h);
        float r = d(18);
        // 深色底
        pFill.setShader(null);
        pFill.setColor(c1);
        c.drawRoundRect(rect, r, r, pFill);
        // 品牌光晕（右下角）
        pFill.setShader(new RadialGradient(w * 0.86f, h * 1.05f, Math.max(w, h) * 0.95f,
                new int[]{(c2 & 0x00FFFFFF) | 0xB0000000, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(rect, r, r, pFill);
        pFill.setShader(null);

        // 电路走线
        pLine.setColor(0x33FFFFFF);
        for (int i = 1; i <= 3; i++) {
            float y = h * i / 4f;
            c.drawLine(w * 0.55f, y, w - d(10), y, pLine);
        }
        for (int i = 1; i <= 2; i++) {
            float x = w * 0.55f + (w - w * 0.55f) * i / 3f;
            c.drawLine(x, d(10), x, h - d(10), pLine);
        }

        // 自绘芯片：引脚数、核心簇布局、色相都由型号决定 —— 每颗芯片长得不一样
        if (render == null) drawGenericDie(c, w, h);

        // 芯片渲染图（优先）：贴右侧，高度占卡片 88%
        if (render != null) {
            float ih = h * 0.90f;
            float iw = render.getWidth() * (ih / render.getHeight());
            float maxIw = w * 0.50f;
            if (iw > maxIw) { iw = maxIw; ih = render.getHeight() * (iw / render.getWidth()); }
            float left = w - iw - d(14);
            float top = (h - ih) / 2f;
            RectF dst = new RectF(left, top, left + iw, top + ih);
            drawChipRealtime(c, dst);
        } else if (logo != null) {
            float maxW = w * 0.56f;
            float maxH = h * 0.34f;
            float sc = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
            float lw = logo.getWidth() * sc, lh = logo.getHeight() * sc;
            float left = d(18), top = h * 0.14f;
            pFill.setColorFilter(monoWhite ? new PorterDuffColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN) : null);
            c.drawBitmap(logo, null, new RectF(left, top, left + lw, top + lh), pFill);
            pFill.setColorFilter(null);
        } else {
            pWord.setColor(0xFFFFFFFF);
            pWord.setTextSize(h * 0.155f);
            c.drawText(word, d(16), h * 0.30f, pWord);
        }

        // 型号（有渲染图时左侧区域变窄，超长省略）
        float textMaxW = w - d(32);
        if (render != null) textMaxW = w * 0.56f;
        pModel.setColor(0xFFFFFFFF);
        pModel.setTextSize(Math.min(h * 0.27f, w * (render != null ? 0.062f : 0.082f)));
        CharSequence shownModel = android.text.TextUtils.ellipsize(model, pModel, textMaxW, android.text.TextUtils.TruncateAt.END);
        c.drawText(shownModel.toString(), d(16), h * 0.68f, pModel);

        // 规格
        pSpec.setColor(0xCCFFFFFF);
        pSpec.setTextSize(h * 0.115f);
        CharSequence shownSpec = android.text.TextUtils.ellipsize(spec, pSpec, textMaxW, android.text.TextUtils.TruncateAt.END);
        c.drawText(shownSpec.toString(), d(16), h * 0.86f, pSpec);

    }
}
