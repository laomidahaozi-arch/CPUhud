package com.dsh.cpuhud;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 不依赖容器的本地采样：所有命令都经 Shizuku 以 shell 身份执行。
 * 逻辑与 server.mjs 对齐（同一套命令、同一套解析），便于两边互相兜底。
 */
public class LocalSampler {
    private static final String[] THERMAL = {
            "echo \"###T\"",
            "dumpsys thermalservice 2>/dev/null",
            "echo \"###F\"",
            "for d in /sys/devices/system/cpu/cpufreq/policy*; do echo \"$d $(cat $d/related_cpus 2>/dev/null) $(cat $d/scaling_cur_freq 2>/dev/null) $(cat $d/cpuinfo_max_freq 2>/dev/null)\"; done",
            "echo \"###C\"",
            "head -1 /proc/stat",
            "echo \"###M\"",
            "grep -E '^(MemTotal|MemAvailable):' /proc/meminfo",
            "echo \"###B\"",
            "dumpsys battery 2>/dev/null",
            "echo \"###S2\"",
            "__S2__",
            "echo \"###N\"",
            "ls /sys/class/power_supply/ 2>/dev/null | tr '\\n' ' '; echo",
            "echo \"###P\"",
            "cat /sys/class/power_supply/battery/status 2>/dev/null",
            "echo \"###G\"",
            "dumpsys SurfaceFlinger --timestats -dump 2>/dev/null | awk '/^layerName = /{n=substr($0,13);next} /^totalFrames = /{if(n==\"\")print \"G\",$3; else print \"L\",n,$3; next} /^droppedFrames = /{if(n!=\"\")print \"D\",n,$3; next} /^jankyFrames = /{if(n!=\"\")print \"K\",n,$3; else print \"J\",$3; next} /^displayRefreshRate = /{print \"R\",$3} /^statsStart = /{print \"T\",$3} /^statsEnd = /{print \"U\",$3}'",
            "echo \"###G2\"",
            "dumpsys gfxinfo __PKG__ framestats 2>/dev/null | tail -60",
            "echo \"###A\"",
            "dumpsys activity activities 2>/dev/null | grep -m1 -E 'mResumedActivity|topResumedActivity'",
            "echo \"###W\"",
            "dumpsys window 2>/dev/null | grep -m1 \"mCurrentFocus\"",
            "echo \"###R\"",
            "dumpsys window displays 2>/dev/null | grep -m1 \"init=\"",
            "echo \"###E\"",
    };
    // 快速路径：常见机型就是 battery / bms 的几个文件，6 次 cat 就够
    private static final String S2_FAST =
            "for f in /sys/class/power_supply/battery/voltage_now /sys/class/power_supply/battery/current_now "
          + "/sys/class/power_supply/bms/voltage_now /sys/class/power_supply/bms/current_now; "
          + "do echo \"S $f $(cat $f 2>/dev/null)\"; done";
    // 全量路径：节点名不一样的机型（比如 vivo）才用，每 10 次采一次
    private static final String S2_SCAN =
            "for f in /sys/class/power_supply/*/voltage_now /sys/class/power_supply/*/current_now "
          + "/sys/class/power_supply/*/voltage_avg /sys/class/power_supply/*/current_avg "
          + "/sys/class/power_supply/*/current_now /sys/class/power_supply/bq_bms/current_now "
          + "/sys/class/power_supply/mtk_battery/current_avg; "
          + "do echo \"S $f $(cat $f 2>/dev/null)\"; done";

    /** 已经探测到具体文件时只 cat 这几个（1 次 fork），否则用通用快扫/全扫。 */
    private String s2Body(boolean scan) {
        if (voltFile != null) {
            String list = voltFile + (curFile != null ? " " + curFile : "");
            return "for f in " + list + "; do echo \"S $f $(cat $f 2>/dev/null)\"; done";
        }
        return scan ? S2_SCAN : S2_FAST;
    }

    /** 列出 power_supply 下所有含 current/volt 的节点，挑一组最像“实际值”的文件缓存起来。 */
    private void probePower() {
        if (System.currentTimeMillis() - lastProbe < 20000) return;
        lastProbe = System.currentTimeMillis();
        String out = Shell.exec(
                "ls /sys/class/power_supply/*/* 2>/dev/null | grep -Ei 'current|volt'", 4000);
        if (out == null) return;
        String bestV = null, bestC = null;
        int bestRankV = 99, bestRankC = 99;
        StringBuilder cand = new StringBuilder();
        for (String raw : out.split("\n")) {
            String path = raw.trim();
            if (!path.startsWith("/sys/class/power_supply/")) continue;
            String[] seg = path.split("/");
            if (seg.length < 6) continue;
            String dev = seg[4].toLowerCase();
            String name = seg[5].toLowerCase();
            if (name.matches(".*(limit|max|min|design|term|step|offset|cali|threshold|state|count|avg_lim).*")) continue;
            if (cand.length() < 220) cand.append(dev).append('/').append(name).append(' ');
            int rank = devRank(dev);
            if (name.contains("volt")) {
                if (rank < bestRankV) { bestRankV = rank; bestV = path; }
            } else if (name.contains("current")) {
                if (rank < bestRankC) { bestRankC = rank; bestC = path; }
            }
        }
        candList = cand.toString().trim();
        if (bestV != null) voltFile = bestV;
        if (bestC != null) curFile = bestC;
    }

    /** 其他机型兜底：有的 ROM 的 thermalservice 不给 HAL 数据，但 /sys/class/thermal 可读。 */
    private void probeThermalZones() {
        if (System.currentTimeMillis() - lastThermalProbe < 60000) return;
        lastThermalProbe = System.currentTimeMillis();
        String out = Shell.exec(
                "for z in /sys/class/thermal/thermal_zone*/type; do d=${z%/type}; "
              + "echo \"$(cat $z 2>/dev/null) $(cat $d/temp 2>/dev/null)\"; done", 6000);
        if (out == null) return;
        zoneTemps.clear();
        double allMax = -1;
        for (String line : out.split("\n")) {
            String[] p2 = line.trim().split("\\s+");
            if (p2.length < 2) continue;
            double v;
            try { v = Double.parseDouble(p2[1]); } catch (Exception e) { continue; }
            if (v > 1000) v = v / 1000.0;            // m°C → °C
            if (v <= -20 || v >= 200) continue;
            String t = p2[0].toLowerCase();
            allMax = Math.max(allMax, v);
            if (t.contains("cpu") || t.contains("tsens") || t.contains("ap_") || t.contains("cluster")
                    || t.contains("silver") || t.contains("gold") || t.contains("prime") || t.contains("core")
                    || t.contains("mtkts") || t.contains("cpuss") || t.contains("cpu-")) {
                if (!zoneTemps.containsKey("CPU")) zoneTemps.put("CPU", v);
            } else if (t.contains("gpu") || t.contains("kgsl") || t.contains("adreno") || t.contains("mtktsgpu")) {
                if (!zoneTemps.containsKey("GPU")) zoneTemps.put("GPU", v);
            } else if (t.contains("soc") || t.contains("qti") || t.contains("modem") || t.contains("ddr")
                    || t.contains("mtktsbts") || t.contains("soc_therm")) {
                if (!zoneTemps.containsKey("SOC")) zoneTemps.put("SOC", v);
            } else if (t.contains("batt") || t.startsWith("bat") || t.contains("chg") || t.contains("charger")) {
                if (!zoneTemps.containsKey("BATTERY")) zoneTemps.put("BATTERY", v);
            } else if (t.contains("skin") || t.contains("back") || t.contains("shell") || t.contains("quiet")
                    || t.contains("xo_therm") || t.contains("pa_therm")) {
                if (!zoneTemps.containsKey("SKIN")) zoneTemps.put("SKIN", v);
            }
        }
    }

    private static int devRank(String dev) {
        if (dev.equals("battery")) return 0;
        if (dev.equals("bms") || dev.equals("mtk_battery") || dev.equals("mtk-gauge")) return 1;
        if (dev.equals("fg_common") || dev.equals("meter") || dev.equals("mcu")) return 2;
        if (dev.equals("usb") || dev.equals("ac") || dev.contains("chg")) return 8;
        return 5;
    }

    /** 轻量命令：去掉 SurfaceFlinger 与 gfxinfo 两个重活，用于输出被截断时的重试。 */
    private String buildLite(boolean scan) {
        StringBuilder sb = new StringBuilder();
        String body = s2Body(scan);
        for (String p : THERMAL) {
            if (p == null) continue;
            if (p.contains("SurfaceFlinger") || p.contains("gfxinfo")) continue;
            if (sb.length() > 0) sb.append("; ");
            sb.append("__S2__".equals(p) ? body : p);
        }
        return sb.toString();
    }

    private String buildCmd(boolean rot, boolean scan) {
        String[] parts = rot ? CMD_ROT_PARTS : THERMAL;
        String body = s2Body(scan);
        StringBuilder sb = new StringBuilder();
        String pkg = lastPkg == null ? "" : lastPkg;
        // 省 CPU：gfxinfo 只在每 3 次采样跑一次（TimeStats 现在一直开着，基本用不到它）；
        // 前台包名已知且新鲜时，跳过 activity / window 两次 dumpsys。
        boolean needGfx = (sampleN % 3 == 0);
        boolean needFg = pkg.isEmpty() || (System.currentTimeMillis() - lastPkgTs > 15000);
        for (String p : parts) {
            if (p == null) continue;
            if (!needGfx && p.contains("gfxinfo")) continue;
            if (!needFg && (p.contains("dumpsys activity activities") || p.contains("mCurrentFocus"))) continue;
            String one = p;
            if (one.contains("__PKG__")) {
                if (pkg.isEmpty()) continue;          // 还没拿到前台包名，跳过 gfxinfo
                one = one.replace("__PKG__", pkg);
            }
            if (sb.length() > 0) sb.append("; ");
            sb.append("__S2__".equals(one) ? body : one);
        }
        return sb.toString();
    }

    private static final String CMD = join(THERMAL);   // 兼容旧引用
    private static final String[] CMD_ROT_PARTS = appendRotation();

    private static String[] appendRotation() {
        // 复制除最后一个 ###E 之外的全部命令，替换成「窗口信息 + ###E」，避免数组里留 null 洞
        String[] a = new String[THERMAL.length + 1];
        System.arraycopy(THERMAL, 0, a, 0, THERMAL.length - 1);
        a[THERMAL.length - 1] = "dumpsys window displays 2>/dev/null | grep -m1 \"init=\"";
        a[THERMAL.length] = "echo \"###E\"";
        return a;
    }

    private static String join(String[] parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(p);
        }
        return sb.toString();
    }

    private static final Pattern TEMP = Pattern.compile("mValue=(-?[\\d.]+),\\s*mType=(\\d+),\\s*mName=(\\w+)");
    private static final Pattern FPS_LINE = Pattern.compile("^(L|K|D|G|J|R) (.+)$");

    private long prevTotal = -1, prevIdle = -1;
    private long prevTs = 0, prevGlobal = -1, lastClear = 0;
    private long globalJank = 0, prevGlobalJank = 0;
    private final Map<String, Long> prevFrames = new HashMap<>(), prevJank = new HashMap<>(), prevDropped = new HashMap<>();
    private double lastFps = 0, lastJank = 0;
    private boolean lastLandscape = false;
    private long tick = 0;
    private final List<Float> histFps = new ArrayList<>(), histW = new ArrayList<>();
    private String lastPkg = "";
    private long lastPkgTs = 0;
    private int sampleN = 0;

    /** 最近一次识别到的前台包名（诊断用）。 */
    public String fgPkg() { return lastPkg == null ? "" : lastPkg; }
    private final java.util.Map<String, double[]> lastTemps = new java.util.HashMap<>();
    private int lastStatus = -1;
    public int emptySamples = 0;
    private double lastVolt = -1, lastMa = 0;
    private String voltFile = null, curFile = null, candList = "";
    private long lastProbe = 0;
    private long lastThermalProbe = 0;
    private final java.util.Map<String, Double> zoneTemps = new java.util.HashMap<>();
    private String powerInfo = "";
    private String powerDevs = "";
    public String powerInfo() { return powerInfo; }
    public String powerDevs() { return powerDevs; }
    private static final String[] THERMAL_LABEL = {"正常", "轻度", "中度", "严重", "危急", "紧急", "关机保护"};

    public long lastMs = 0;
    public long lastParseMs = 0;
    public String diag() { return "ms=" + lastMs + " parse=" + lastParseMs + " bytes=" + lastBytes + " lite=" + lightRetry; }
    public long lastBytes = 0;
    public int lightRetry = 0;
    public String lastFpsDebug = "";
    public double lastDispRate = 0;
    private long lastEnable = 0;
    public String lastPwrDebug = "";
    private long prevCounterUah = 0, prevCounterTs = 0;
    private final java.util.List<Double> curHist = new java.util.ArrayList<>();

    /** 采一帧；Shizuku 不可用或失败返回 null。 */
    public Snapshot sample() {
        tick++;
        long now = System.currentTimeMillis();
        long t0 = System.currentTimeMillis();
        if (curFile == null || voltFile == null) probePower();
        boolean scan = tick % 10 == 0 || lastVolt <= 0;   // 读不到电压/每 10 次才做全量扫描
        long t1 = System.currentTimeMillis();
        String out = Shell.exec(buildCmd(tick % 4 == 0, scan), 6000);
        if (out == null || out.length() < 600) {          // 明显被截断 → 换轻量命令重试
            lightRetry++;
            String lite = Shell.exec(buildLite(scan), 5000);
            if (lite != null && lite.length() > (out == null ? 0 : out.length())) out = lite;
        }
        if (out == null) out = Shell.exec(buildCmd(false, false), 6000);
        lastMs = System.currentTimeMillis() - t0;
        sampleN++;
        lastBytes = out == null ? 0 : out.length();
        if (out == null || out.trim().isEmpty()) return null;
        // TimeStats 在 Android 14+ 默认是关的，关着时 --timestats -dump 输出为空 →
        // 全局帧数/逐层帧数全都取不到，FPS 只能掉到 gfxinfo 兜底（前台包名拿不到就是 0）。
        if (lastEnable == 0 || now - lastEnable > 180000) {
            lastEnable = now;
            Shell.exec("dumpsys SurfaceFlinger --timestats -enable >/dev/null 2>&1; echo ok", 3000);
        }
        if (now - lastClear > 45000) {
            lastClear = now;
            Shell.exec("dumpsys SurfaceFlinger --timestats -clear >/dev/null 2>&1; echo ok", 3000);
        }
        try {
            return parse(out, System.currentTimeMillis());
        } catch (Throwable t) {
            return null;
        }
    }

    Snapshot parse(String out, long ts) {   // package-private: 便于离线用真实 dump 验证
        List<String> t = section(out, "T"), f = section(out, "F"), c = section(out, "C"),
                m = section(out, "M"), b = section(out, "B"), p = section(out, "P"),
                g = section(out, "G"), r = section(out, "R"), g2 = section(out, "G2");
        Snapshot s = new Snapshot();
        s.ts = ts;

        // 温度：HAL 段优先，其次 Cached 段；本轮没拿到就沿用上一次（避免显示 0.0 闪烁）
        java.util.Map<String, double[]> seen = new java.util.HashMap<>();  // name -> {value, priority}
        boolean inHal = false;
        for (String line : t) {
            if (line.contains("Current temperatures from HAL")) { inHal = true; continue; }
            if (line.contains("Current cooling devices from HAL")) { inHal = false; continue; }
            if (line.contains("Cached temperatures")) { inHal = false; continue; }
            Matcher mt = TEMP.matcher(line);
            if (!mt.find()) continue;
            double v = Double.parseDouble(mt.group(1));
            if (v <= -20 || v >= 200) continue;
            String name = mt.group(3);
            double prio = inHal ? 2 : 1;
            double[] cur = seen.get(name);
            if (cur == null || prio > cur[1]) seen.put(name, new double[]{v, prio});
        }
        if (seen.isEmpty()) emptySamples++;
        lastTemps.putAll(seen);
        for (String k : new String[]{"CPU", "GPU", "SOC", "SKIN", "BATTERY", "POWER_AMPLIFIER"}) {
            double[] v = lastTemps.get(k);
            setTemp(s, k, v == null ? -1 : v[0]);
        }
        if (s.cpu < 0 || s.gpu < 0) {           // HAL 没数据时退到 /sys/class/thermal
            probeThermalZones();
            if (s.cpu < 0 && zoneTemps.containsKey("CPU")) s.cpu = zoneTemps.get("CPU");
            if (s.gpu < 0 && zoneTemps.containsKey("GPU")) s.gpu = zoneTemps.get("GPU");
            if (s.soc < 0 && zoneTemps.containsKey("SOC")) s.soc = zoneTemps.get("SOC");
            if (s.skin < 0 && zoneTemps.containsKey("SKIN")) s.skin = zoneTemps.get("SKIN");
            if (s.battTemp < 0 && zoneTemps.containsKey("BATTERY")) s.battTemp = zoneTemps.get("BATTERY");
        }
        for (String line : t) {
            Matcher mt = Pattern.compile("Thermal Status:\\s*(\\d+)").matcher(line);
            if (mt.find()) { s.thermalStatus = Integer.parseInt(mt.group(1)); lastStatus = s.thermalStatus; break; }
        }
        if (s.thermalStatus < 0) s.thermalStatus = Math.max(0, lastStatus);
        s.thermalLabel = THERMAL_LABEL[Math.min(Math.max(s.thermalStatus, 0), THERMAL_LABEL.length - 1)];

        List<String> cores = new ArrayList<>();
        List<Double> curs = new ArrayList<>(), maxs = new ArrayList<>();
        for (String line : f) {
            String[] tok = line.trim().split("\\s+");
            if (tok.length < 4) continue;
            try {
                double max = Double.parseDouble(tok[tok.length - 1]) / 1000;
                double cur = Double.parseDouble(tok[tok.length - 2]) / 1000;
                if (max <= 0) continue;
                StringBuilder cn = new StringBuilder();
                for (int i = 1; i < tok.length - 2; i++) { if (cn.length() > 0) cn.append(' '); cn.append(tok[i]); }
                cores.add(cn.toString()); curs.add(cur); maxs.add(max);
            } catch (NumberFormatException ignored) { }
        }
        s.cores = cores.toArray(new String[0]);
        s.cur = new double[curs.size()];
        s.max = new double[maxs.size()];
        for (int i = 0; i < curs.size(); i++) {
            s.cur[i] = curs.get(i);
            s.max[i] = maxs.get(i);
            s.freqAvg += curs.get(i);
            if (curs.get(i) > s.freqMax) s.freqMax = curs.get(i);
        }
        if (curs.size() > 0) s.freqAvg /= curs.size();

        for (String line : c) {
            if (!line.startsWith("cpu ")) continue;
            String[] tok = line.trim().split("\\s+");
            long idle = 0, total = 0;
            for (int i = 1; i < tok.length; i++) {
                try {
                    long v = Long.parseLong(tok[i]);
                    if (i == 4 || i == 5) idle += v;
                    total += v;
                } catch (NumberFormatException ignored) { }
            }
            if (prevTotal > 0) {
                long dt = total - prevTotal, di = idle - prevIdle;
                if (dt > 0) s.load = Math.max(0, Math.min(100, (1.0 - (double) di / dt) * 100));
            }
            prevTotal = total; prevIdle = idle;
        }

        double memTotal = 0, memAvail = 0;
        for (String line : m) {
            String[] tok = line.trim().split("\\s+");
            if (tok.length < 2) continue;
            double kb = Double.parseDouble(tok[1]) / 1048576.0;
            if (line.startsWith("MemTotal")) memTotal = kb; else if (line.startsWith("MemAvailable")) memAvail = kb;
        }
        s.memTotal = round1(memTotal);
        s.memUsed = round1(memTotal - memAvail);
        s.memPct = memTotal > 0 ? round1((memTotal - memAvail) / memTotal * 100) : 0;

        int status = 0;
        double dumpVoltMv = 0, dumpCurrent = 0;
        for (String line : b) {
            String[] tok = line.trim().split("\\s+");
            if (tok.length >= 2) {
                if (tok[0].startsWith("level:")) { try { s.battLevel = Double.parseDouble(tok[1]); } catch (Exception ignored) { } continue; }
                if (tok[0].startsWith("status:")) { try { status = Integer.parseInt(tok[1]); } catch (Exception ignored) { } continue; }
                if (tok[0].startsWith("voltage:")) {
                    try {
                        double v = Double.parseDouble(tok[1]);
                        dumpVoltMv = v < 100 ? v * 1000.0 : v;      // "4" → 4V；"4097" → mV
                    } catch (Exception ignored) { }
                    continue;
                }
            }
            // 有的 ROM 会打印 "current now: 289" / "Battery current : 268" 这类行
            String lower = line.toLowerCase();
            if (lower.contains("battery current")) {                 // OPLUS 段：更接近真实值
                Matcher bm2 = Pattern.compile("(-?\\d+(?:\\.\\d+)?)").matcher(line.substring(Math.max(0, lower.indexOf("battery current"))));
                if (bm2.find()) { try { dumpCurrent = Math.abs(Double.parseDouble(bm2.group(1))) ; } catch (Exception ignored) { } continue; }
            }
            if (lower.contains("current") && !lower.contains("max") && !lower.contains("charging current")) {
                Matcher cm = Pattern.compile("(-?\\d+(?:\\.\\d+)?)").matcher(line.substring(Math.max(0, lower.indexOf("current"))));
                if (cm.find()) {
                    try { dumpCurrent = Double.parseDouble(cm.group(1)); } catch (Exception ignored) { }
                }
            }
        }

        // dumpsys battery 的 charge counter（µAh）差分算电流
        long counterUah = 0;
        for (String line : b) {
            String l = line.toLowerCase();
            if (l.contains("charge counter")) {
                Matcher cm2 = Pattern.compile("(\\d+)").matcher(line);
                if (cm2.find()) {
                    try { counterUah = Long.parseLong(cm2.group(1)); } catch (Exception ignored) { }
                }
            }
        }
        double vMv = 0, iMa = 0;
        String battStatus = "";
        int numIdx = 0;
        for (String line : p) {
            String v = line.trim();
            if (v.isEmpty()) continue;
            if (v.matches("-?\\d+")) {
                double d = Double.parseDouble(v);
                if (numIdx == 0) vMv = d; else if (numIdx == 1) iMa = d;
                numIdx++;
            } else if (battStatus.isEmpty()) {
                battStatus = v.toLowerCase();
            }
        }

        // 新机（如 vivo）的 power_supply 节点布局不同：扫描所有设备，按优先级挑一个能用的
        StringBuilder devList = new StringBuilder();
        for (String line : section(out, "N")) devList.append(line.trim());
        powerDevs = devList.toString();
        java.util.Map<String, double[]> devs = new java.util.LinkedHashMap<>();  // dev -> {voltMv, curMa}
        for (String line : section(out, "S2")) {
            String t2 = line.trim();
            if (!t2.startsWith("S ")) continue;
            String[] parts = t2.split("\\s+");
            if (parts.length < 3) continue;
            String path = parts[1];
            double val;
            try { val = Double.parseDouble(parts[2]); } catch (Exception e) { continue; }
            if (Math.abs(val) < 1) continue;                      // 文件不存在/空
            String[] seg = path.split("/");
            if (seg.length < 6) continue;
            String dev = seg[4];
            String file = seg[5];
            double[] cur = devs.get(dev);
            if (cur == null) { cur = new double[2]; devs.put(dev, cur); }
            String fl = file.toLowerCase();
            if (fl.contains("volt")) { if (cur[0] == 0) cur[0] = val; }
            else if (fl.contains("current")) { if (cur[1] == 0) cur[1] = val; }
        }
        String picked = null;
        for (String pref : new String[]{"battery", "bms", "mtk-battery", "Battery"}) {
            double[] dv = devs.get(pref);
            if (dv != null && dv[0] > 0) { picked = pref; break; }
        }
        if (picked == null) {
            for (java.util.Map.Entry<String, double[]> e : devs.entrySet()) {
                if (e.getValue()[0] > 0) { picked = e.getKey(); break; }
            }
        }
        double sysVoltMv = 0, sysCur = 0;
        if (picked != null) {
            double[] dvv = devs.get(picked);
            sysVoltMv = dvv[0];
            sysCur = dvv[1];
        }
        if (sysVoltMv > 0) vMv = sysVoltMv;                       // 优先用扫描到的
        double iRaw = iMa > 0 ? iMa : sysCur;
        if (iRaw == 0) iRaw = dumpCurrent;
        if (iRaw == 0 && counterUah > 0) {                    // 最后：电荷计数差分
            long nowTs = System.currentTimeMillis();
            if (prevCounterUah > 0 && nowTs > prevCounterTs) {
                double dh = (nowTs - prevCounterTs) / 3600000.0;
                double dUah = Math.abs(counterUah - prevCounterUah);
                double ma = dUah / 1000.0 / dh;
                if (dh > 0.001 && ma > 0 && ma < 8000) iRaw = ma;
            }
            prevCounterUah = counterUah;
            prevCounterTs = nowTs;
        }
        if (iRaw != 0 && Math.abs(iRaw) > 20000) iRaw = iRaw / 1000.0;   // µA → mA
        if (iRaw != 0) {                                    // 中位数平滑，抗瞬间尖峰
            curHist.add(Math.abs(iRaw));
            while (curHist.size() > 7) curHist.remove(0);
            java.util.List<Double> sorted = new java.util.ArrayList<>(curHist);
            java.util.Collections.sort(sorted);
            iRaw = sorted.get(sorted.size() / 2);
        }
        if (vMv <= 0 && dumpVoltMv > 0) vMv = dumpVoltMv;         // dumpsys battery 的 voltage(mV)
        iMa = iRaw;

        if (picked == null) {
            powerInfo = "无电流节点（设备: " + (powerDevs.isEmpty() ? "空" : powerDevs) + "）"
                    + (candList.isEmpty() ? "" : " | 候选: " + candList);
        } else {
            double dispCur = Math.abs(sysCur) > 20000 ? sysCur / 1000.0 : sysCur;
            powerInfo = picked + " v=" + (long) sysVoltMv + "mV i=" + Math.round(dispCur) + "mA"
                    + (curFile != null ? "  [" + curFile.substring(curFile.indexOf("power_supply/") + 13) + "]" : "");
        }

        double voltV = vMv > 100 ? vMv / 1000.0 : (vMv > 0 && vMv < 10 ? vMv : lastVolt);
        if (voltV > 0) lastVolt = voltV;
        s.voltV = voltV > 0 ? round3(voltV) : -1;
        s.powerCharging = battStatus.startsWith("charging") || battStatus.startsWith("full") || status == 2;
        s.charging = s.powerCharging;
        double ma = Math.abs(iMa);
        if (ma > 0) lastMa = ma; else ma = lastMa;      // 负值（放电）也是有效值
        s.currentMa = s.powerCharging ? Math.abs(ma) : -Math.abs(ma);
        s.powerW = s.voltV > 0 && ma > 0 ? round2(s.voltV * s.currentMa / 1000.0) : 0;

        boolean landscape = lastLandscape;
        for (String line : r) {
            Matcher mt = Pattern.compile("cur=(\\d+)x(\\d+)").matcher(line);
            if (mt.find()) { landscape = Integer.parseInt(mt.group(1)) > Integer.parseInt(mt.group(2)); lastLandscape = landscape; }
        }

        // 帧率
        double dispRate = 0;
        long statsStart = 0, statsEnd = 0;
        long gFrames = -1;
        Map<String, Long> frames = new HashMap<>(), jank = new HashMap<>(), dropped = new HashMap<>();
        List<String> order = new ArrayList<>();
        for (String line : g) {
            String v = line.trim();
            if (v.length() < 3) continue;
            char k = v.charAt(0);
            String rest = v.substring(2);
            if (k == 'R') { try { dispRate = Math.max(dispRate, Double.parseDouble(rest)); } catch (NumberFormatException ignored) { } continue; }
            if (k == 'G') { try { long val = Long.parseLong(rest.trim()); if (val > gFrames) gFrames = val; } catch (NumberFormatException ignored) { } continue; }
            if (k == 'J') { try { globalJank = Math.max(globalJank, Long.parseLong(rest.trim())); } catch (NumberFormatException ignored) { } continue; }
            if (k == 'T') { try { statsStart = Long.parseLong(rest.trim()); } catch (NumberFormatException ignored) { } continue; }
            if (k == 'U') { try { statsEnd = Long.parseLong(rest.trim()); } catch (NumberFormatException ignored) { } continue; }
            int sp = rest.lastIndexOf(' ');
            if (sp <= 0) continue;
            String name = rest.substring(0, sp);
            long val;
            try { val = Long.parseLong(rest.substring(sp + 1)); } catch (NumberFormatException e) { continue; }
            if (k == 'L') { Long old = frames.get(name); if (old == null || val > old) frames.put(name, val); if (!order.contains(name)) order.add(name); }
            else if (k == 'K') { Long old = jank.get(name); if (old == null || val > old) jank.put(name, val); }
            else if (k == 'D') { Long old = dropped.get(name); if (old == null || val > old) dropped.put(name, val); }
            else if (k == 'G') { if (val > gFrames) gFrames = val; }
            else if (k == 'J') { globalJank = Math.max(globalJank, val); }
        }
        int flagsIdx = -1;
        // —— gfxinfo framestats 兜底数据 ——
        double gfxFps = -1, gfxFt = 0, gfxJank = 0;
        try {
            int idx = -1;
            long first = -1, last = -1;
            int nFrames = 0, jankFrames = 0;
            for (String line : g2) {
                String l = line.trim();
                if (l.startsWith("Flags,") || l.contains("IntendedVsync")) {
                    String[] head = l.split(",");
                    for (int i = 0; i < head.length; i++) {
                        if (head[i].trim().equalsIgnoreCase("IntendedVsync")) idx = i;
                        if (head[i].trim().equalsIgnoreCase("Flags")) flagsIdx = i;
                    }
                    continue;
                }
                if (idx < 0 || !l.matches("^[0-9,]+.*")) continue;
                String[] cols = l.split(",");
                if (cols.length <= Math.max(idx, flagsIdx)) continue;
                long tsv;
                try { tsv = Long.parseLong(cols[idx].trim()); } catch (Exception e) { continue; }
                if (tsv <= 0) continue;
                if (first < 0) first = tsv;
                last = tsv;
                nFrames++;
                if (flagsIdx >= 0) {
                    try {
                        long fl = Long.parseLong(cols[flagsIdx].trim());
                        if ((fl & 1L) != 0) jankFrames++;      // FLAG_MISSED_VSYNC
                    } catch (Exception ignored) { }
                }
            }
            if (nFrames >= 3 && last > first) {
                double sec = (last - first) / 1e9;
                if (sec > 0.05) {
                    gfxFps = (nFrames - 1) / sec;
                    gfxFt = sec * 1000.0 / (nFrames - 1);
                    gfxJank = jankFrames * 1000.0 / (sec * 1000);   // 每秒卡顿次数
                }
            }
        } catch (Throwable ignored) { }
        if (gFrames < 0) gFrames = 0;
        double globalFps = 0;
        double dtOut = 0;
        double fps = -1, jankRate = 0;
        String layer = "";
        if (prevTs > 0 && ts - prevTs > 300) {
            double dt = (ts - prevTs) / 1000.0;
            dtOut = dt;
            if (prevGlobal >= 0 && gFrames >= prevGlobal) {
                globalFps = (gFrames - prevGlobal) / dt;
            } else if (gFrames > 0) {
                globalFps = -1;              // 计数器刚被 clear，这一帧不算
            }
            double best = -1;
            for (String name : order) {
                if (name.matches(".*(StatusBar|NavigationBar|Wallpaper|NotificationShade|InputMethod|ImeContainer|Splash Screen).*")) continue;
                Long fr = frames.get(name), pv = prevFrames.get(name);
                if (fr == null || pv == null || fr < pv) continue;
                double v = (fr - pv) / dt;
                if (v > best) { best = v; layer = name; }
            }
            // 1) 全局帧数增量（最稳）
            if (globalFps > 3) {
                fps = Math.round(Math.min(globalFps, (dispRate > 0 ? dispRate : 120) * 1.3) * 10) / 10.0;
                layer = "全屏出帧";
                s.fpsSrc = "global";
            }
            // 2) 逐层（只在明显高于全局时采用，比如游戏独占图层）
            if (best > (fps > 0 ? fps * 1.25 : 5)) {
                fps = Math.round(Math.min(best, (dispRate > 0 ? dispRate : 120) * 1.3) * 10) / 10.0;
                Long kj = jank.get(layer), pj = prevJank.get(layer);
                if (kj != null && pj != null && kj >= pj) jankRate = Math.round((kj - pj) / dt * 10) / 10.0;
                s.fpsSrc = "layer";
            }
            // 3) 窗口平均（计数器刚重置或首帧时兜底）
            if (fps <= 3 && statsEnd > statsStart && gFrames > 0) {
                double win = (statsEnd - statsStart);
                if (win > 1) {
                    fps = Math.round(Math.min(gFrames / win, (dispRate > 0 ? dispRate : 120) * 1.3) * 10) / 10.0;
                    layer = "窗口平均";
                    s.fpsSrc = "window";
                }
            }
            if (fps < 5 && gfxFps > 0) {                      // 最后：前台应用的 framestats
                fps = Math.round(Math.min(gfxFps, (dispRate > 0 ? dispRate : 120) * 1.3) * 10) / 10.0;
                jankRate = Math.round(gfxJank * 10) / 10.0;
                layer = "gfxinfo";
                s.fpsSrc = "gfxinfo";
            }
        }
        prevFrames.clear(); prevFrames.putAll(frames);
        prevJank.clear(); prevJank.putAll(jank);
        prevDropped.clear(); prevDropped.putAll(dropped);
        prevTs = ts; prevGlobal = gFrames;

        if (fps > 0) { lastFps = fps; lastJank = jankRate; }   // 0 不算有效样本
        s.fps = fps >= 0 ? fps : lastFps;
        s.fpsJank = lastJank;
        s.dispRate = dispRate > 0 ? dispRate : 120;
        lastDispRate = s.dispRate;
        s.fpsLayer = layer;
        s.fpsFt = s.fps > 0 ? round1(1000.0 / s.fps) : 0;
        lastPwrDebug = String.format(java.util.Locale.US, "pwr=%.2fW i=%.0fmA v=%.3fV cur=%s volt=%s",
                s.powerW, s.currentMa, s.voltV,
                curFile == null ? "null" : curFile.substring(curFile.lastIndexOf('/') + 1),
                voltFile == null ? "null" : voltFile.substring(voltFile.lastIndexOf('/') + 1));
        lastFpsDebug = String.format(java.util.Locale.US,
                "fps=%.1f src=%s globalRaw=%.1f g=%d prevG=%d dt=%.2f",
                s.fps, s.fpsSrc, globalFps, gFrames, prevGlobal, dtOut);

        Matcher pm = Pattern.compile("(?:VRI-)?(?:SurfaceView\\[)?([a-zA-Z][\\w.]*)/").matcher(layer);
        if (pm.find()) lastPkg = pm.group(1);
        if (lastPkg == null || lastPkg.isEmpty()) {           // 老 ROM 从 activity 里取
            for (String line : section(out, "A")) {
                Matcher am2 = Pattern.compile("u\\d+ ([a-zA-Z0-9_.]+)/").matcher(line);
                if (am2.find()) { lastPkg = am2.group(1); break; }
            }
        }
        if (lastPkg == null || lastPkg.isEmpty()) {           // 新 ROM：mCurrentFocus 更靠谱
            for (String line : section(out, "W")) {
                Matcher wm2 = Pattern.compile("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").matcher(line);
                if (wm2.find()) { lastPkg = wm2.group(1); break; }
            }
        }
        s.pkg = lastPkg;
        if (lastPkg != null && !lastPkg.isEmpty()) lastPkgTs = ts;

        s.gameOn = landscape;
        s.gameReason = landscape ? "landscape" : "";

        histFps.add((float) Math.max(0, s.fps));
        histW.add((float) s.powerW);
        while (histFps.size() > 90) histFps.remove(0);
        while (histW.size() > 90) histW.remove(0);
        s.histFps = toArray(histFps);
        s.histW = toArray(histW);
        return s;
    }

    private void setTemp(Snapshot s, String name, double v) {
        if ("CPU".equals(name)) s.cpu = v;
        else if ("GPU".equals(name)) s.gpu = v;
        else if ("SOC".equals(name)) s.soc = v;
        else if ("SKIN".equals(name)) s.skin = v;
        else if ("BATTERY".equals(name)) s.battTemp = v;
        else if ("POWER_AMPLIFIER".equals(name)) s.pa = v;
    }

    private static List<String> section(String out, String tag) {
        List<String> res = new ArrayList<>();
        boolean on = false;
        for (String line : out.split("\n")) {
            String l = line.trim();
            if (l.equals("###" + tag)) { on = true; continue; }
            if (l.matches("^###[A-Z]$")) { on = false; continue; }
            if (on) res.add(line);
        }
        return res;
    }

    private static float[] toArray(List<Float> l) {
        float[] a = new float[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    private static double round1(double v) { return Math.round(v * 10) / 10.0; }
    private static double round2(double v) { return Math.round(v * 100) / 100.0; }
    private static double round3(double v) { return Math.round(v * 1000) / 1000.0; }
}
