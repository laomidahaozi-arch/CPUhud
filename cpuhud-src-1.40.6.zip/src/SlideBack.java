package com.dsh.cpuhud;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;

/**
 * 二级页面的「从左边缘拖拽返回」。
 * 必须在 Activity.dispatchTouchEvent 里调用 handle()，否则事件会被子 View（ScrollView/按钮）先吃掉。
 */
public final class SlideBack {
    private final Activity act;
    private final View content;
    private final int edge;
    private float downX, downY, lastX, vel;
    private long lastT;
    private boolean tracking;
    private boolean finishing;

    private SlideBack(Activity a, View target) {
        this.act = a;
        this.content = target;
        this.edge = (int) (56 * a.getResources().getDisplayMetrics().density);
    }

    public static SlideBack attach(Activity a, View target) {
        return new SlideBack(a, target);
    }

    /** true = 本次事件被侧滑手势消费掉。 */
    public boolean handle(MotionEvent e) {
        if (content == null || finishing) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (e.getX() > edge) return false;
                downX = e.getX();
                downY = e.getY();
                lastX = downX;
                lastT = System.currentTimeMillis();
                vel = 0;
                tracking = true;
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (!tracking) return false;
                float dx = e.getX() - downX;
                long now = System.currentTimeMillis();
                if (now - lastT > 10) {
                    vel = (e.getX() - lastX) / (float) (now - lastT);
                    lastX = e.getX();
                    lastT = now;
                }
                if (dx < 0) dx = 0;
                content.setTranslationX(dx);
                content.setAlpha(1f - 0.3f * Math.min(1f, dx / (content.getWidth() * 0.6f)));
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (!tracking) return false;
                tracking = false;
                float dx = content.getTranslationX();
                boolean goBack = dx > content.getWidth() / 3f || vel > 0.45f;
                if (goBack) {
                    finishing = true;
                    content.animate().translationX(content.getWidth()).alpha(0.5f).setDuration(200)
                            .withEndAction(new Runnable() {
                                @Override public void run() {
                                    act.finish();
                                    act.overridePendingTransition(0, 0);
                                }
                            }).start();
                } else {
                    content.animate().translationX(0).alpha(1f).setDuration(180).start();
                }
                return true;
            }
        }
        return tracking;
    }
}
