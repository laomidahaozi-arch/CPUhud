package com.dsh.cpuhud;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 跑分过程中的轻量采样：只开一个常驻 shell 进程，每 500ms 吐一行
 * 「温度|最高实时频率」，避免反复 exec 拖慢跑分本身。
 */
public final class RunSampler {
    private Thread reader;
    private volatile boolean running;
    private final List<float[]> samples = new ArrayList<>();   // [tMs, tempC, ghz]
    private long t0;
    private Object proc;

    /** 采样脚本：遍历 thermal_zone 取 CPU 温度 + 各核 cur_freq 取最大。 */
    private static final String SCRIPT =
            "i=0; while true; do i=$((i+1)); "
          + "F=$(for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq; do cat $c 2>/dev/null; done | sort -n | tail -1); "
          // 温度每 4 个循环取一次（dumpsys 较重，约 2 秒一次）
          + "if [ $((i % 4)) -eq 1 ]; then "
          + "T=$(dumpsys thermalservice 2>/dev/null | grep -m1 mName=CPU | awk -F 'mValue=' '{print $2}' | awk -F ',' '{print $1}'); "
          + "if [ -z \"$T\" ]; then T=$(for z in /sys/class/thermal/thermal_zone*; do n=$(cat $z/type 2>/dev/null); v=$(cat $z/temp 2>/dev/null); case \"$n\" in *cpu*|*soc*|*CPU*) [ -n \"$v\" ] && echo $v && break;; esac; done | head -1); fi; "
          + "else T=\"\"; fi; "
          + "echo \"$T|$F\"; sleep 0.5; done";

    public void start() {
        if (!ShizukuShell.granted()) return;
        running = true;
        samples.clear();
        t0 = System.currentTimeMillis();
        reader = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    java.lang.reflect.Method m = rikka.shizuku.Shizuku.class
                            .getMethod("newProcess", String[].class, String[].class, String.class);
                    Object p = m.invoke(null, new String[]{"/system/bin/sh", "-c", SCRIPT}, null, null);
                    proc = p;
                    InputStream in = (InputStream) p.getClass().getMethod("getInputStream").invoke(p);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    String line;
                    while (running && (line = br.readLine()) != null) {
                        String[] f = line.split("\\|");
                        if (f.length < 2) continue;
                        float temp = -1, ghz = -1;
                        try {
                            float raw = Float.parseFloat(f[0].trim());
                            float t = raw > 1000 ? raw / 1000f : raw;
                            if (t >= 15 && t <= 95) temp = t;             // 过滤哨兵值
                        } catch (Exception ignored) { }
                        try {
                            long khz = Long.parseLong(f[1].trim());
                            if (khz > 0) ghz = khz / 1000000f;
                        } catch (Exception ignored) { }
                        if (temp > 0 || ghz > 0) {
                            samples.add(new float[]{System.currentTimeMillis() - t0, temp, ghz});
                        }
                    }
                } catch (Throwable ignored) { }
            }
        }, "bench-sampler");
        reader.setDaemon(true);
        reader.start();
    }

    public void stop() {
        running = false;
        try {
            if (proc != null) proc.getClass().getMethod("destroy").invoke(proc);
        } catch (Throwable ignored) { }
    }

    public List<float[]> data() {
        synchronized (samples) { return new ArrayList<>(samples); }
    }

    public float maxTemp() {
        float m = -1;
        for (float[] s : data()) m = Math.max(m, s[1]);
        return m;
    }

    public float minGhz() {
        float m = Float.MAX_VALUE;
        for (float[] s : data()) if (s[2] > 0) m = Math.min(m, s[2]);
        return m == Float.MAX_VALUE ? -1 : m;
    }
}
