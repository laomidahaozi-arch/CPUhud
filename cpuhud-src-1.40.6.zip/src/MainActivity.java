package com.dsh.cpuhud;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 设置页：看数据、开/关悬浮窗、调不透明度、切换游戏模式。 */
public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private TextView statusView, dataView, hintView, alphaLabel, shizukuView, powerInfoView;
    private Button toggleBtn;
    private SparkChart chart;
    private SeekBar alphaBar;
    private volatile boolean active = false;
    private Snapshot lastSnap;
    private SharedPreferences prefs;
    private int themeSig;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView tv(String s, float sp, int color, boolean mono, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (mono) t.setTypeface(android.graphics.Typeface.MONOSPACE, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setOnClickListener(l);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        b.setBackground(bg);
        b.setTextColor(Theme.text());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        DataSource.init(getApplicationContext());
        new Thread(new Runnable() {                       // 打开即自动读系统信息（只跑一次）
            @Override public void run() {
                android.content.Context ac = MainActivity.this.getApplicationContext();
                SocProbe.get(ac, false);
                SocMap.refreshIfStale(ac);        // 映射表超过 24 小时就静默拉一次
            }
        }).start();
        prefs = getSharedPreferences("hud", MODE_PRIVATE);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));

        root.addView(tv("CPU HUD  v1.40.6", 26f, Theme.strong(), false, true));
        root.addView(tv("温度 / 频率 / 功耗 / FPS 悬浮窗 · 点悬浮窗切换大小，长按隐藏", 12f, Theme.dim2(), false, false));

        shizukuView = tv("", 12f, Theme.dim(), true, false);
        powerInfoView = tv("", 10.5f, Theme.dim2(), true, false);
        statusView = tv("", 13f, Theme.good(), true, false);
        statusView.setPadding(0, dp(14), 0, dp(2));
        root.addView(statusView);
        root.addView(shizukuView);
        root.addView(powerInfoView);

        dataView = tv("正在等待数据…", 13f, Theme.text(), true, false);
        dataView.setLineSpacing(dp(3), 1f);
        root.addView(dataView);

        chart = new SparkChart(this);
        chart.setColors(Theme.accent(), Theme.dim2(), withAlpha(Theme.dim2(), 0x33), Theme.good(), Theme.hot());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(96));
        cp.topMargin = dp(10);
        root.addView(chart, cp);

        // 不透明度
        LinearLayout alphaRow = new LinearLayout(this);
        alphaRow.setOrientation(LinearLayout.HORIZONTAL);
        alphaRow.setPadding(0, dp(14), 0, 0);
        alphaLabel = tv("", 12f, Theme.dim(), true, false);
        alphaLabel.setWidth(dp(120));
        alphaBar = new SeekBar(this);
        alphaBar.setMax(75);
        int a0 = prefs.getInt("alpha", 78);
        alphaBar.setProgress(Math.max(0, Math.min(75, a0 - 25)));
        alphaLabel.setText("不透明度 " + a0 + "%");
        alphaBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int v = 25 + p;
                alphaLabel.setText("不透明度 " + v + "%");
                prefs.edit().putInt("alpha", v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        LinearLayout.LayoutParams alb = new LinearLayout.LayoutParams(0, dp(40), 1f);
        alphaRow.addView(alphaLabel);
        alphaRow.addView(alphaBar, alb);
        root.addView(alphaRow);

        // ---- 主操作：一个开关按钮 ----
        toggleBtn = new Button(this);
        toggleBtn.setAllCaps(false);
        toggleBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(Theme.card());
        tbg.setCornerRadius(dp(12));
        tbg.setStroke(dp(1), Theme.accent());
        toggleBtn.setBackground(tbg);
        toggleBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (HudService.running) {
                    stopService(new Intent(MainActivity.this, HudService.class));
                    toast("已关闭");
                } else {
                    startHud();
                }
                refreshToggle();
                // 服务真正起来 / 销毁有个延迟，稍后再对一次，避免文字停在旧状态
                toggleBtn.postDelayed(new Runnable() {
                    @Override public void run() { refreshToggle(); }
                }, 700);
            }
        });
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        tlp.topMargin = dp(14);
        root.addView(toggleBtn, tlp);

        // ---- 入口：四个常用页面 ----
        LinearLayout rowA = new LinearLayout(this);
        rowA.setOrientation(LinearLayout.HORIZONTAL);
        rowA.addView(navBtn("显示设置", HudConfigActivity.class));
        rowA.addView(navBtn("配色", ThemeActivity.class));
        LinearLayout.LayoutParams rpa = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rpa.topMargin = dp(8);
        root.addView(rowA, rpa);

        LinearLayout rowB = new LinearLayout(this);
        rowB.setOrientation(LinearLayout.HORIZONTAL);
        rowB.addView(navBtn("硬件信息", HardwareActivity.class));
        rowB.addView(navBtn("设备信息", DeviceInfoActivity.class));
        LinearLayout.LayoutParams rpb = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rpb.topMargin = dp(6);
        root.addView(rowB, rpb);

        LinearLayout rowC = new LinearLayout(this);
        rowC.setOrientation(LinearLayout.HORIZONTAL);
        rowC.addView(navBtn("更多设置（权限 / 手势 / 游戏名单 / 更新日志）", MoreActivity.class));
        LinearLayout.LayoutParams rpc = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rpc.topMargin = dp(6);
        root.addView(rowC, rpc);

        hintView = tv("· 点悬浮窗：简 → 标准 → 详细 循环；长按隐藏；拖动移动\n"
                + "· 数据源：Root / Shizuku 本地 → 容器后端 → 系统 API（三级自动回落）\n"
                + "· 功耗符号：放电为负，充电为正\n",
                11.5f, Theme.dim2(), false, false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hp.topMargin = dp(20);
        root.addView(hintView, hp);

        sc.addView(root);
        setContentView(sc);
        refreshToggle();

        root.postDelayed(new Runnable() {
            @Override public void run() {
                // 每次打开都检查：没有授权就请求（Shizuku 已授权时这个调用是空操作）
                if (ShizukuShell.perm() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    ShizukuShell.request();
                }
            }
        }, 1200);

        if (getIntent() != null && getIntent().getBooleanExtra("start", false)) {
            root.postDelayed(new Runnable() { @Override public void run() { startHud(); } }, 300);
        }
    }

    private String td(double v) {
        return v <= 0 ? "--" : Fmt.t1(v) + " °C";
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    /** 二级页入口按钮（半宽）。 */
    private Button navBtn(String label, final Class<?> target) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setPadding(dp(6), 0, dp(6), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        b.setTextColor(Theme.text());
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, target));
            }
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    /** 按钮文案跟着服务真实状态走。 */
    private void refreshToggle() {
        if (toggleBtn == null) return;
        boolean on = HudService.running;
        toggleBtn.setText(on ? "关闭悬浮窗" : "开启悬浮窗");
        toggleBtn.setTextColor(on ? Theme.hot() : Theme.good());
    }

    private void startHud() {
        if (!Settings.canDrawOverlays(this)) {
            toast("先点「悬浮窗权限」打开开关");
            return;
        }
        startService(new Intent(this, HudService.class));
        toast("悬浮窗已开启");
    }

    /** 从通知/adb 再次拉起时也要能开悬浮窗（Activity 已存在时不会走 onCreate）。 */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("start", false)) startHud();
    }

    /** 从配色页返回后重载配色，变了就重建，颜色立刻生效。 */
    private void checkTheme() {
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); return; }
    }

    private static int withAlpha(int c, int a) {
        return (c & 0x00FFFFFF) | (a << 24);
    }

    @Override protected void onResume() {
        super.onResume();
        checkTheme();
        refreshToggle();
        active = true;
        tick();
    }
    @Override protected void onPause() { active = false; super.onPause(); }
    @Override protected void onDestroy() { bg.shutdownNow(); super.onDestroy(); }

    private void tick() {
        bg.execute(new Runnable() {
            @Override public void run() {
                try {
                    final Snapshot s = DataSource.fetch();
                    ui.post(new Runnable() { @Override public void run() { if (active) show(s); } });
                } catch (final Exception e) {
                    ui.post(new Runnable() { @Override public void run() { if (active) showOffline(e.getMessage()); } });
                }
                ui.postDelayed(new Runnable() { @Override public void run() { if (active) tick(); } }, 1000);
            }
        });
    }

    private void refreshShizuku() {
        if (shizukuView == null) return;
        int p = ShizukuShell.perm();
        if (p < 0) {
            shizukuView.setText(Shell.hasRoot() ? "Root：已获取（本地直读模式）"
                    : "Shizuku 直连：未连接（数据走容器后端）");
            shizukuView.setTextColor(Theme.dim2());
        } else if (p == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            shizukuView.setText(Shell.hasRoot() ? "Root + Shizuku：已连接（优先走 Root 直读）"
                    : "Shizuku：已连接 · 已授权（本地采样可用）");
            shizukuView.setTextColor(Theme.good());
        } else {
            shizukuView.setText("Shizuku：已连接 · 未授权（点下面按钮）");
            shizukuView.setTextColor(Theme.warn());
        }
    }

    private void showOffline(String why) {
        boolean down = why != null && (why.contains("Failed to connect") || why.contains("ECONNREFUSED")
                || why.contains("connect timed out") || why.contains("Connection refused"));
        statusView.setTextColor(Theme.bad());
        if (ShizukuShell.granted()) {          // 已经用 Shizuku 直连，不再提容器后端
            statusView.setText("采样失败（将自动重试）");
            dataView.setText("Shizuku 已授权，但这一次本地采样没取到数据（宿主机偶发超时/命令被中断）。\n"
                    + "App 会自动重试，并临时退回「系统 API 基础模式」，不会中断显示。\n\n"
                    + "原始错误：" + why);
            return;
        }
        if (down) {
            statusView.setText("后端未启动 —— 采集服务没在跑");
            dataView.setText("手机重启 / App 重启后，容器里的采集服务会停掉，悬浮窗就取不到数据。\n\n"
                    + "恢复：执行 sh /sdcard/dsh/cpuhud/start.sh\n"
                    + "（在对话里说一句「启动后端」也行）\n\n"
                    + "原始错误：" + why);
        } else {
            statusView.setText("后端异常 —— " + why);
        }
    }

    private void show(Snapshot s) {
        lastSnap = s;
        refreshToggle();
        refreshShizuku();
        if (powerInfoView != null) {
            String pi = DataSource.powerInfo();
            powerInfoView.setText(pi == null || pi.isEmpty() ? "" : "功耗源：" + pi);
        }
        int a = prefs.getInt("alpha", 78);
        if (alphaBar.getProgress() != a - 25) {
            alphaBar.setProgress(a - 25);
            alphaLabel.setText("不透明度 " + a + "%");
        }
        boolean perm = Settings.canDrawOverlays(this);
        statusView.setTextColor(Theme.good());
        String src = DataSource.lastSource();
        String srcName = "shizuku".equals(src) ? "Shizuku 本地"
                : "basic".equals(src) ? "系统 API（基础模式）"
                : "root".equals(src) ? "Root 直读" : "容器后端";
        boolean local = "shizuku".equals(src);
        statusView.setText("数据源：" + srcName + " · 悬浮窗 " + (perm ? "已授权" : "未授权")
                + (s.gameOn ? " · 游戏模式(" + ("landscape".equals(s.gameReason) ? "横屏" : "名单") + ")" : ""));

        chart.setData(s.histFps, s.histW, (float) s.dispRate);
        StringBuilder b = new StringBuilder();
        b.append("FPS  ").append(s.fps >= 0 ? String.valueOf((int) Math.round(s.fps)) : "--")
                .append("   帧时间 ").append(String.format(java.util.Locale.US, "%.1f", s.fpsFt)).append(" ms")
                .append("   卡顿 ").append((int) Math.round(s.fpsJank)).append("/s\n");
        b.append("功耗 ").append(s.voltV > 0 ? String.format(java.util.Locale.US, "%+.2f", s.powerW) : "--").append(" W   ")
                .append(s.powerCharging ? "充电中" : "放电中").append("   ")
                .append(s.voltV > 0 ? String.valueOf(s.voltV) : "--").append(" V  ")
                .append(s.currentMa != 0 ? String.valueOf((int) Math.abs(s.currentMa)) : "--").append(" mA\n");
        b.append("屏幕 ").append((int) s.dispRate).append(" Hz   前台 ").append(s.pkg.isEmpty() ? "—" : s.pkg).append("\n");
        b.append("CPU  ").append(td(s.cpu)).append("    GPU ").append(td(s.gpu)).append("\n");
        b.append("SOC  ").append(td(s.soc)).append("    屏温 ").append(td(s.skin)).append("\n");
        b.append("电池 ").append(td(s.battTemp)).append("   ").append((int) s.battLevel).append("%\n");
        b.append("热状态 ").append(s.thermalLabel).append(" (level ").append(s.thermalStatus).append(")\n");
        b.append("────────────────────\n");
        for (int i = 0; i < s.cur.length; i++) {
            b.append("核 ").append(s.cores[i]).append("   ").append(Fmt.ghz(s.cur[i])).append(" / ")
                    .append(Fmt.ghz(s.max[i])).append(" GHz\n");
        }
        b.append("────────────────────\n");
        b.append("CPU 负载 ").append((int) Math.round(s.load)).append(" %\n");
        b.append("内存 ").append(Fmt.g1(s.memUsed)).append(" / ").append(Fmt.g1(s.memTotal)).append(" GB (")
                .append((int) s.memPct).append("%)\n");
        dataView.setText(b.toString());
    }
}
