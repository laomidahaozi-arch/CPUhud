package com.dsh.cpuhud;

import android.content.Context;

/**
 * 数据源优先级：
 *   1. Shizuku（本地 dumpsys，最全）
 *   2. 容器后端 127.0.0.1:8790（同机容器里的 node 服务）
 *   3. 系统 API 基础模式（免 root / 免 Shizuku / 免无线调试）
 */
public final class DataSource {
    private static final LocalSampler LOCAL = new LocalSampler();
    private static final BasicSampler BASIC = new BasicSampler();
    private static Context appCtx;
    private static String lastSrc = "";
    private static int fallbackCount = 0;
    public static int fallbackCount() { return fallbackCount; }

    private DataSource() { }

    public static void init(Context c) {
        if (c != null && appCtx == null) appCtx = c.getApplicationContext();
    }

    public static String lastSource() { return lastSrc; }
    public static Context appContext() { return appCtx; }
    public static String diag() { return LOCAL.diag(); }
    public static String fpsDebug() { return LOCAL.lastFpsDebug; }

    /** 最近一次识别到的前台包名（帧率兜底要用它跑 gfxinfo）。 */
    public static String fgPkg() { return LOCAL.fgPkg(); }

    /** 采样到的屏幕刷新率（取各图层上报的最大值）。 */
    public static double dispRate() { return LOCAL.lastDispRate; }
    public static String pwrDebug() { return LOCAL.lastPwrDebug; }
    public static String powerInfo() { return LOCAL.powerInfo(); }
    public static String powerDevs() { return LOCAL.powerDevs(); }

    public static Snapshot fetch() throws Exception {
        if (Shell.available()) {
            long t0 = System.currentTimeMillis();
            Snapshot s = LOCAL.sample();
            LOCAL.lastParseMs = System.currentTimeMillis() - t0 - LOCAL.lastMs;
            if (s != null) {
                BasicSampler.fillPower(appCtx, s);       // 高通用框架 API 兜底补齐
                CellCalib.apply(appCtx, s);             // 双电芯/串联校准
                lastSrc = Shell.hasRoot() ? "root" : "shizuku";
                return s;
            }
            // Shizuku 偶尔采样失败：直接降级到系统 API，不去碰已经不用的容器后端
            if (appCtx != null) {
                Snapshot fb = BASIC.sample(appCtx);
                BasicSampler.fillPower(appCtx, fb);
                lastSrc = "basic";
                fallbackCount++;
                return fb;
            }
            throw new Exception("本地采样失败且无上下文");
        }
        try {
            Snapshot s = MetricsClient.fetch();
            lastSrc = "http";
            return s;
        } catch (Exception e) {
            if (appCtx == null) throw e;
            Snapshot s = BASIC.sample(appCtx);
            CellCalib.apply(appCtx, s);
            lastSrc = "basic";
            return s;
        }
    }
}
