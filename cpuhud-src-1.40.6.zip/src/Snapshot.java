package com.dsh.cpuhud;

import org.json.JSONArray;
import org.json.JSONObject;

/** 一帧采样数据 + 从后端 JSON 解析。 */
public class Snapshot {
    public long ts;
    public double cpu, gpu, soc, skin, battTemp, pa;
    public int thermalStatus;
    public String thermalLabel = "";
    public String[] cores = new String[0];
    public double[] cur = new double[0];
    public double[] max = new double[0];
    public double freqAvg, freqMax, load;
    public double memTotal, memUsed, memPct;
    public double battLevel, battCurrent;
    public boolean charging;

    public double powerW, voltV, currentMa;
    public boolean powerCharging;
    public double fpsFt, fpsJank;
    public String fpsSrc = "layer";
    public String pkg = "";
    public boolean gameOn;
    public String gameReason = "";
    public double fps = -1, dispRate;
    public String fpsLayer = "";
    public float[] histFps = new float[0];
    public float[] histW = new float[0];

    static double num(JSONObject o, String k, double def) {
        return o != null && o.has(k) && !o.isNull(k) ? o.optDouble(k, def) : def;
    }

    public static Snapshot parse(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        Snapshot s = new Snapshot();
        s.ts = o.optLong("ts", System.currentTimeMillis());
        JSONObject t = o.optJSONObject("temps");
        if (t != null) {
            s.cpu = num(t, "CPU", 0); s.gpu = num(t, "GPU", 0); s.soc = num(t, "SOC", 0);
            s.skin = num(t, "SKIN", 0); s.battTemp = num(t, "BATTERY", 0); s.pa = num(t, "PA", 0);
        }
        JSONObject th = o.optJSONObject("thermal");
        if (th != null) { s.thermalStatus = th.optInt("status", 0); s.thermalLabel = th.optString("label", ""); }
        JSONArray fr = o.optJSONArray("freq");
        if (fr != null) {
            s.cores = new String[fr.length()]; s.cur = new double[fr.length()]; s.max = new double[fr.length()];
            for (int i = 0; i < fr.length(); i++) {
                JSONObject f = fr.getJSONObject(i);
                s.cores[i] = f.optString("cores", ""); s.cur[i] = f.optDouble("cur", 0); s.max[i] = f.optDouble("max", 0);
            }
        }
        s.freqAvg = num(o, "freqAvg", 0); s.freqMax = num(o, "freqMax", 0); s.load = num(o, "load", 0);
        JSONObject m = o.optJSONObject("mem");
        if (m != null) { s.memTotal = num(m, "total", 0); s.memUsed = num(m, "used", 0); s.memPct = num(m, "pct", 0); }
        JSONObject p2 = o.optJSONObject("power");
        if (p2 != null) {
            s.voltV = num(p2, "v", 0); s.currentMa = num(p2, "ma", 0); s.powerW = num(p2, "w", 0);
            s.powerCharging = p2.optBoolean("charging", false);
        }
        JSONObject f2 = o.optJSONObject("fps");
        if (f2 != null) {
            s.fps = f2.has("cur") && !f2.isNull("cur") ? f2.optDouble("cur", -1) : -1;
            s.dispRate = num(f2, "rate", 0);
            s.fpsLayer = f2.optString("layer", "");
            s.fpsFt = num(f2, "ft", 0);
            s.fpsJank = num(f2, "jank", 0);
            s.pkg = f2.optString("pkg", "");
            s.fpsSrc = f2.optString("src", "layer");
        }
        JSONObject g2 = o.optJSONObject("game");
        if (g2 != null) { s.gameOn = g2.optBoolean("on", false); s.gameReason = g2.optString("reason", ""); }
        JSONObject h = o.optJSONObject("hist");
        if (h != null) {
            JSONArray a1 = h.optJSONArray("fps"), a2 = h.optJSONArray("w");
            if (a1 != null) {
                s.histFps = new float[a1.length()];
                for (int i = 0; i < a1.length(); i++) s.histFps[i] = (float) a1.optDouble(i, 0);
            }
            if (a2 != null) {
                s.histW = new float[a2.length()];
                for (int i = 0; i < a2.length(); i++) s.histW[i] = (float) a2.optDouble(i, 0);
            }
        }
        JSONObject b = o.optJSONObject("batt");
        if (b != null) { s.battLevel = num(b, "level", 0); s.battCurrent = num(b, "current", 0); s.charging = b.optBoolean("charging", false); }
        return s;
    }
}
