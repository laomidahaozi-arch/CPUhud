// 极简 Android AXML(二进制 XML) 生成器 —— 绕开只能在 x86 上跑的 aapt2。
import fs from 'node:fs';

const RES_XML_TYPE = 0x0003, RES_STRING_POOL_TYPE = 0x0001, RES_XML_RESOURCE_MAP_TYPE = 0x0180;
const RES_XML_START_NAMESPACE = 0x0100, RES_XML_END_NAMESPACE = 0x0101;
const RES_XML_START_ELEMENT = 0x0102, RES_XML_END_ELEMENT = 0x0103;

const TYPE_REFERENCE = 0x01, TYPE_STRING = 0x03, TYPE_INT_DEC = 0x10, TYPE_INT_HEX = 0x11, TYPE_INT_BOOLEAN = 0x12;

const ATTR_IDS = {
  theme: 0x01010000, label: 0x01010001, icon: 0x01010002, name: 0x01010003,
  exported: 0x01010010, screenOrientation: 0x0101001e, versionCode: 0x0101021b,
  versionName: 0x0101021c, minSdkVersion: 0x0101020c, targetSdkVersion: 0x01010270,
  allowBackup: 0x01010280, hardwareAccelerated: 0x010102d3, usesCleartextTraffic: 0x010104ec,
  foregroundServiceType: 0x01010599, value: 0x01010024, authorities: 0x01010018,
  permission: 0x01010006, enableOnBackInvokedCallback: 0x0101066c,
  enabled: 0x0101000e, multiprocess: 0x01010013,
};

class Pool {
  constructor() { this.list = []; this.map = new Map(); }
  idx(s) { if (this.map.has(s)) return this.map.get(s); const i = this.list.length; this.list.push(s); this.map.set(s, i); return i; }
}

function u16(v) { const b = Buffer.alloc(2); b.writeUInt16LE(v >>> 0); return b; }
function u32(v) { const b = Buffer.alloc(4); b.writeUInt32LE(v >>> 0); return b; }

function chunk(type, headerSize, body) {
  return Buffer.concat([u16(type), u16(headerSize), u32(8 + body.length), body]);
}

function stringPool(strings) {
  const data = [];
  const offsets = [];
  let pos = 0;
  for (const s of strings) {
    offsets.push(pos);
    const buf = Buffer.from(s, 'utf16le');
    const len = Buffer.alloc(2); len.writeUInt16LE(s.length);
    const item = Buffer.concat([len, buf, u16(0)]);
    data.push(item);
    pos += item.length;
  }
  let blob = Buffer.concat(data);
  while (blob.length % 4 !== 0) blob = Buffer.concat([blob, Buffer.alloc(4 - (blob.length % 4))]);
  const headerSize = 28;
  const stringsStart = headerSize + 4 * strings.length; // styleCount = 0
  const body = Buffer.concat([
    u32(strings.length), u32(0),            // stringCount, styleCount
    u32(0),                                 // flags: UTF-16
    u32(stringsStart), u32(0),              // stringsStart, stylesStart
    ...offsets.map(u32),
    blob,
  ]);
  return chunk(RES_STRING_POOL_TYPE, headerSize, body);
}

function resourceMap(pool) {
  const entries = pool.list.map((s) => u32(ATTR_IDS[s] || 0));
  return chunk(RES_XML_RESOURCE_MAP_TYPE, 8, Buffer.concat(entries));
}

function startNamespace(prefixIdx, uriIdx) {
  return chunk(RES_XML_START_NAMESPACE, 16, Buffer.concat([u32(1), u32(0xffffffff), u32(prefixIdx), u32(uriIdx)]));
}
function endNamespace(prefixIdx, uriIdx) {
  return chunk(RES_XML_END_NAMESPACE, 16, Buffer.concat([u32(1), u32(0xffffffff), u32(prefixIdx), u32(uriIdx)]));
}

function startElement(pool, name, attrs, nsUri) {
  const nameIdx = pool.idx(name);
  const nsIdx = nsUri ? pool.idx(nsUri) : 0xffffffff;
  // aapt 会把属性按资源 ID 升序排列（无 ID 的放最后）——顺序不对时部分属性会被平台忽略
  attrs = attrs.slice().sort((a, b) => {
    const ia = ATTR_IDS[a.name] || (a.ns === 'android' ? 0x7fffffff : 0x7fffffff);
    const ib = ATTR_IDS[b.name] || (b.ns === 'android' ? 0x7fffffff : 0x7fffffff);
    return ia - ib;
  });
  const attrBufs = attrs.map((a) => {
    const attrNs = a.ns === 'android' ? pool.idx(nsUri) : 0xffffffff;
    const attrNameIdx = pool.idx(a.name);
    let raw = 0xffffffff, type, data;
    if (a.type === 'string') { raw = pool.idx(a.value); type = TYPE_STRING; data = raw; }
    else if (a.type === 'int') { type = TYPE_INT_DEC; data = a.value | 0; }
    else if (a.type === 'hex') { type = TYPE_INT_HEX; data = a.value | 0; }
    else if (a.type === 'bool') { type = TYPE_INT_BOOLEAN; data = a.value ? 0xffffffff : 0; }
    else if (a.type === 'ref') { type = TYPE_REFERENCE; data = a.value | 0; }
    else throw new Error('bad attr type ' + a.type);
    return Buffer.concat([u32(attrNs), u32(attrNameIdx), u32(raw), u16(8), Buffer.from([0, type]), u32(data)]);
  });
  const ext = Buffer.concat([
    u32(1), u32(0xffffffff), u32(nsIdx), u32(nameIdx),
    u16(20), u16(20), u16(attrs.length), u16(0), u16(0), u16(0),
    ...attrBufs,
  ]);
  return chunk(RES_XML_START_ELEMENT, 16, ext);
}

function endElement(pool, name, nsUri) {
  const nsIdx = nsUri ? pool.idx(nsUri) : 0xffffffff;
  return chunk(RES_XML_END_ELEMENT, 16, Buffer.concat([u32(1), u32(0xffffffff), u32(nsIdx), u32(pool.idx(name))]));
}

// node: {name, attrs:[{name, ns, type, value}], children:[]}
export function buildAxml(root, nsUri = 'http://schemas.android.com/apk/res/android', prefix = 'android') {
  const pool = new Pool();
  pool.idx(prefix); pool.idx(nsUri);
  const body = [];
  body.push(startNamespace(pool.idx(prefix), pool.idx(nsUri)));
  const walk = (node) => {
    const attrs = node.attrs || [];
    // 先把名字/取值塞进池子，保证 resourceMap 按最终顺序生成
    pool.idx(node.name);
    for (const a of attrs) {
      pool.idx(a.name);
      if (a.type === 'string') pool.idx(a.value);
    }
    body.push(startElement(pool, node.name, attrs, nsUri));
    for (const c of node.children || []) walk(c);
    body.push(endElement(pool, node.name, nsUri));
  };
  walk(root);
  body.push(endNamespace(pool.idx(prefix), pool.idx(nsUri)));
  const chunks = Buffer.concat([stringPool(pool.list), resourceMap(pool), ...body]);
  return chunk(RES_XML_TYPE, 8, chunks);
}

export function writeAxml(outPath, root) {
  const buf = buildAxml(root);
  fs.writeFileSync(outPath, buf);
  return buf.length;
}
