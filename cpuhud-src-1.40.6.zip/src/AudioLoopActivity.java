package com.dsh.cpuhud;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * 闭环音频测量：一边放单频，一边用麦克风录，测出「扬声器 + 麦克风」的合成频响和失真。
 * 纯软件实现：Goertzel 单频检测，不需要 FFT 库。
 */
public class AudioLoopActivity extends Activity {

    private static final int SR = 44100;
    private static final int[] FREQS = {100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000,
            1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000};

    private AudioManager am;
    private int savedVolume = -1;
    private ResponseView chart;
    private TextView state, thdText;
    private Button startBtn;
    private volatile boolean measuring = false;

    private final float[] db = new float[FREQS.length];
    private volatile double thdPct = -1;
    private volatile String lastError = null;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        Theme.load(this);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        savedVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(26));

        root.addView(text("频响 / 失真（闭环测量）", 21f, Theme.strong(), true));
        root.addView(text("外放一段一段单频，同时用麦克风录下来，量每一段的电平 → 画出频响曲线；"
                + "再放 1kHz 正弦，量 2~5 次谐波算失真。\n"
                + "测的是「扬声器 + 麦克风」的合成响应：横向对比、找破音很准，绝对值仅供参考。\n"
                + "需要麦克风权限；音量会自动到 70%，退出还原。", 11f, Theme.dim2(), false));

        state = text("等待开始", 12f, Theme.dim(), true);
        root.addView(state);

        chart = new ResponseView();
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        cp.topMargin = dp(8);
        chart.setLayoutParams(cp);
        root.addView(chart);

        thdText = text("", 12f, Theme.text(), true);
        root.addView(thdText);

        startBtn = wideBtn("开始测量（约 8 秒）");
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (measuring) return;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
                    return;
                }
                runMeasure();
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        sp.topMargin = dp(12);
        root.addView(startBtn, sp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button ok = wideBtn("正常");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save("pass", "频响连续，失真正常"); }
        });
        Button bad = wideBtn("有异常");
        bad.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save("fail", "某频段缺失 / 破音 / 失真明显"); }
        });
        row.addView(ok);
        row.addView(bad);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(10);
        root.addView(row, rp);

        Button back = wideBtn("返回");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        bp.topMargin = dp(8);
        root.addView(back, bp);

        root.addView(text("· 手机外放音量小、麦克风在底部，测量时别遮住底部麦克风\n"
                + "· 低频（<200Hz）手机会自然衰减，这是正常的，看曲线形状就好", 10.5f, Theme.dim2(), false));

        sc.addView(root);
        setContentView(sc);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == 1001) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) runMeasure();
            else Toast.makeText(this, "没有麦克风权限，测不了闭环", Toast.LENGTH_LONG).show();
        }
    }

    private void save(String result, String note) {
        SharedPreferences p = getSharedPreferences("selftest", MODE_PRIVATE);
        p.edit().putString("audio", result).putString("audio_note", note)
                .putLong("audio_ts", System.currentTimeMillis()).apply();
        Toast.makeText(this, "已记录", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ---------------------------------------------------------------- 测量

    private void runMeasure() {
        measuring = true;
        startBtn.setEnabled(false);
        startBtn.setText("测量中…");
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                lastError = null;
                try { ok = measure(); } catch (Throwable t) {
                    lastError = t.getClass().getSimpleName() + ": " + t.getMessage();
                }
                final boolean good = ok;
                final String err = lastError;
                runOnUiThread(new Runnable() { @Override public void run() { finishMeasure(good, err); } });
            }
        }).start();
    }

    private void finishMeasure(boolean ok, String err) {
        measuring = false;
        startBtn.setEnabled(true);
        startBtn.setText("再测一次");
        if (!ok) {
            state.setText("测量失败：" + (err == null ? "未知原因" : err));
            state.setTextColor(Theme.bad());
            return;
        }
        state.setText("测量完成");
        state.setTextColor(Theme.good());
        if (thdPct >= 0) {
            thdText.setText(String.format(Locale.US, "1kHz 失真 THD ≈ %.1f%%  ·  低频(100Hz) %s  ·  高频(16kHz) %s",
                    thdPct, dbStr(0), dbStr(FREQS.length - 1)));
            thdText.setTextColor(thdPct < 10 ? Theme.good() : Theme.warn());
        }
        chart.invalidate();
    }

    private String dbStr(int i) {
        return String.format(Locale.US, "%.0f dB", db[i]);
    }

    private boolean measure() {
        int maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(1, (int) (maxVol * 0.7)), 0);

        int minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minBuf <= 0) minBuf = 4096;
        AudioRecord rec = null;
        int[] sources = {MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.MIC};
        for (int src : sources) {
            try {
                AudioRecord cand = new AudioRecord(src, SR, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf * 2, SR / 2));
                if (cand.getState() == AudioRecord.STATE_INITIALIZED) { rec = cand; break; }
                cand.release();
            } catch (Throwable ignored) { }
        }
        if (rec == null) {
            lastError = "麦克风初始化失败（系统拒绝或不支持 44100Hz 单声道录音）";
            return false;
        }
        final AudioRecord recF = rec;

        final short[] ring = new short[SR];
        final int[] pos = {0};
        final boolean[] run = {true};
        recF.startRecording();
        Thread reader = new Thread(new Runnable() {
            @Override public void run() {
                short[] buf = new short[2048];
                while (run[0]) {
                    int n = recF.read(buf, 0, buf.length);
                    if (n <= 0) continue;
                    synchronized (ring) {
                        for (int i = 0; i < n; i++) { ring[pos[0]] = buf[i]; pos[0] = (pos[0] + 1) % ring.length; }
                    }
                }
            }
        });
        reader.setPriority(Thread.MAX_PRIORITY);
        reader.start();

        final TonePlayer player = new TonePlayer();
        try {
            player.start();
        } catch (Throwable t) {
            run[0] = false;
            try { recF.stop(); recF.release(); } catch (Throwable ignored) { }
            lastError = "音频输出初始化失败：" + t.getClass().getSimpleName();
            return false;
        }
        if (!player.ready) {
            sleep(150);
            if (!player.ready) {
                run[0] = false;
                player.halt();
                try { recF.stop(); recF.release(); } catch (Throwable ignored) { }
                lastError = "音频输出初始化失败：" + player.err;
                return false;
            }
        }
        sleep(250);      // 让录音和播放都稳定下来

        for (int i = 0; i < FREQS.length; i++) {
            final int idx = i;
            player.freq = FREQS[i];
            sleep(300);                       // 等这一路声音稳定
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    state.setText("正在测 " + FREQS[idx] + " Hz …");
                    state.setTextColor(Theme.dim());
                }
            });
            double best = 0;
            for (int k = 0; k < 3; k++) {
                if (!measuring) break;
                double m = goertzel(grab(ring, pos[0], 8192), FREQS[i]);
                if (m > best) best = m;
                sleep(70);
            }
            db[i] = (float) (20 * Math.log10(Math.max(best, 1e-9)));
        }

        // THD：1kHz 基波与 2~5 次谐波
        player.freq = 1000;
        sleep(320);
        short[] win = grab(ring, pos[0], 8192);
        double f1 = goertzel(win, 1000);
        double h = 0;
        for (int k = 2; k <= 5; k++) {
            double m = goertzel(win, 1000 * k);
            h += m * m;
        }
        thdPct = f1 > 0 ? Math.sqrt(h) / f1 * 100 : -1;

        run[0] = false;
        player.halt();
        try { recF.stop(); } catch (Throwable ignored) { }
        try { recF.release(); } catch (Throwable ignored) { }

        float max = -999;
        for (float v : db) max = Math.max(max, v);
        if (max < -100) {
            lastError = "没录到声音：麦克风被占用 / 静音 / 外放没响";
            return false;
        }
        for (int i = 0; i < db.length; i++) db[i] -= max;
        return true;
    }

    /** 常驻播放线程：一直往 AudioTrack 里灌当前频率的正弦，避免测量时 buffer 见底。 */
    private class TonePlayer extends Thread {
        volatile int freq = 0;              // 0 = 静音
        volatile boolean ready = false;
        volatile String err = "";
        private volatile boolean alive = true;
        private AudioTrack track;
        private double phase = 0;

        @Override public void run() {
            try {
                int minOut = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT);
                if (minOut <= 0) minOut = 16384;
                track = new AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(minOut * 2, 32768), AudioTrack.MODE_STREAM);
                if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                    err = "state";
                    return;
                }
                track.play();
                ready = true;
                short[] buf = new short[2048];
                while (alive) {
                    int f = freq;
                    for (int i = 0; i < buf.length / 2; i++) {
                        short s = 0;
                        if (f > 0) {
                            phase += 2 * Math.PI * f / SR;
                            if (phase > 2 * Math.PI) phase -= 2 * Math.PI;
                            s = (short) (Math.sin(phase) * 9000);
                        }
                        buf[i * 2] = s;
                        buf[i * 2 + 1] = s;
                    }
                    track.write(buf, 0, buf.length);
                }
            } catch (Throwable t) {
                err = t.getClass().getSimpleName();
            } finally {
                try { if (track != null) { track.stop(); track.release(); } } catch (Throwable ignored) { }
            }
        }

        void halt() {
            alive = false;
            freq = 0;
            try { join(800); } catch (InterruptedException ignored) { }
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    /**
     * 生成正弦（左右声道相同）。
     *
     * 相位必须跨缓冲区连续：老写法每个 buffer 用 i % period 重新起相，
     * 每次拼接都会产生一个相位跳变 → 咔哒声 → 谐波暴涨（THD 曾被测成 39%）。
     */
    private double tonePhase = 0;

    private void fillTone(short[] pcm, int freq) {
        int frames = pcm.length / 2;
        double w = 2 * Math.PI * freq / SR;
        for (int i = 0; i < frames; i++) {
            tonePhase += w;
            if (tonePhase > 2 * Math.PI) tonePhase -= 2 * Math.PI;
            short s = (short) (Math.sin(tonePhase) * 9000);
            pcm[i * 2] = s;
            pcm[i * 2 + 1] = s;
        }
    }

    private static short[] grab(short[] ring, int pos, int len) {
        short[] out = new short[len];
        synchronized (ring) {
            for (int i = 0; i < len; i++) {
                int idx = (pos - len + i + ring.length * 2) % ring.length;
                out[i] = ring[idx];
            }
        }
        return out;
    }

    /**
     * Goertzel + Hann 窗。
     *
     * 加窗很关键：矩形窗的频谱泄漏会把基波的能量漏到 2k/3k 这些谐波位置上，
     * 让 THD 严重虚高（实测矩形窗能测出 14%，加窗后回到正常量级）。
     */
    private static double goertzel(short[] data, double freq) {
        int n = data.length;
        double w = 2 * Math.PI * freq / SR;
        double coeff = 2 * Math.cos(w);
        double q1 = 0, q2 = 0;
        double winSum = 0;
        for (int i = 0; i < n; i++) {
            double win = 0.5 * (1 - Math.cos(2 * Math.PI * i / (n - 1)));
            winSum += win;
            double q0 = coeff * q1 - q2 + (data[i] / 32768.0) * win;
            q2 = q1;
            q1 = q0;
        }
        double power = q1 * q1 + q2 * q2 - coeff * q1 * q2;
        // 窗函数让幅度衰减到一半，除回来保持量级一致（比值判定不受影响）
        return winSum > 0 ? Math.sqrt(Math.max(power, 0)) / (winSum / 2.0) : 0;
    }

    // ---------------------------------------------------------------- 曲线

    private class ResponseView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        ResponseView() { super(AudioLoopActivity.this); }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            float plotH = h - dp(16);
            c.drawColor(Theme.card2());
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1);
            p.setColor(Theme.card());
            for (int i = 0; i <= 4; i++) {
                float y = plotH * i / 4f;
                c.drawLine(0, y, w, y, p);
            }
            for (int i = 0; i <= 4; i++) {
                float x = w * i / 4f;
                c.drawLine(x, 0, x, plotH, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.dim2());
            p.setTextSize(dp(9));
            p.setTextAlign(Paint.Align.LEFT);
            c.drawText("0 dB", dp(4), dp(11), p);
            c.drawText("-40 dB", dp(4), plotH - dp(3), p);
            c.drawText("100Hz", dp(4), h - dp(3), p);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("1kHz", w / 2f, h - dp(3), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("16kHz", w - dp(2), h - dp(3), p);

            float px = -1, py = -1;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(Theme.accent());
            for (int i = 0; i < FREQS.length; i++) {
                float x = (float) (Math.log10(FREQS[i] / 100.0) / Math.log10(16000 / 100.0)) * w;
                float y = plotH * (1 - Math.max(0, Math.min(1, (db[i] + 40) / 40f)));
                if (px >= 0) c.drawLine(px, py, x, y, p);
                px = x;
                py = y;
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.accent());
            for (int i = 0; i < FREQS.length; i++) {
                float x = (float) (Math.log10(FREQS[i] / 100.0) / Math.log10(16000 / 100.0)) * w;
                float y = plotH * (1 - Math.max(0, Math.min(1, (db[i] + 40) / 40f)));
                c.drawCircle(x, y, dp(2f), p);
            }
        }
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(3), 0, dp(3));
        return v;
    }

    private Button wideBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        b.setTextColor(Theme.text());
        b.setPadding(dp(6), 0, dp(6), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }

    @Override protected void onDestroy() {
        measuring = false;
        if (savedVolume >= 0) {
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }
}
