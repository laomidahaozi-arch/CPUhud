package com.dsh.cpuhud;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** 触摸自检：在网格上滑一遍，看覆盖率；多指同时按，看最大触点数。 */
public class TouchTestActivity extends Activity {

    private GridView view;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(view = new GridView());
        goFullscreen();
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::showResult);
        }
    }

    @Override public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) goFullscreen();
    }

    private void goFullscreen() {
        try {
            android.view.Window win = getWindow();
            win.setStatusBarColor(0x00000000);
            win.setNavigationBarColor(0x00000000);
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = win.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                win.setAttributes(lp);
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                win.setDecorFitsSystemWindows(false);
                android.view.WindowInsetsController c = win.getInsetsController();
                if (c != null) {
                    c.hide(android.view.WindowInsets.Type.statusBars()
                            | android.view.WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                win.getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        } catch (Throwable ignored) { }
    }

    @Override public void onBackPressed() {
        showResult();
    }

    private void showResult() {
        int total = view.cols * view.rows, hit = view.count();
        int pct = total == 0 ? 0 : Math.round(hit * 100f / total);
        boolean ok = pct >= 95;
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle("触摸自检结果")
                .setMessage("网格覆盖：" + hit + " / " + total + "（" + pct + "%）\n"
                        + "最大同时触点：" + view.maxPointers + " 点\n\n"
                        + (ok ? "覆盖率达标。" : "有格子没划到 —— 如果是自己漏划，可以重测；如果反复划不到同一区域，可能那块触摸有问题。"))
                .setPositiveButton(ok ? "记录为正常" : "记录为异常", (d, w) -> {
                    SharedPreferences p = getSharedPreferences("selftest", MODE_PRIVATE);
                    p.edit().putString("touch", ok ? "pass" : "warn")
                            .putString("touch_note", "覆盖 " + pct + "% · 最大 " + view.maxPointers + " 点")
                            .putLong("touch_ts", System.currentTimeMillis()).apply();
                    Toast.makeText(this, "已记录", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNeutralButton("重测", (d, w) -> {
                    view.reset();
                    view.invalidate();
                })
                .setNegativeButton("退出", (d, w) -> finish())
                .create();
        styleDialog(dlg);
        dlg.show();
    }

    /** 深色圆角背景，和 App 配色一致。 */
    private void styleDialog(android.app.AlertDialog dlg) {
        dlg.setOnShowListener(d -> {
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(Theme.card2());
            bg.setCornerRadius(getResources().getDisplayMetrics().density * 20);
            if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(bg);
            int id = getResources().getIdentifier("alertTitle", "id", "android");
            android.view.View v = dlg.findViewById(id);
            if (v instanceof android.widget.TextView) ((android.widget.TextView) v).setTextColor(Theme.strong());
            View mv = dlg.findViewById(android.R.id.message);
            if (mv instanceof android.widget.TextView) ((android.widget.TextView) mv).setTextColor(Theme.text());
        });
    }

    private class GridView extends View {
        int cols = 12, rows = 26;
        int maxPointers = 1;
        private final boolean[] hit = new boolean[64 * 64];
        private final Paint p = new Paint();
        private final Map<Integer, float[]> last = new HashMap<>();

        GridView() { super(TouchTestActivity.this); }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            float cell = Math.max(dp(18), w / 12f);
            cols = Math.max(4, Math.round(w / cell));
            rows = Math.max(6, Math.round(h / cell));
            p.setStrokeWidth(1);
        }

        private float dp(float v) {
            return getResources().getDisplayMetrics().density * v;
        }

        int count() {
            int n = 0;
            for (int i = 0; i < cols * rows && i < hit.length; i++) if (hit[i]) n++;
            return n;
        }

        void reset() {
            for (int i = 0; i < hit.length; i++) hit[i] = false;
            maxPointers = 1;
            last.clear();
        }

        private void mark(float x, float y) {
            int cx = (int) (x / (getWidth() / (float) cols));
            int cy = (int) (y / (getHeight() / (float) rows));
            cx = Math.max(0, Math.min(cols - 1, cx));
            cy = Math.max(0, Math.min(rows - 1, cy));
            int idx = cy * cols + cx;
            if (idx >= 0 && idx < hit.length) hit[idx] = true;
        }

        private void markLine(float x0, float y0, float x1, float y1) {
            float dx = x1 - x0, dy = y1 - y0;
            float dist = (float) Math.hypot(dx, dy);
            int steps = Math.max(1, (int) (dist / dp(6)));
            for (int i = 0; i <= steps; i++) {
                mark(x0 + dx * i / steps, y0 + dy * i / steps);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            int action = e.getActionMasked();
            maxPointers = Math.max(maxPointers, e.getPointerCount());
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                float x = e.getX(i), y = e.getY(i);
                float[] prev = last.get(id);
                if (prev == null) {
                    mark(x, y);
                    last.put(id, new float[]{x, y});
                } else {
                    markLine(prev[0], prev[1], x, y);
                    prev[0] = x;
                    prev[1] = y;
                }
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                last.remove(e.getPointerId(0));
            }
            invalidate();
            return true;
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(0xFF10161D);
            float cw = w / (float) cols, ch = h / (float) rows;
            p.setStyle(Paint.Style.FILL);
            for (int y = 0; y < rows; y++) {
                for (int x = 0; x < cols; x++) {
                    boolean on = hit[y * cols + x];
                    p.setColor(on ? 0xFF2FD07A : 0xFF1C2630);
                    c.drawRect(x * cw + 1, y * ch + 1, (x + 1) * cw - 1, (y + 1) * ch - 1, p);
                }
            }
            int total = cols * rows, cnt = count();
            int pct = total == 0 ? 0 : Math.round(cnt * 100f / total);
            p.setColor(0xCC000000);
            c.drawRect(0, 0, w, dp(64), p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(dp(15));
            p.setTextAlign(Paint.Align.LEFT);
            c.drawText(String.format(Locale.US, "覆盖 %d%%（%d/%d）   最大触点 %d   返回结束",
                    pct, cnt, total, maxPointers), dp(14), dp(38), p);
        }
    }
}
