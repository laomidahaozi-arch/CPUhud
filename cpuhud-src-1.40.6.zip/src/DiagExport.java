package com.dsh.cpuhud;

import android.os.Build;

/** 把「这台机器实际能读到什么」导成一个文本文件，方便适配新机型。 */
public final class DiagExport {
    private DiagExport() { }

    private static final String[] CMDS = {
        "getprop ro.board.platform",
        "getprop ro.soc.model",
        "getprop ro.hardware",
        "getprop ro.product.board",
        "getprop | grep -iE 'thermal|soc|platform|chip' | head -40",
        "echo '--- thermal zones ---'; for z in /sys/class/thermal/thermal_zone*; do "
            + "echo \"$z | $(cat $z/type 2>/dev/null) | $(cat $z/temp 2>/dev/null)\"; done",
        "echo '--- cooling devices ---'; ls /sys/class/thermal/ 2>/dev/null",
        "echo '--- power_supply ---'; for d in /sys/class/power_supply/*; do "
            + "echo \"[$d]\"; ls $d 2>/dev/null | tr '\\n' ' '; echo; done",
        "echo '--- power values ---'; for f in /sys/class/power_supply/*/current_now "
            + "/sys/class/power_supply/*/current_avg /sys/class/power_supply/*/voltage_now "
            + "/sys/class/power_supply/*/capacity; do "
            + "v=$(cat $f 2>/dev/null); [ -n \"$v\" ] && echo \"$f = $v\"; done",
        "echo '--- cpufreq ---'; for c in /sys/devices/system/cpu/cpu0 /sys/devices/system/cpu/cpu4 "
            + "/sys/devices/system/cpu/cpu7; do echo \"$c: cur=$(cat $c/cpufreq/scaling_cur_freq 2>/dev/null) "
            + "max=$(cat $c/cpufreq/cpuinfo_max_freq 2>/dev/null)\"; done",
        "echo '--- thermalservice ---'; dumpsys thermalservice 2>/dev/null | head -40",
        "echo '--- sf timestats ---'; dumpsys SurfaceFlinger --timestats -dump 2>/dev/null | head -40",
        "echo '--- battery ---'; dumpsys battery 2>/dev/null",
        "echo '--- soc props ---'; getprop | grep -iE 'soc|chip|platform|board|hardware' | head -30",
        "echo '--- cpuinfo ---'; grep -iE 'Hardware|Processor' /proc/cpuinfo | head -20",
        "echo '--- power_supply 全节点 ---'; for d in /sys/class/power_supply/*; do n=${d##*/}; "
            + "for f in charge_full charge_full_design cycle_count charge_counter capacity voltage_now current_now; do "
            + "v=$(cat $d/$f 2>/dev/null); [ -n \"$v\" ] && echo \"$n/$f=$v\"; done; done",
        "echo '--- sensors ---'; dumpsys sensorservice 2>/dev/null | sed -n '/Sensor List:/,/^$/p' | head -50",
        "echo '--- display rates ---'; dumpsys display 2>/dev/null | grep -m1 -o 'supportedRefreshRates[^]]*]'",
        "echo '--- audio ---'; dumpsys audio 2>/dev/null | grep -iE 'spatializer|HeadTracking' | head -5",
    };

    /** 生成诊断文本并复制到剪贴板（阻塞，需在后台线程调用；返回文本长度）。 */
    public static int copyToClipboard(android.content.Context ctx, String foregroundPkg) {
        String text = build(ctx, foregroundPkg);
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("CPU HUD 适配诊断", text));
        return text.length();
    }

    /** 生成诊断文本（阻塞，需在后台线程调用）。 */
    public static String build(android.content.Context ctx, String foregroundPkg) {
        StringBuilder sb = new StringBuilder();
        if (ctx != null) {
            sb.append("--- 识别结果 (JSON) ---\n");
            sb.append(SocTrust.toJson(ctx));
            sb.append("\n--- 原始诊断 ---\n");
        }
        sb.append("CPU HUD 适配诊断\n");
        sb.append("model=").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
          .append(" android=").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("fg=").append(foregroundPkg).append('\n');
        boolean shellOk = Shell.hasRoot() || ShizukuShell.granted();
        sb.append("shell=").append(shellOk ? "可用" : "不可用（未授权 Shizuku / 无 root）")
          .append(shellOk ? "" : "  →  下面所有 $ 开头的段落都会是 (null)，这是权限问题不是 App 问题")
          .append('\n');
        sb.append("diag=").append(DataSource.diag()).append('\n');
        sb.append("power=").append(DataSource.powerInfo()).append('\n');
        sb.append('\n');

        // 与 App 内「设备信息」页完全一致的内容：用户看到什么，研发就看到什么
        if (ctx != null) {
            sb.append("--- 设备信息页（与 App 内一致）---\n");
            try {
                DeviceInfo.Result r = DeviceInfo.collect(ctx);
                sb.append("机型：").append(r.model).append("  ").append(r.market)
                  .append("  标称库：").append(r.specStatus).append('\n');
                for (DeviceInfo.Section sec : r.sections) {
                    sb.append('\n').append("[").append(sec.title).append("]\n");
                    for (String[] row : sec.rows) {
                        sb.append(row[0]).append(": ").append(row[1]).append('\n');
                    }
                }
                sb.append('\n');
            } catch (Throwable t) {
                sb.append("(设备信息采集失败：").append(t).append(")\n\n");
            }
        }
        if (!shellOk) {
            sb.append("（跳过 shell 段：需要 Shizuku 授权或 root 才有输出）\n\n");
        } else {
            for (String cmd : CMDS) {
                sb.append("$ ").append(cmd.length() > 80 ? cmd.substring(0, 80) + "…" : cmd).append('\n');
                String out = Shell.exec(cmd, 4000);
                sb.append(out == null ? "(null)\n" : out.trim()).append("\n\n");
            }
        }
        if (foregroundPkg != null && !foregroundPkg.isEmpty()) {
            sb.append("$ dumpsys gfxinfo ").append(foregroundPkg).append(" framestats\n");
            String out = Shell.exec("dumpsys gfxinfo " + foregroundPkg + " framestats 2>/dev/null | head -20", 4000);
            sb.append(out == null ? "(null)\n" : out.trim()).append("\n");
        }
        return sb.toString();
    }
}
