package com.dsh.cpuhud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.List;
import java.util.Locale;

/** 跑分历史趋势：单核（青）/ 多核（橙）两条线，各自归一化。 */
public class TrendChart extends View {
    private final Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pGrid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float[] single = new float[0];
    private float[] multi = new float[0];
    private int accent = Theme.accent();

    public TrendChart(Context c) {
        super(c);
        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(dp(1.6f));
        pLine.setStrokeCap(Paint.Cap.ROUND);
        pLine.setStrokeJoin(Paint.Join.ROUND);
        pText.setColor(Theme.dim2());
        pText.setTextSize(dp(8f));
        pGrid.setColor(Theme.isLight() ? 0x22000000 : 0x1AFFFFFF);
        pGrid.setStrokeWidth(dp(0.7f));
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    private float dp(float v) {
        return getResources().getDisplayMetrics().density * v;
    }

    public void setData(List<float[]> pts, int accent) {
        this.accent = accent;
        single = new float[pts.size()];
        multi = new float[pts.size()];
        for (int i = 0; i < pts.size(); i++) {
            single[i] = pts.get(i)[0];
            multi[i] = pts.get(i)[1];
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || single.length < 2) return;
        float bottom = h - dp(1.5f);
        float left = dp(24), right = w - dp(2);
        float plotW = Math.max(dp(8), right - left);

        c.drawLine(left, 0, right, 0, pGrid);
        c.drawLine(left, bottom, right, bottom, pGrid);

        drawSeries(c, single, left, plotW, bottom, accent);
        drawSeries(c, multi, left, plotW, bottom, Theme.hot());

        pText.setTextAlign(Paint.Align.LEFT);
        c.drawText(String.format(Locale.US, "%.0f", maxOf(single)), dp(1), dp(8), pText);
        pText.setTextAlign(Paint.Align.RIGHT);
        c.drawText(String.format(Locale.US, "%.0f", maxOf(multi)), w - dp(1), dp(8), pText);
        pText.setTextAlign(Paint.Align.LEFT);
        c.drawText("最近 " + single.length + " 次", left + dp(2), bottom - dp(2), pText);
    }

    private static float maxOf(float[] a) {
        float m = 1;
        for (float v : a) m = Math.max(m, v);
        return m;
    }

    private void drawSeries(Canvas c, float[] v, float left, float plotW, float bottom, int color) {
        float mx = maxOf(v);
        float step = plotW / (v.length - 1);
        path.reset();
        for (int i = 0; i < v.length; i++) {
            float x = left + i * step;
            float y = bottom - Math.min(v[i] / mx, 1f) * bottom * 0.92f;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        pLine.setColor(color);
        c.drawPath(path, pLine);
    }
}
