package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 打开 App 时自动探测 SoC 身份：把所有常见系统属性读一遍，
 * 取最像"芯片型号"的那个，再套市场名映射。结果缓存在本地。
 */
public final class SocProbe {
    private SocProbe() { }

    public static class Info {
        public String raw = "";         // SM6375 / MT6993 / holi
        public String source = "";      // 来自哪个属性
        public String vendor = "";      // Qualcomm / MediaTek / …
        public String market = "";      // 骁龙 695 / 天玑 9500
        public String deviceMarket = ""; // 手机市场名（设置里那个）
        /** 所有参与比对的候选值 → 来源，用来解释「为什么识别成这个」 */
        public final java.util.LinkedHashMap<String, String> candidates = new java.util.LinkedHashMap<>();
        public String gpuVendor = "";   // 从 GPU 反推的厂商，用来交叉校验
        public String note = "";        // 校正说明（例如「已按 GPU 校正」）
    }

    private static final String PREF = "socprobe";
    private static Info cached;

    /** 读一次缓存；force=true 时重新探测。 */
    public static Info get(Context ctx, boolean force) {
        if (cached != null && !force) {
            // 映射表可能刚被换掉，市场名跟着重算（毫秒级，纯内存）
            cached.market = ChipArt.marketName(cached.raw);
            return cached;
        }
        if (ctx == null) return hardcoded();
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!force) {
            String raw = sp.getString("raw", "");
            // 识别算法升级后老缓存要作废：ver 不匹配就重新探测
            if (!raw.isEmpty() && sp.getInt("ver", 0) == 3) {
                Info i = new Info();
                i.raw = raw;
                i.source = sp.getString("source", "");
                i.vendor = sp.getString("vendor", "");
                i.note = sp.getString("note", "");
                i.gpuVendor = sp.getString("gpu", "");
                // 市场名每次重算：远端映射表可能在两次启动之间更新过
                i.market = ChipArt.marketName(raw);
                refineByFreq(i);
                i.deviceMarket = sp.getString("device", "");
                String cand = sp.getString("cand", "");
                if (!cand.isEmpty()) {
                    for (String line : cand.split("\n")) {
                        int eq = line.indexOf('=');
                        if (eq > 0) i.candidates.put(line.substring(0, eq), line.substring(eq + 1));
                    }
                }
                if (!i.candidates.isEmpty()) {
                    cached = i;
                    return i;
                }
                // 老版本缓存里没有候选记录：顺手重新探测一次（约 50ms），把候选补上
            }
        }
        Info info = probe();
        android.util.Log.i("CPUHUD", "socprobe raw=" + info.raw + " src=" + info.source
                + " vendor=" + info.vendor + " market=" + info.market + " device=" + info.deviceMarket);
        StringBuilder cb = new StringBuilder();
        for (java.util.Map.Entry<String, String> e : info.candidates.entrySet()) {
            cb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        }
        sp.edit().putString("raw", info.raw).putString("source", info.source)
                .putString("vendor", info.vendor).putString("market", info.market)
                .putString("device", info.deviceMarket)
                .putString("note", info.note).putString("gpu", info.gpuVendor)
                .putInt("ver", 3)
                .putString("cand", cb.toString()).apply();
        cached = info;
        return info;
    }

    /**
     * 完全不依赖 shell 的兜底：Build 里的公开字段，任何权限都不需要。
     * 没装 Shizuku / 没 root 时走这条，保证"打开就能识别"。
     */
    private static Info hardcoded() {
        Info i = new Info();
        String soc = Build.VERSION.SDK_INT >= 31 ? Build.SOC_MODEL : null;
        String[] cands = { soc, Build.HARDWARE, Build.BOARD, Build.PRODUCT, Build.DEVICE };
        for (String c : cands) {
            if (isUseful(c)) { i.raw = c.trim(); break; }
        }
        if (i.raw.isEmpty()) i.raw = Build.HARDWARE == null ? "" : Build.HARDWARE;
        i.source = i.raw.equals(nz(soc)) ? "Build.SOC_MODEL" : "Build";
        if (Build.VERSION.SDK_INT >= 31) {
            String sm = Build.SOC_MANUFACTURER;
            if (sm != null) {
                String u = sm.toLowerCase(Locale.US);
                if (u.contains("qualcomm")) i.vendor = "Qualcomm";
                else if (u.contains("mediatek")) i.vendor = "MediaTek";
                else if (u.contains("hisilicon")) i.vendor = "HiSilicon";
                else if (u.contains("samsung")) i.vendor = "Samsung";
                else if (u.contains("google")) i.vendor = "Google";
                else if (u.contains("unisoc") || u.contains("spreadtrum")) i.vendor = "Unisoc";
            }
        }
        i.deviceMarket = nz(Build.MODEL);   // 拿不到市场名时至少显示型号代码，不空着
        fill(i);
        if (i.vendor.isEmpty()) {
            String u = nz(Build.MANUFACTURER).toLowerCase(Locale.US);
            if (u.contains("oneplus") || u.contains("oppo") || u.contains("vivo")
                    || u.contains("xiaomi") || u.contains("realme")) {
                // 手机厂商 ≠ 芯片厂商，只用来提示，不当作芯片厂商写进去
            }
        }
        return i;
    }

    private static boolean isUseful(String v) {
        if (v == null) return false;
        String t = v.trim().toLowerCase(Locale.US);
        return !t.isEmpty() && !"unknown".equals(t) && !"".equals(t) && !"default".equals(t);
    }

    private static String nz(String s) { return s == null ? "" : s; }

    /** 把所有属性抓下来本地解析（一次 shell，约 50ms）。 */
    private static Info probe() {
        Info info = new Info();
        try { return probeInner(info); } catch (Throwable t) { return hardcoded(); }
    }

    private static Info probeInner(Info info) {
        Map<String, String> props = new LinkedHashMap<>();
        String out = Shell.exec("getprop 2>/dev/null", 4000);
        if (out != null) {
            for (String line : out.split("\n")) {
                try {
                    int a = line.indexOf('['), b = line.indexOf("]: [");
                    if (a < 0 || b < 0) continue;
                    int vs = b + 4;
                    int ve = line.lastIndexOf(']');
                    if (ve <= vs) ve = line.length();       // 截断行：取到行尾
                    if (ve > line.length()) ve = line.length();
                    String k = line.substring(a + 1, b);
                    String v = line.substring(vs, ve);
                    if (!v.isEmpty()) props.put(k, v);
                } catch (Throwable ignored) { }
            }
        }
        // 先把所有像"芯片型号"的属性收集起来，再统一打分（不再看到第一个就用）
        String[][] cand = {
            // 完整料号最精确（MT6878V_B/TZA 这种），内置表里有 1013 条料号 → 营销名
            {"ro.vendor.soc.model.part_name", ""},
            {"ro.vendor.soc.model.external_name", ""},
            {"ro.vendor.soc.model", ""},
            {"ro.soc.model", ""},
            {"ro.chipname", ""},
            {"ro.hardware.chipname", ""},
            {"ro.board.platform", ""},
            {"ro.product.board", ""},
            {"ro.boot.hardware", ""},
            {"ro.vivo.product.platform", ""},
            {"ro.mediatek.platform", ""},
            {"ro.hardware", ""},
        };
        java.util.LinkedHashMap<String, String> pool = new java.util.LinkedHashMap<>();
        for (String[] c : cand) {
            String v = props.get(c[0]);
            if (v != null && !v.trim().isEmpty() && !"unknown".equalsIgnoreCase(v.trim())) {
                pool.put(c[0], v.trim());
            }
        }
        // 再补几个 Build 字段和 /proc/cpuinfo 的 Hardware 行
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != null && !Build.SOC_MODEL.isEmpty()) {
            pool.put("Build.SOC_MODEL", Build.SOC_MODEL);
        }
        if (Build.HARDWARE != null && !Build.HARDWARE.isEmpty()) pool.put("Build.HARDWARE", Build.HARDWARE);
        String cpuinfo = Shell.exec("grep -i -m1 'Hardware' /proc/cpuinfo 2>/dev/null", 2000);
        if (cpuinfo != null) {
            int c1 = cpuinfo.indexOf(':');
            if (c1 > 0) {
                String hw = cpuinfo.substring(c1 + 1).trim();
                if (!hw.isEmpty()) pool.put("/proc/cpuinfo", hw);
            }
        }

        // GPU 反推厂商，用来交叉校验
        String gpu = HwInfo.gpuRenderer();
        String gpuVendor = vendorOfGpu(gpu);
        info.gpuVendor = gpuVendor;

        // 打分：越"像芯片型号"分越高；手机型号、厂商名、qcom/mtk 这类都扣分
        String bestKey = null, bestVal = null;
        int bestScore = Integer.MIN_VALUE;
        String bestMatchingGpu = null, bestMatchingGpuKey = null;
        int bestMatchingGpuScore = Integer.MIN_VALUE;
        for (java.util.Map.Entry<String, String> e : pool.entrySet()) {
            int sc = score(e.getValue());
            // 内置表能把这个值翻成营销名 → 说明它是可靠标识，加分
            try {
                String mk = ChipArt.tableName(e.getValue());
                if (mk != null && !mk.isEmpty() && !mk.equalsIgnoreCase(e.getValue())
                        && !mk.equalsIgnoreCase("未知")) sc += 5;
            } catch (Throwable ignored) { }
            info.candidates.put(e.getKey(), e.getValue() + "   (" + sc + " 分)");
            if (sc > bestScore) { bestScore = sc; bestKey = e.getKey(); bestVal = e.getValue(); }
            if (!gpuVendor.isEmpty() && gpuVendor.equals(vendorOfModel(e.getValue()))
                    && sc > bestMatchingGpuScore) {
                bestMatchingGpuScore = sc;
                bestMatchingGpu = e.getValue();
                bestMatchingGpuKey = e.getKey();
            }
        }
        if (bestVal != null && bestScore > 0) {
            // 同一个值的多个来源（MT6993 / mt6993）取更像官方字段的那个
            for (java.util.Map.Entry<String, String> e : pool.entrySet()) {
                if (e.getValue().equalsIgnoreCase(bestVal) && "ro.soc.model".equals(e.getKey())) {
                    bestVal = e.getValue();
                    bestKey = e.getKey();
                    break;
                }
            }
            // 规范成大写型号（mt6993 → MT6993）
            if (bestVal != null && bestVal.toUpperCase(Locale.US)
                    .matches("^(SM|SDM|MSM|MT|SC)[0-9A-Z\\-]+$")) {
                bestVal = bestVal.toUpperCase(Locale.US);
            }
            info.raw = bestVal;
            info.source = bestKey;
            // GPU 与型号冲突时，优先信任 GPU 厂商那一侧
            if (bestMatchingGpu != null && !gpuVendor.equals(vendorOfModel(bestVal))
                    && vendorOfModel(bestVal).length() > 0 && bestMatchingGpuScore >= bestScore - 2) {
                info.raw = bestMatchingGpu;
                info.source = bestMatchingGpuKey;
                info.note = "已按 GPU（" + trim(gpu) + "）校正";
            }
        } else {
            info.raw = Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != null ? Build.SOC_MODEL : Build.HARDWARE;
            info.source = "Build";
        }
        info.deviceMarket = firstNonEmpty(props.get("ro.product.marketname"),
                props.get("ro.vendor.oplus.market.name"), props.get("ro.config.marketing_name"),
                props.get("ro.vivo.market.name"), props.get("ro.oppo.market.name"),
                props.get("ro.vivo.product.marketname"), props.get("ro.product.model"));
        String mfr = firstNonEmpty(props.get("ro.soc.manufacturer"), props.get("ro.hardware"));
        fill(info);
        refineByFreq(info);
        if (info.vendor.isEmpty()) {
            String u = mfr == null ? "" : mfr.toLowerCase(Locale.US);
            if (u.contains("qti") || u.contains("qcom")) info.vendor = "Qualcomm";
            else if (u.contains("mtk") || u.contains("mediatek")) info.vendor = "MediaTek";
            else if (u.contains("hisilicon")) info.vendor = "HiSilicon";
            else if (u.contains("samsung")) info.vendor = "Samsung";
            else if (u.contains("google")) info.vendor = "Google";
        }
        return info;
    }

    private static void fill(Info i) {
        String raw = i.raw == null ? "" : i.raw;
        // 交叉验证的结论优先（自动，不需要用户选）
        try {
            SocVerify.Verdict v = SocVerify.cached(DataSource.appContext(), i.raw);
            if (v != null && v.name != null && !v.name.isEmpty()) {
                i.market = v.name;
                i.note = (i.note == null || i.note.isEmpty() ? "" : i.note + "；")
                        + "交叉验证（" + v.confidence + "）";
                if (i.vendor.isEmpty()) {
                    String u = v.name.toUpperCase(Locale.US);
                    if (u.contains("天玑") || u.contains("DIMENSITY")) i.vendor = "MediaTek";
                    else if (u.contains("骁龙") || u.contains("SNAPDRAGON")) i.vendor = "Qualcomm";
                    else if (u.contains("麒麟") || u.contains("KIRIN")) i.vendor = "HiSilicon";
                    else if (u.contains("EXYNOS")) i.vendor = "Samsung";
                }
                return;
            }
        } catch (Throwable ignored) { }
        i.market = ChipArt.marketName(raw.toUpperCase(Locale.US));
        if (i.vendor.isEmpty()) {
            String v = BuiltinMap.vendor(DataSource.appContext(), raw);
            if (!v.isEmpty()) i.vendor = v;
        }
        String u = raw.toUpperCase(Locale.US);
        if (i.vendor.isEmpty()) {
            if (u.startsWith("SM") || u.startsWith("SDM") || u.startsWith("MSM")) i.vendor = "Qualcomm";
            else if (u.startsWith("MT")) i.vendor = "MediaTek";
            else if (u.contains("KIRIN")) i.vendor = "HiSilicon";
            else if (u.contains("EXYNOS")) i.vendor = "Samsung";
            else if (u.contains("TENSOR")) i.vendor = "Google";
        }
    }

    /**
     * 同一颗芯片常有「带 + 的官超版」，光看型号码分不出来，只能看最高主频。
     * 例：MT6989 3.25GHz = 天玑 9300，3.40GHz = 天玑 9300+；MT6991 3.73GHz = 9400+。
     */
    private static void refineByFreq(Info i) {
        if (i == null) return;
        int mhz = maxFreqMhz();
        if (mhz <= 0) return;
        String u = i.raw == null ? "" : i.raw.toUpperCase(Locale.US);
        if (u.startsWith("MT6989") && mhz >= 3350) i.market = "天玑 9300+";
        else if (u.startsWith("MT6991") && mhz >= 3700) i.market = "天玑 9400+";
        else if (u.startsWith("MT6983") && mhz >= 3200) i.market = "天玑 9000+";
        else if (u.startsWith("MT6897") && mhz >= 3200) i.market = "天玑 8300-Ultra";
    }

    private static int maxFreqKhzCache = -1;

    public static int maxFreqMhz() {
        if (maxFreqKhzCache < 0) {
            String out = Shell.exec("for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; "
                    + "do cat $f 2>/dev/null; done | sort -n | tail -1", 3000);
            try {
                maxFreqKhzCache = Integer.parseInt(out == null ? "" : out.trim());
            } catch (Throwable t) {
                maxFreqKhzCache = 0;
            }
        }
        return maxFreqKhzCache / 1000;
    }

    /** 给候选值打分：越像芯片型号分越高。 */
    private static int score(String v) {
        if (v == null) return -100;
        String t = v.trim();
        String u = t.toUpperCase(Locale.US);
        if (t.isEmpty() || "unknown".equalsIgnoreCase(t)) return -100;
        int sc = 0;
        // 典型型号前缀
        boolean looksModel = u.matches("^(SM|SDM|MSM|MT|SC|TENSOR)[0-9A-Z\\-]{2,}.*");
        if (looksModel) sc += 6;
        if (u.contains("KIRIN") || u.contains("EXYNOS") || u.contains("DIMENSITY")) sc += 5;
        // MT6878V_B/TZA 这种带斜杠的完整料号，比基础码更可信
        if (looksModel && t.contains("/")) sc += 3;
        // 平台代号（holi / lahaina / kona…）：只有在不像具体型号时才加分，
        // 否则 mt6993 这种「小写的型号」会比 ro.soc.model 里的 MT6993 得分还高
        if (!looksModel && t.matches("^[a-z][a-z0-9_]{3,15}$")) sc += 3;
        // 和手机型号一样 → 肯定不是芯片
        if (t.equalsIgnoreCase(Build.MODEL) || t.equalsIgnoreCase(Build.DEVICE)) sc -= 8;
        if (u.equals("QCOM") || u.equals("MTK") || u.equals("QUALCOMM") || u.equals("MEDIATEK")) sc -= 4;
        if (u.equals("MTK") || u.endsWith("_64")) sc -= 2;
        return sc + 1;
    }

    private static String vendorOfModel(String v) {
        if (v == null) return "";
        String u = v.toUpperCase(Locale.US);
        if (u.startsWith("SM") || u.startsWith("SDM") || u.startsWith("MSM")) return "Qualcomm";
        if (u.startsWith("MT")) return "MediaTek";
        if (u.contains("KIRIN")) return "HiSilicon";
        if (u.contains("EXYNOS")) return "Samsung";
        if (u.contains("TENSOR")) return "Google";
        if (u.startsWith("SC")) return "Unisoc";
        return "";
    }

    private static String vendorOfGpu(String gpu) {
        if (gpu == null) return "";
        String u = gpu.toUpperCase(Locale.US);
        if (u.contains("ADRENO")) return "Qualcomm";
        if (u.contains("MALI")) return "MediaTek";     // 三星也用 Mali，先按 MTK 记，有型号再校正
        if (u.contains("XCLIPSE") || u.contains("SAMSUNG")) return "Samsung";
        if (u.contains("POWERVR")) return "PowerVR";
        return "";
    }

    private static String trim(String s) {
        if (s == null) return "";
        return s.length() > 28 ? s.substring(0, 28) + "…" : s;
    }

    private static String firstNonEmpty(String... vals) {
        for (String v : vals) if (v != null && !v.isEmpty()) return v;
        return "";
    }

    public static void clear(Context c) {
        cached = null;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
