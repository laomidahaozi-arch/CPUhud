package com.dsh.cpuhud;

/** 颜色与数字格式。 */
public final class Fmt {
    public static final int C_OK = 0xFF7CFFB2, C_WARM = 0xFFBFFA5A, C_HOT = 0xFFFFE066,
            C_HOTTER = 0xFFFFA94D, C_CRIT = 0xFFFF6B6B, C_PANIC = 0xFFFF3B3B, C_DIM = 0xFF9FB0C7;

    public static int tempColor(double t) {
        if (t <= 0) return C_DIM;
        if (t < 42) return C_OK;
        if (t < 52) return C_WARM;
        if (t < 62) return C_HOT;
        if (t < 72) return C_HOTTER;
        if (t < 82) return C_CRIT;
        return C_PANIC;
    }

    public static String t1(double v) { return String.format(java.util.Locale.US, "%.1f", v); }

    public static String ghz(double mhz) { return String.format(java.util.Locale.US, "%.2f", mhz / 1000.0); }

    public static String g1(double v) { return String.format(java.util.Locale.US, "%.1f", v); }

    public static String pad2(double v) { return String.format(java.util.Locale.US, "%2d", (int) Math.round(v)); }
}
