#!/bin/sh
# 手工打 APK：javac -> d8 -> 手写 AXML 清单 -> zip -> apksigner（不需要 aapt2）
# 用法：在本文件所在目录的任意位置执行 sh src/apk/build.sh
set -e
APP=$(cd "$(dirname "$0")/../.." && pwd)      # /sdcard/dsh/cpuhud
ROOT="$APP"
SDK=/root/sdk
JDK=/root/jdk
AJAR=$SDK/platform/android-35/android.jar
D8=$SDK/bt/android-14/lib/d8.jar
SIGNER=$SDK/bt/android-14/lib/apksigner.jar
OUT=$APP/out
rm -rf "$OUT/classes" "$OUT/dex"; mkdir -p "$OUT/classes" "$OUT/dex"

echo "== javac =="
"$JDK/bin/javac" -nowarn -source 8 -target 8 -classpath "$AJAR:$APP/src/apk/shizuku-api.jar:$APP/src/apk/shizuku-provider.jar:$APP/src/apk/shizuku-aidl.jar:$APP/src/apk/shizuku-shared.jar" -d "$OUT/classes" \
  $(find "$APP/src" -maxdepth 1 -name '*.java')

echo "== d8 =="
"$JDK/bin/java" -Xmx2g -cp "$D8" com.android.tools.r8.D8 \
  --release --min-api 26 --lib "$AJAR" --output "$OUT/dex" $(find "$OUT/classes" -name '*.class') \
  "$APP/src/apk/shizuku-api.jar" "$APP/src/apk/shizuku-provider.jar" "$APP/src/apk/shizuku-aidl.jar" "$APP/src/apk/shizuku-shared.jar"

echo "== AndroidManifest.xml (AXML) =="
node --input-type=module -e "
import { writeAxml } from '$APP/src/apk/axml.mjs';
import { manifestRoot } from '$APP/src/apk/manifest.mjs';
console.log('manifest bytes:', writeAxml('$OUT/AndroidManifest.xml', manifestRoot));
"

echo "== zip =="
python3 - "$OUT" "$APP/assets" <<'PY'
import sys, zipfile, os
out, assets = sys.argv[1], sys.argv[2]
apk = os.path.join(out, 'cpuhud-unsigned.apk')
n_assets = 0
with zipfile.ZipFile(apk, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(os.path.join(out, 'AndroidManifest.xml'), 'AndroidManifest.xml')
    z.write(os.path.join(out, 'dex', 'classes.dex'), 'classes.dex')
    if os.path.isdir(assets):
        for root, _, files in os.walk(assets):
            for f in sorted(files):
                p = os.path.join(root, f)
                rel = os.path.relpath(p, assets).replace(os.sep, '/')
                z.write(p, 'assets/' + rel)
                n_assets += 1
print('apk bytes:', os.path.getsize(apk), 'assets:', n_assets)
PY

KS=$APP/hud.jks
if [ ! -f "$KS" ]; then
  "$JDK/bin/keytool" -genkeypair -keystore "$KS" -alias hud -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass android -keypass android \
    -dname "CN=CPU HUD, OU=DSH, O=DSH, L=CN, ST=CN, C=CN" >/dev/null 2>&1
fi

echo "== sign =="
"$JDK/bin/java" -jar "$SIGNER" sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$OUT/cpuhud.apk" "$OUT/cpuhud-unsigned.apk"
ls -l "$OUT/cpuhud.apk"
# verify version：防止打包失败却拿着旧包
python3 - "$OUT/cpuhud.apk" <<'PYV'
import sys, zipfile, re
m = zipfile.ZipFile(sys.argv[1]).read('AndroidManifest.xml').decode('utf-16-le', 'ignore')
print('verify version =', re.findall(r'1\.\d+\.\d+', m))
PYV
