package com.dsh.cpuhud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/**
 * 双轴曲线：左轴=功耗(W，绝对值)，右轴=帧率。
 * 功耗按充/放电分段：充电绿、放电橙，切换处断开不连线。
 */
public class SparkChart extends View {
    private float[] fps = new float[0];
    private float[] pw = new float[0];
    private float maxFps = 120f;
    private float maxW = 6f;

    private final Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pGrid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path area = new Path();
    private final Path seg = new Path();

    private int cAccent = Theme.accent();
    private int cText = Theme.dim2();
    private int cGrid = 0x33FFFFFF;
    private int cCharge = Theme.good();
    private int cDischarge = Theme.hot();
    private boolean darkTheme = true;
    private boolean showGrid = true;

    public SparkChart(Context c) {
        super(c);
        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(dp(1.4f));
        pLine.setStrokeCap(Paint.Cap.ROUND);
        pLine.setStrokeJoin(Paint.Join.ROUND);
        pGrid.setColor(cGrid);
        pGrid.setStrokeWidth(dp(0.7f));
        pText.setColor(cText);
        pText.setTextSize(dp(7.5f));
        pText.setTypeface(Typeface.MONOSPACE);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private float dp(float v) {
        return getResources().getDisplayMetrics().density * v;
    }

    public void setGrid(boolean on) { this.showGrid = on; invalidate(); }

    public void setPalette(boolean dark, int accent) {
        this.darkTheme = dark;
        this.cAccent = accent;
        pGrid.setColor(dark ? 0x1AFFFFFF : 0x22000000);
        pText.setColor(Theme.isLight() ? 0xFF5B6B7C : 0xFF8A9BB0);
        invalidate();
    }

    /** 主界面用：强调色 / 刻度文字 / 网格 / 充电线 / 放电线，全部跟随 App 配色。 */
    public void setColors(int accent, int text, int grid, int charge, int discharge) {
        this.cAccent = accent;
        this.cText = text;
        this.cGrid = grid;
        this.cCharge = charge;
        this.cDischarge = discharge;
        pText.setColor(text);
        pGrid.setColor(grid);
        invalidate();
    }

    public void setData(float[] fps, float[] pw, float dispRate) {
        this.fps = fps != null ? fps : new float[0];
        this.pw = pw != null ? pw : new float[0];
        this.maxFps = dispRate > 0 ? dispRate : 120f;
        float mw = 1f;
        for (float v : this.pw) mw = Math.max(mw, Math.abs(v));
        this.maxW = Math.max(2f, (float) (Math.ceil(mw / 2.0) * 2.0));
        invalidate();
    }

    private String wLabel(float v) {
        if (v >= 10) return String.valueOf(Math.round(v));
        return String.format(java.util.Locale.US, "%.0f", v);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float bottom = h - dp(1.5f);
        float leftG = dp(15f), rightG = dp(19f);
        float x0 = leftG;
        float plotW = Math.max(dp(10), w - leftG - rightG);

        // 左轴：功耗 0 ~ maxW
        pText.setTextAlign(Paint.Align.LEFT);
        c.drawText(wLabel(maxW) + "W", dp(1), dp(7f), pText);
        c.drawText(wLabel(maxW / 2f), dp(1), bottom / 2f + dp(2.6f), pText);
        c.drawText("0", dp(1), bottom, pText);

        // 右轴：帧率 0 ~ maxFps
        pText.setTextAlign(Paint.Align.RIGHT);
        c.drawText(String.valueOf(Math.round(maxFps)), w - dp(1), dp(7f), pText);
        c.drawText(String.valueOf(Math.round(maxFps / 2f)), w - dp(1), bottom / 2f + dp(2.6f), pText);
        c.drawText("0", w - dp(1), bottom, pText);
        pText.setTextAlign(Paint.Align.LEFT);

        if (showGrid) {
            c.drawLine(x0, 0, x0 + plotW, 0, pGrid);
            c.drawLine(x0, bottom / 2f, x0 + plotW, bottom / 2f, pGrid);
            c.drawLine(x0, bottom, x0 + plotW, bottom, pGrid);
        }

        int n = fps.length;
        if (n >= 2) {
            float stepX = plotW / (float) (n - 1);
            area.reset();
            path.reset();
            for (int i = 0; i < n; i++) {
                float x = x0 + i * stepX;
                float y = bottom - Math.min(fps[i] / maxFps, 1f) * bottom;
                if (i == 0) { path.moveTo(x, y); area.moveTo(x, bottom); area.lineTo(x, y); }
                else { path.lineTo(x, y); area.lineTo(x, y); }
            }
            area.lineTo(x0 + plotW, bottom);
            area.close();
            int a1 = (cAccent & 0x00FFFFFF) | 0x55000000;
            pFill.setShader(new LinearGradient(0, 0, 0, bottom, a1, 0x00000000, Shader.TileMode.CLAMP));
            c.drawPath(area, pFill);
            pLine.setColor(cAccent);
            c.drawPath(path, pLine);

            float lx = x0 + (n - 1) * stepX;
            float ly = bottom - Math.min(fps[n - 1] / maxFps, 1f) * bottom;
            pDot.setColor(cAccent);
            c.drawCircle(lx, ly, dp(2f), pDot);
        } else {
            c.drawText("等待曲线…", x0 + dp(2), bottom / 2f + dp(3), pText);
        }

        // 功耗：按符号分段画，充电/放电之间断开（不连线）
        int m = pw.length;
        if (m >= 2) {
            float sx = plotW / (float) (m - 1);
            int idx = 0;
            while (idx < m) {
                int sign = pw[idx] >= 0 ? 1 : -1;
                seg.reset();
                seg.moveTo(x0 + idx * sx, bottom - Math.min(Math.abs(pw[idx]) / maxW, 1f) * bottom);
                int k = idx + 1;
                while (k < m && ((pw[k] >= 0 ? 1 : -1) == sign)) {
                    seg.lineTo(x0 + k * sx, bottom - Math.min(Math.abs(pw[k]) / maxW, 1f) * bottom);
                    k++;
                }
                pLine.setColor(sign > 0 ? cCharge : cDischarge);
                c.drawPath(seg, pLine);
                idx = k;
            }
        }
    }
}
