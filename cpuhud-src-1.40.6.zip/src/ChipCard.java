package com.dsh.cpuhud;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** CPU-Z 风格的芯片名片：左边画一颗芯片，右边是型号和「点击查看官网」。 */
public class ChipCard extends LinearLayout {
    private final ChipIcon icon;
    private final TextView title, sub, hint;
    private String url = "";

    public ChipCard(Context c, int accent, boolean dark) {
        super(c);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card2());
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), (accent & 0x00FFFFFF) | 0x66000000);
        setBackground(bg);

        icon = new ChipIcon(c, accent, dark);
        addView(icon, new LayoutParams(dp(58), dp(58)));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(VERTICAL);
        LayoutParams clp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = dp(12);
        col.setLayoutParams(clp);

        title = new TextView(c);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        title.setTextColor(Theme.strong());
        title.setMaxLines(1);
        col.addView(title);

        sub = new TextView(c);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        sub.setTextColor(Theme.dim2());
        sub.setMaxLines(1);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setPadding(0, dp(2), 0, 0);
        col.addView(sub);

        hint = new TextView(c);
        hint.setText("点击查看官方参数 ↗");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        hint.setTextColor((accent & 0x00FFFFFF) | 0xCC000000);
        hint.setPadding(0, dp(3), 0, 0);
        col.addView(hint);
        addView(col);

        setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                open(v.getContext());
            }
        });
    }

    public void bind(String name, String subtitle, String link) {
        title.setText(name == null || name.isEmpty() ? "未知" : name);
        sub.setText(subtitle == null ? "" : subtitle);
        url = link == null ? "" : link;
    }

    private void open(Context c) {
        if (url.isEmpty()) {
            Toast.makeText(c, "没有找到对应的官方页面", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(c, "没有可用浏览器：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    /** 用 Canvas 画一颗带引脚的芯片。 */
    static class ChipIcon extends View {
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pin = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint die = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int accent;
        private final boolean dark;

        ChipIcon(Context c, int accent, boolean dark) {
            super(c);
            this.accent = accent;
            this.dark = dark;
            pin.setStrokeWidth(d(1.6f));
            pin.setStrokeCap(Paint.Cap.ROUND);
            pin.setColor((accent & 0x00FFFFFF) | 0x99000000);
        }

        private float d(float v) {
            return getResources().getDisplayMetrics().density * v;
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float s = Math.min(w, h) * 0.66f;          // 芯片本体边长
            float half = s / 2f;
            float pinLen = Math.min(w, h) * 0.12f;

            // 引脚
            int n = 4;
            for (int i = 0; i < n; i++) {
                float off = -half + s * (i + 0.5f) / n;
                c.drawLine(cx + off, cy - half, cx + off, cy - half - pinLen, pin);
                c.drawLine(cx + off, cy + half, cx + off, cy + half + pinLen, pin);
                c.drawLine(cx - half, cy + off, cx - half - pinLen, cy + off, pin);
                c.drawLine(cx + half, cy + off, cx + half + pinLen, cy + off, pin);
            }

            // 本体
            body.setColor(Theme.card());
            RectF r = new RectF(cx - half, cy - half, cx + half, cy + half);
            c.drawRoundRect(r, d(4), d(4), body);
            body.setStyle(Paint.Style.STROKE);
            body.setStrokeWidth(d(1.2f));
            body.setColor(accent);
            c.drawRoundRect(r, d(4), d(4), body);
            body.setStyle(Paint.Style.FILL);

            // 中间的 die
            die.setColor((accent & 0x00FFFFFF) | 0x55000000);
            float ds = s * 0.42f;
            c.drawRoundRect(new RectF(cx - ds / 2, cy - ds / 2, cx + ds / 2, cy + ds / 2), d(2), d(2), die);

            // 定位点
            die.setColor(accent);
            c.drawCircle(cx - half + d(6), cy - half + d(6), d(2f), die);
        }
    }

    /** 根据 SoC 型号猜官网地址。 */
    public static String socUrl(String soc) {
        if (soc == null) return "";
        String s = soc.toUpperCase(Locale.US);
        if (s.startsWith("MT") || s.contains("DIMENSITY") || s.contains("HELIO"))
            return "https://www.mediatek.com/products/smartphones";
        if (s.startsWith("SM") || s.startsWith("SDM") || s.startsWith("MSM") || s.contains("SNAPDRAGON"))
            return "https://www.qualcomm.com/products/mobile/snapdragon";
        if (s.contains("EXYNOS"))
            return "https://www.samsung.com/semiconductor/minisite/exynos/";
        if (s.contains("KIRIN"))
            return "https://www.hisilicon.com/en/products/Kirin";
        if (s.contains("UNISOC") || s.startsWith("SC9") || s.contains("TIGER"))
            return "https://www.unisoc.com/";
        if (s.contains("TENSOR"))
            return "https://store.google.com/category/phones";
        if (s.contains("RK") || s.contains("ROCKCHIP"))
            return "https://www.rock-chips.com/";
        return "https://www.bing.com/search?q=" + Uri.encode(soc + " 参数 规格");
    }

    /** GPU 厂商官网。 */
    public static String gpuUrl(String gpu) {
        if (gpu == null) return "";
        String s = gpu.toUpperCase(Locale.US);
        if (s.contains("MALI"))
            return "https://www.arm.com/products/silicon-ip-multimedia";
        if (s.contains("ADRENO"))
            return "https://www.qualcomm.com/products/mobile/snapdragon";
        if (s.contains("POWERVR"))
            return "https://www.imaginationtech.com/products/gpu/";
        if (s.contains("XCLIPSE"))
            return "https://www.imaginationtech.com/products/gpu/";
        if (s.contains("APPLE"))
            return "https://www.apple.com/";
        return "https://www.bing.com/search?q=" + Uri.encode(gpu + " GPU 参数");
    }
}
