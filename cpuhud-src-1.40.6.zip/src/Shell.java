package com.dsh.cpuhud;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * 统一 shell 入口：优先 root（su），没有 root 就用 Shizuku。
 * root 不受 SELinux 限制，能读到更多 /sys、/proc 节点。
 */
public final class Shell {
    private Shell() { }

    private static int rootState = -1;      // -1 未知, 0 无, 1 有
    private static String lastError = "";

    private static long lastCheck = 0;

    public static boolean hasRoot() {
        if (rootState == 1) return true;                       // 已确认，永久生效
        long now = System.currentTimeMillis();
        if (rootState == 0 && now - lastCheck < 60000) return false;  // 60 秒内不重复探测
        lastCheck = now;
        rootState = checkRoot() ? 1 : 0;
        return rootState == 1;
    }

    /**
     * 探测 root：`su -c id` 输出里含 uid=0 才算。
     *
     * 临时 root 工具的 su 常常不在 PATH 里（放在 /data/local/tmp/su、/debug_ramdisk/su 等），
     * 所以这里按常见路径逐个试，并把「试了哪些、为什么失败」记下来给诊断页看。
     */
    private static final String[] SU_PATHS = {
            "su",
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/su/bin/su",
            "/debug_ramdisk/su",
            "/data/local/tmp/su",
            "/data/adb/ksu/bin/su",
            "/data/adb/ap/bin/su",
    };
    private static String rootVia = "";

    private static boolean checkRoot() {
        StringBuilder tried = new StringBuilder();
        for (String su : SU_PATHS) {
            Process p = null;
            try {
                p = new ProcessBuilder(su, "-c", "id").redirectErrorStream(true).start();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[512];
                long end = System.currentTimeMillis() + 2500;
                InputStream in = p.getInputStream();
                int n;
                while (System.currentTimeMillis() < end && (n = in.read(buf)) > 0) bo.write(buf, 0, n);
                String out = bo.toString("UTF-8").trim();
                if (out.contains("uid=0")) {
                    rootVia = su;
                    lastError = "";
                    return true;
                }
                tried.append(su).append(':').append(out.isEmpty() ? "空" : firstLine(out)).append("  ");
            } catch (Throwable t) {
                tried.append(su).append(':').append(t.getClass().getSimpleName()).append("  ");
            } finally {
                if (p != null) { try { p.destroy(); } catch (Throwable ignored) { } }
            }
        }
        // 还有一种情况：App 进程本身就以 root 身份在跑（某些临时 root 直接提权 App）
        try {
            String who = execDirect("id");
            if (who != null && who.contains("uid=0")) {
                rootVia = "当前进程已是 root";
                lastError = "";
                return true;
            }
        } catch (Throwable ignored) { }
        rootVia = "";
        lastError = "su 全部失败 → " + (tried.length() > 220 ? tried.substring(0, 220) : tried.toString());
        return false;
    }

    private static String firstLine(String s) {
        int i = s.indexOf('\n');
        return i > 0 ? s.substring(0, i) : s;
    }

    /** 直接执行（不走 su），用于判断本进程是否已是 root。 */
    private static String execDirect(String cmd) {
        Process p = null;
        try {
            p = new ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start();
            InputStream in = p.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int n;
            long end = System.currentTimeMillis() + 1500;
            while (System.currentTimeMillis() < end && (n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (p != null) { try { p.destroy(); } catch (Throwable ignored) { } }
        }
    }

    /** 用哪个 su 拿到 root 的（诊断用）。 */
    public static String rootVia() { return rootVia; }

    public static boolean available() { return hasRoot() || ShizukuShell.granted(); }

    /** 当前生效的数据源名：Root / Shizuku / 空。 */
    public static String sourceName() {
        if (hasRoot()) return "Root";
        if (ShizukuShell.granted()) return "Shizuku";
        return "";
    }

    public static String err() { return lastError.isEmpty() ? ShizukuShell.err() : lastError; }

    /** 优先 root，失败再落 Shizuku。 */
    public static String exec(String cmd, long timeoutMs) {
        if (hasRoot()) {
            String out = suExec(cmd, timeoutMs);
            if (out != null) return out;
            rootState = 0;                      // root 失效，降级
        }
        return ShizukuShell.exec(cmd, timeoutMs);
    }

    private static String suExec(String cmd, long timeoutMs) {
        Process p = null;
        try {
            p = new ProcessBuilder(rootVia.isEmpty() ? "su" : rootVia, "-c", cmd)
                    .redirectErrorStream(true).start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            InputStream in = p.getInputStream();
            byte[] buf = new byte[16384];
            long deadline = System.currentTimeMillis() + timeoutMs;
            int n;
            while (System.currentTimeMillis() < deadline && (n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            String out = bo.toString("UTF-8");
            return out.isEmpty() ? null : out;
        } catch (Throwable t) {
            lastError = t.toString();
            return null;
        } finally {
            if (p != null) { try { p.destroy(); } catch (Throwable ignored) { } }
        }
    }
}
