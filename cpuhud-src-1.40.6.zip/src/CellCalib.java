package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 双电池 / 串联电池校准。
 * 现象：部分双电芯机型上报的电流是"单电芯"或"两颗相加"，直接乘电压会让功耗差一倍。
 * 做法：自动初判 + 用户手动勾选 + 可调除数，最终作用于 currentMa 与 powerW。
 */
public final class CellCalib {
    private CellCalib() { }

    public static final String PREF = "hud";
    public static final String KEY_ON = "cellSeries";
    public static final String KEY_DIV = "cellDiv";
    public static final String KEY_AUTO = "cellAuto";

    /** 自动判定：电压 > 5.0V 基本可判定为串联双电芯（单芯满电也就 4.4V 左右）。 */
    public static boolean detectSeries(Snapshot s) {
        if (s == null) return false;
        if (s.voltV > 5.0) return true;
        // 电量 100% 时 charge counter 接近两倍设计容量，也视为双电芯
        return false;
    }

    public static boolean enabled(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return p.getBoolean(KEY_ON, false);
    }

    public static int divisor(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        int d = p.getInt(KEY_DIV, 2);
        return d < 1 ? 1 : Math.min(d, 4);
    }

    /** 把校准应用到一帧数据（电流与功耗同时缩放）。 */
    public static void apply(Context ctx, Snapshot s) {
        if (ctx == null || s == null) return;
        if (!enabled(ctx)) return;
        int d = divisor(ctx);
        if (d <= 1) return;
        s.currentMa = s.currentMa / d;
        s.powerW = s.powerW / d;
    }

    public static void set(Context ctx, boolean on, int div) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ON, on)
                .putInt(KEY_DIV, Math.max(1, Math.min(div, 4)))
                .apply();
    }
}
