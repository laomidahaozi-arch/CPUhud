package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 主界面配色：12 个角色，全部可自定义。
 *
 * <p>存在独立的偏好文件 "ui" 里 —— 悬浮窗用的是 "hud"（不透明度 / 强调色 / 圆角等），
 * 两边完全分开，改主界面配色不会动到悬浮窗。
 *
 * <p>每个 Activity 在 onCreate 里先 load，再取色；onResume 里重新 load 一次，
 * 签名变了就 recreate()，从配色页返回即时生效。
 */
public final class Theme {
    public static final int BG = 0, CARD = 1, CARD2 = 2, TEXT = 3, STRONG = 4, DIM = 5, DIM2 = 6,
            ACCENT = 7, GOOD = 8, WARN = 9, BAD = 10, HOT = 11;

    private static final String PREFS = "ui";

    public static final String[] KEYS = {"ui_bg", "ui_card", "ui_card2", "ui_text", "ui_strong",
            "ui_dim", "ui_dim2", "ui_accent", "ui_good", "ui_warn", "ui_bad", "ui_hot"};

    /** 角色名（配色页显示用）。 */
    public static final String[] NAMES = {"背景", "卡片 / 按钮", "深层卡片", "正文", "标题",
            "次要文字", "提示文字", "强调色", "正常 / 成功", "警告", "错误", "高亮橙"};

    /** 每项一句话说明它管哪里。 */
    public static final String[] DESC = {"整页底色", "按钮、输入框、卡片底", "对话框、次级面板底",
            "数据正文", "大标题", "标签、说明文字", "更淡的脚注", "曲线、数值高亮", "在线 / 成功",
            "降级 / 待授权", "失败 / 冲突", "充电 / GPU / 高温"};

    public static final int[] DEF = {
            0xFF0E1319, 0xFF1B2430, 0xFF161E27, 0xFFDCE6F2, 0xFFEAF2FF,
            0xFF9FB0C7, 0xFF6F8098, 0xFF5AD1FF, 0xFF7CFFB2, 0xFFFFE066, 0xFFFF8F8F, 0xFFFFB25A};

    public static final String[] PRESETS = {"夜色蓝", "纯黑", "雪白", "紫夜", "极光绿", "蒸汽波", "落日橙"};

    public static final int[][] PRESET_COLORS = {
            // 夜色蓝（出厂）
            {0xFF0E1319, 0xFF1B2430, 0xFF161E27, 0xFFDCE6F2, 0xFFEAF2FF,
                    0xFF9FB0C7, 0xFF6F8098, 0xFF5AD1FF, 0xFF7CFFB2, 0xFFFFE066, 0xFFFF8F8F, 0xFFFFB25A},
            // 纯黑（省电 / OLED）
            {0xFF000000, 0xFF121214, 0xFF1A1A1D, 0xFFEDEDED, 0xFFFFFFFF,
                    0xFF9C9C9C, 0xFF6E6E6E, 0xFF4FC3F7, 0xFF69F0AE, 0xFFFFD740, 0xFFFF5252, 0xFFFFAB40},
            // 雪白（浅色）
            {0xFFF2F5F9, 0xFFFFFFFF, 0xFFF7F9FC, 0xFF22303C, 0xFF0F1720,
                    0xFF52606D, 0xFF7B8794, 0xFF0B84D8, 0xFF12855C, 0xFFB26A00, 0xFFC62828, 0xFFD35400},
            // 紫夜
            {0xFF140E1E, 0xFF241933, 0xFF1B1226, 0xFFE7DCF5, 0xFFF5EEFF,
                    0xFFA896C0, 0xFF7C6B93, 0xFFC084FC, 0xFF86EFAC, 0xFFFDE68A, 0xFFFB7185, 0xFFFBBF24},
            // 极光绿
            {0xFF04140F, 0xFF0C2A20, 0xFF08201A, 0xFFD9F5E7, 0xFFECFFF6,
                    0xFF8FBFA8, 0xFF5F8C78, 0xFF34D399, 0xFFA7F3D0, 0xFFFCD34D, 0xFFFB7185, 0xFFF59E0B},
            // 蒸汽波
            {0xFF1A0B2E, 0xFF2D1045, 0xFF241038, 0xFFF5E1FF, 0xFFFFF0FF,
                    0xFFC7A6E0, 0xFF9678B0, 0xFFFF6BD6, 0xFF5EEAD4, 0xFFFDE047, 0xFFFF5C8A, 0xFFFF9F1C},
            // 落日橙
            {0xFF1C1108, 0xFF2E1B0E, 0xFF23150B, 0xFFF6E6D8, 0xFFFFF4E8,
                    0xFFBFA48E, 0xFF8E7461, 0xFFFF9F1C, 0xFF8BE9A6, 0xFFFFD166, 0xFFFF6B6B, 0xFFFFB25A},
    };

    /** 跟手机取色：0=关，1=手机主题色（Material You），2=壁纸取色。 */
    public static final int FOLLOW_OFF = 0, FOLLOW_MATERIAL = 1, FOLLOW_WALLPAPER = 2;

    private static final int[] CUR = DEF.clone();
    private static int sig = 1;
    private static int followMode = FOLLOW_OFF;

    private Theme() { }

    /** 读一次偏好，刷新全部角色并算出签名（给 Activity 判断要不要 recreate）。 */
    public static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        followMode = p.getInt("ui_follow", FOLLOW_OFF);
        int[] auto = null;
        if (followMode == FOLLOW_MATERIAL) auto = SysTheme.material(c);
        else if (followMode == FOLLOW_WALLPAPER) auto = SysTheme.wallpaper(c);
        int s = 17;
        for (int i = 0; i < CUR.length; i++) {
            int v = (auto != null && i < auto.length) ? auto[i] : p.getInt(KEYS[i], DEF[i]);
            if ((v >>> 24) == 0) v |= 0xFF000000;      // 透明的一律补满不透明度
            CUR[i] = v;
            s = s * 131 + v;
        }
        sig = s;
    }

    /** 当前跟随模式。 */
    public static int follow(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("ui_follow", FOLLOW_OFF);
    }

    /** 切换到某个跟随模式（取不到就自动退回关闭）。返回是否成功。 */
    public static boolean setFollow(Context c, int mode) {
        if (mode == FOLLOW_MATERIAL && SysTheme.material(c) == null) return false;
        if (mode == FOLLOW_WALLPAPER && SysTheme.wallpaper(c) == null) return false;
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("ui_follow", mode).apply();
        followMode = mode;
        if (mode == FOLLOW_OFF) lockIn(c);
        return true;
    }

    /** 关掉跟随前，把当前这套颜色原样存下来，避免界面突然跳回出厂色。 */
    private static void lockIn(Context c) {
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        for (int i = 0; i < CUR.length; i++) e.putInt(KEYS[i], CUR[i]);
        e.putInt("ui_follow", FOLLOW_OFF).apply();
    }

    public static int sig() { return sig; }

    public static int color(int role) {
        return CUR[role >= 0 && role < CUR.length ? role : 0];
    }

    public static String hex(int color) {
        return String.format(java.util.Locale.US, "#%06X", color & 0x00FFFFFF);
    }

    /** 具名取色，代码里读起来清楚。 */
    public static int bg() { return CUR[BG]; }
    public static int card() { return CUR[CARD]; }
    public static int card2() { return CUR[CARD2]; }
    public static int text() { return CUR[TEXT]; }
    public static int strong() { return CUR[STRONG]; }
    public static int dim() { return CUR[DIM]; }
    public static int dim2() { return CUR[DIM2]; }
    public static int accent() { return CUR[ACCENT]; }
    public static int good() { return CUR[GOOD]; }
    public static int warn() { return CUR[WARN]; }
    public static int bad() { return CUR[BAD]; }
    public static int hot() { return CUR[HOT]; }

    /** 亮色配色（决定曲线的网格 / 文字用黑还是白）。 */
    public static boolean isLight() {
        int c = bg();
        double l = 0.299 * ((c >> 16) & 0xFF) + 0.587 * ((c >> 8) & 0xFF) + 0.114 * (c & 0xFF);
        return l > 140;
    }

    /** 某个角色改成这个颜色（立即落盘）。 */
    public static void set(Context c, int role, int color) {
        if (role < 0 || role >= CUR.length) return;
        if (followMode != FOLLOW_OFF) lockIn(c);      // 手动改色 = 退出跟随
        CUR[role] = color | 0xFF000000;
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEYS[role], CUR[role]).apply();
    }

    /** 整页换成某个预设。 */
    public static void applyPreset(Context c, int idx) {
        if (idx < 0 || idx >= PRESET_COLORS.length) return;
        followMode = FOLLOW_OFF;
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putInt("ui_follow", FOLLOW_OFF);
        for (int i = 0; i < PRESET_COLORS[idx].length; i++) {
            CUR[i] = PRESET_COLORS[idx][i];
            e.putInt(KEYS[i], CUR[i]);
        }
        e.apply();
    }

    /** 全部恢复出厂配色。 */
    public static void resetAll(Context c) {
        followMode = FOLLOW_OFF;
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putInt("ui_follow", FOLLOW_OFF);
        for (int i = 0; i < KEYS.length; i++) {
            CUR[i] = DEF[i];
            e.remove(KEYS[i]);
        }
        e.apply();
    }

    /** 单角色恢复出厂。 */
    public static void resetOne(Context c, int role) {
        if (role < 0 || role >= CUR.length) return;
        if (followMode != FOLLOW_OFF) lockIn(c);
        CUR[role] = DEF[role];
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEYS[role]).apply();
    }

    /** 是否还是出厂配色（用于按钮文案）。 */
    public static boolean isDefault() {
        for (int i = 0; i < CUR.length; i++) if (CUR[i] != DEF[i]) return false;
        return true;
    }
}
