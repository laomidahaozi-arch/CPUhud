package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 芯片「交叉验证」：把几路互相独立的证据摆在一起比对，直接给结论 + 置信度，不让用户做选择。
 *
 * 证据来源：
 *   1. 型号码（MT6878）→ 内置表给出的系列名
 *   2. GPU（Mali-G615 MC2）→ 厂商是否一致 + 属于哪个平台档位
 *   3. 最高主频 / 核心构成 → 和候选是否对得上
 *   4. 联网搜索结果 → 网页里反复出现的型号名（按出现次数投票）
 *
 * 规则：谁能同时被 GPU 和型号码支持，就采谁；互相冲突就保留本地结论并标「中/低」，同时把冲突写进证据里。
 */
public final class SocVerify {

    public static final class Verdict {
        public String code = "";          // 型号码
        public String name = "";          // 结论
        public String confidence = "中";  // 高 / 中 / 低
        public String note = "";
        public final List<String[]> evidence = new ArrayList<>();  // {项目, 结果, 状态}
        public long ts = 0;

        String toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("code", code);
                o.put("name", name);
                o.put("confidence", confidence);
                o.put("note", note);
                o.put("ts", ts);
                JSONArray arr = new JSONArray();
                for (String[] r : evidence) {
                    JSONArray one = new JSONArray();
                    one.put(r[0]); one.put(r[1]); one.put(r[2]);
                    arr.put(one);
                }
                o.put("ev", arr);
                return o.toString();
            } catch (Throwable t) {
                return "";
            }
        }

        static Verdict fromJson(String s) {
            try {
                JSONObject o = new JSONObject(s);
                Verdict v = new Verdict();
                v.code = o.optString("code");
                v.name = o.optString("name");
                v.confidence = o.optString("confidence", "中");
                v.note = o.optString("note", "");
                v.ts = o.optLong("ts", 0);
                JSONArray arr = o.optJSONArray("ev");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONArray one = arr.optJSONArray(i);
                        if (one != null && one.length() >= 3) {
                            v.evidence.add(new String[]{one.optString(0), one.optString(1), one.optString(2)});
                        }
                    }
                }
                return v;
            } catch (Throwable t) {
                return null;
            }
        }
    }

    private static final String PREF = "soc_verify";
    private static final long TTL = 24L * 3600 * 1000;

    private SocVerify() { }

    public static Verdict cached(Context c, String code) {
        if (c == null) return null;
        String s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("verdict", "");
        if (s.isEmpty()) return null;
        Verdict v = Verdict.fromJson(s);
        if (v == null || v.name.isEmpty()) return null;
        if (code != null && !code.isEmpty() && !code.equalsIgnoreCase(v.code)) return null;
        return v;
    }

    public static Verdict cachedFresh(Context c, String code) {
        Verdict v = cached(c, code);
        if (v == null) return null;
        if (System.currentTimeMillis() - v.ts > TTL) return null;
        return v;
    }

    public static void save(Context c, Verdict v) {
        if (c == null || v == null) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("verdict", v.toJson()).apply();
    }

    public static void clear(Context c) {
        if (c == null) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("verdict").apply();
    }

    // ---------------------------------------------------------------- 主流程（阻塞，后台线程）

    public static Verdict verify(Context c, SocProbe.Info soc, String marketName, boolean network) {
        Verdict v = new Verdict();
        v.code = soc == null ? "" : soc.raw;
        v.ts = System.currentTimeMillis();
        String gpu = HwInfo.gpuRenderer();
        int mhz = SocProbe.maxFreqMhz();

        String tableName = soc == null ? "" : soc.market;
        String gpuVendor = vendorOfGpu(gpu);
        String socVendor = soc == null ? "" : soc.vendor;

        // 0) 机型库：机型码/代号 → 处理器（官方规格核对过，优先级最高）
        DeviceSocMap.Hit dev = DeviceSocMap.lookup(c, android.os.Build.MODEL, android.os.Build.DEVICE);
        if (dev != null) {
            v.evidence.add(new String[]{"机型库",
                    (dev.device.isEmpty() ? dev.key : dev.device) + " → " + dev.soc
                            + (dev.source.isEmpty() ? "" : "（" + dev.source + "）"), "✔"});
        }

        // 1) 型号码
        v.evidence.add(new String[]{"型号码", nz(v.code) + (tableName.isEmpty() ? "" : " → " + tableName),
                tableName.isEmpty() ? "⚠" : "✔"});
        // 2) GPU 厂商
        boolean gpuOk = gpuVendor.isEmpty() || socVendor.isEmpty() || gpuVendor.equals(socVendor);
        v.evidence.add(new String[]{"GPU", nz(gpu) + (gpuVendor.isEmpty() ? "" : "（" + gpuVendor + "）"),
                gpuOk ? "✔" : "⚠"});
        // 3) 主频 / 核心
        v.evidence.add(new String[]{"主频", mhz > 0 ? mhz + " MHz" : "读不到", mhz > 0 ? "✔" : "—"});

        String name = dev != null ? dev.soc : tableName;
        String conf = dev != null ? "高" : (gpuOk ? "中" : "低");
        String note = dev != null ? "按机型库确定（官方规格）" : "";

        // 4) 联网
        SocOnline.Hit hit = null;
        if (network) {
            hit = SocOnline.lookup(c, marketName, v.code, android.os.Build.DEVICE);
            if (hit != null && !hit.soc.isEmpty()) {
                String hv = vendorOfName(hit.soc);
                boolean hvOk = hv.isEmpty() || socVendor.isEmpty() || hv.equals(socVendor);
                boolean plausible = plausibleByGpu(hit.soc, gpu);
                v.evidence.add(new String[]{"网页搜索",
                        hit.soc + "（" + hit.votes + " 次提及）", (hvOk && plausible) ? "✔" : "⚠"});
                if (!hit.modelName.isEmpty()) {
                    v.evidence.add(new String[]{"机型线索", hit.modelName, "ⓘ"});
                }

                if (dev != null) {
                    // 机型库已经是官方规格，网页结果只作参考，不覆盖
                    note = "按机型库确定（官方规格），网页结果仅作参考";
                } else if (!hvOk) {
                    note = "网页结果厂商与 GPU 不符，已忽略网页结论";
                } else if (!plausible) {
                    note = "网页结果与 GPU 档位不符（GPU 更像 " + gpuHintText(gpu) + "），已忽略";
                } else if (!tableName.isEmpty() && shareFamily(tableName, hit.soc)) {
                    // 同一系列，取更具体的网页名字
                    name = hit.soc;
                    conf = gpuOk ? "高" : "中";
                } else if (tableName.contains("系列") && plausible) {
                    // 内置表只给了系列，网页给了具体型号，且 GPU 支持
                    name = hit.soc;
                    conf = "中";
                    note = "内置表只有系列名，采用网页里的具体型号";
                } else {
                    note = "网页与内置表不一致，保留内置表结论";
                }
            } else {
                v.evidence.add(new String[]{"网页搜索", "无结果 / 网络不通", "—"});
            }
        } else {
            v.evidence.add(new String[]{"网页搜索", "未联网验证", "—"});
        }

        if (name == null || name.isEmpty()) name = nz(v.code);
        v.name = name;
        v.confidence = conf;
        v.note = note;
        save(c, v);
        return v;
    }

    // ---------------------------------------------------------------- 规则

    /** GPU 型号 → 它可能对应的平台档位（用于判断网页结论是否可信）。 */
    private static String[] gpuHints(String gpu) {
        String u = gpu == null ? "" : gpu.toUpperCase(Locale.US);
        if (u.contains("G615")) return new String[]{"7300", "7350", "7360", "7400", "7450"};
        if (u.contains("G610")) return new String[]{"7200", "8100", "8200"};
        if (u.contains("G715")) return new String[]{"9200"};
        if (u.contains("G720")) return new String[]{"9300"};
        if (u.contains("G925")) return new String[]{"9400"};
        if (u.contains("G1-ULTRA") || u.contains("G1 ULTRA")) return new String[]{"9500"};
        if (u.contains("ADRENO")) return new String[]{"骁龙", "SNAPDRAGON"};
        return new String[]{};
    }

    private static boolean plausibleByGpu(String name, String gpu) {
        String[] hints = gpuHints(gpu);
        if (hints.length == 0) return true;          // GPU 认不出就不做限制
        String n = name == null ? "" : name.toUpperCase(Locale.US);
        for (String h : hints) if (n.contains(h.toUpperCase(Locale.US))) return true;
        return false;
    }

    private static String gpuHintText(String gpu) {
        String[] hints = gpuHints(gpu);
        if (hints.length == 0) return "未知平台";
        StringBuilder sb = new StringBuilder();
        for (String h : hints) {
            if (sb.length() > 0) sb.append('/');
            sb.append(h);
        }
        return sb.toString() + " 平台";
    }

    /** 两个名字是不是同一系列（数字前缀相同）。 */
    private static boolean shareFamily(String a, String b) {
        if (a == null || b == null) return false;
        if (a.replace(" ", "").equalsIgnoreCase(b.replace(" ", ""))) return true;
        String na = digits(a), nb = digits(b);
        if (na.length() < 4 || nb.length() < 4) return false;
        return na.substring(0, 2).equals(nb.substring(0, 2)) && na.substring(0, 4).equals(nb.substring(0, 4));
    }

    private static String digits(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) if (c >= '0' && c <= '9') sb.append(c);
        return sb.toString();
    }

    private static String vendorOfGpu(String gpu) {
        String u = gpu == null ? "" : gpu.toUpperCase(Locale.US);
        if (u.contains("MALI") || u.contains("IMMORTALIS")) return "MediaTek";
        if (u.contains("ADRENO")) return "Qualcomm";
        if (u.contains("XCLIPSE")) return "Samsung";
        return "";
    }

    private static String vendorOfName(String name) {
        String u = name == null ? "" : name.toUpperCase(Locale.US);
        if (u.contains("天玑") || u.contains("DIMENSITY")) return "MediaTek";
        if (u.contains("骁龙") || u.contains("SNAPDRAGON")) return "Qualcomm";
        if (u.contains("麒麟") || u.contains("KIRIN")) return "HiSilicon";
        if (u.contains("EXYNOS")) return "Samsung";
        return "";
    }

    private static String nz(String s) { return s == null || s.isEmpty() ? "—" : s; }
}
