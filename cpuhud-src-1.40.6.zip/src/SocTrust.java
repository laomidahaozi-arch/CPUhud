package com.dsh.cpuhud;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SoC 身份「可信度」校验。
 *
 * 系统属性是字符串，改机工具改起来零成本；这里挑几个改起来代价高的信号交叉核对：
 *   1) GPU renderer（EGL / GL_RENDERER）—— 要伪造得动 GPU 驱动，成本最高
 *   2) 最高主频 / 核心数 —— 要伪造得动 cpufreq 与内核
 *   3) 传感器清单 —— 集合型信号，低端机一般凑不出旗舰的配置（弱信号，仅作参考）
 *
 * 只做提示，不做判定：从不输出「假机」结论。
 */
public final class SocTrust {

    public static class Result {
        public int level = 2;              // 2 高 / 1 中 / 0 低
        public String gpu = "";
        public String gpuVendor = "";
        public int maxFreqMhz = 0;
        public int cores = 0;
        public int sensorCount = 0;
        public boolean hasGyro = false;
        public String degrade = "";        // 非空 = 降级识别（没有 shell）
        public final List<String> notes = new ArrayList<>();

        public String levelText() {
            return level == 2 ? "高" : level == 1 ? "中" : "低";
        }
    }

    private SocTrust() { }

    public static Result check(Context ctx) {
        Result r = new Result();
        SocProbe.Info si = SocProbe.get(ctx, false);

        // 1) GPU
        try {
            String gl = HwInfo.gpuRenderer();
            if (gl != null && !gl.isEmpty() && !"—".equals(gl)) {
                r.gpu = gl;
                String u = gl.toLowerCase(Locale.US);
                if (u.contains("adreno")) r.gpuVendor = "Qualcomm";
                else if (u.contains("mali") || u.contains("immortalis")) r.gpuVendor = "MediaTek";
                else if (u.contains("powervr")) r.gpuVendor = "Imagination";
                else if (u.contains("xclipse")) r.gpuVendor = "Samsung";
                else if (u.contains("maleoon")) r.gpuVendor = "HiSilicon";
            }
        } catch (Throwable ignored) { }

        if (!r.gpuVendor.isEmpty() && !si.vendor.isEmpty()) {
            boolean ok = (r.gpuVendor.equals("Qualcomm") && si.vendor.equals("Qualcomm"))
                    || (r.gpuVendor.equals("MediaTek") && si.vendor.equals("MediaTek"))
                    || (r.gpuVendor.equals("Samsung") && si.vendor.equals("Samsung"))
                    || (r.gpuVendor.equals("HiSilicon") && si.vendor.equals("HiSilicon"));
            if (ok) r.notes.add("GPU " + shortGpu(r.gpu) + " 与芯片厂商 " + si.vendor + " 一致");
            else {
                r.level = 0;
                r.notes.add("GPU " + shortGpu(r.gpu) + "（" + r.gpuVendor + "）与属性声称的 "
                        + si.vendor + " 对不上");
            }
        } else if (!r.gpu.isEmpty()) {
            r.notes.add("GPU " + shortGpu(r.gpu) + "（未纳入校验）");
        }

        // 2) 主频 / 核心数
        r.maxFreqMhz = maxFreq();
        r.cores = Runtime.getRuntime().availableProcessors();
        if (r.maxFreqMhz > 0) {
            String m = si.market == null ? "" : si.market;
            boolean highEnd = m.contains("8 Gen") || m.contains("至尊") || m.contains("Elite")
                    || m.contains("天玑 9") || m.contains("Tensor G") || m.contains("Exynos 2");
            boolean lowEnd = m.contains("6 Gen") || m.contains("4 Gen") || m.contains("天玑 6")
                    || m.contains("天玑 7") || m.contains("骁龙 4") || m.contains("骁龙 6");
            if (highEnd && r.maxFreqMhz < 2400) {
                r.level = Math.min(r.level, 0);
                r.notes.add("属性称「" + m + "」但最高主频只有 " + r.maxFreqMhz + " MHz，偏低");
            } else if (lowEnd && r.maxFreqMhz >= 3200) {
                r.level = Math.min(r.level, 1);
                r.notes.add("属性称「" + m + "」但最高主频达 " + r.maxFreqMhz + " MHz，偏高");
            } else {
                r.notes.add("最高主频 " + r.maxFreqMhz + " MHz · " + r.cores + " 核，与档位相符");
            }
        } else {
            r.notes.add("核心数 " + r.cores + "（主频不可读）");
        }

        // 3) 传感器（弱信号，只降一级，且措辞留余地）
        try {
            SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            if (sm != null) {
                List<Sensor> list = sm.getSensorList(Sensor.TYPE_ALL);
                r.sensorCount = list == null ? 0 : list.size();
                if (list != null) {
                    for (Sensor s : list) {
                        if (s.getType() == Sensor.TYPE_GYROSCOPE) { r.hasGyro = true; break; }
                    }
                }
            }
        } catch (Throwable ignored) { }

        // 传感器只做展示与弱提示：旗舰档却连陀螺仪都没有，才降一级
        if (r.sensorCount > 0) {
            String tag = r.hasGyro ? "（含陀螺仪）" : "（无陀螺仪）";
            String m0 = si.market == null ? "" : si.market;
            boolean hi = m0.contains("8 Gen") || m0.contains("至尊") || m0.contains("Elite")
                    || m0.contains("天玑 9") || m0.contains("Tensor G");
            if (!r.hasGyro && hi) {
                r.level = Math.min(r.level, 1);
                r.notes.add("传感器 " + r.sensorCount + " 项" + tag + "，与旗舰档位略有出入（仅供参考）");
            } else {
                r.notes.add("传感器 " + r.sensorCount + " 项" + tag);
            }
        }

        // 4) 是否降级识别
        String src = si.source == null ? "" : si.source;
        if (src.startsWith("Build")) {
            r.degrade = "无 shell 权限，仅用 Build 字段识别（未读系统属性）";
        }

        return r;
    }

    /** 去掉 GL_RENDERER 里冗长的括号说明，只留主体。 */
    public static String shortGpu(String gl) {
        if (gl == null) return "—";
        int i = gl.indexOf('(');
        String s = i > 0 ? gl.substring(0, i) : gl;
        return s.trim();
    }

    /** 各核 cpuinfo_max_freq 的最大值（MHz）；读不到返回 0。 */
    private static int maxFreq() {
        int best = 0;
        File base = new File("/sys/devices/system/cpu");
        File[] cpus = base.listFiles();
        if (cpus == null) return 0;
        for (File c : cpus) {
            String n = c.getName();
            if (!n.startsWith("cpu") || n.length() <= 3) continue;
            try {
                BufferedReader br = new BufferedReader(
                        new FileReader(new File(c, "cpufreq/cpuinfo_max_freq")));
                String line = br.readLine();
                br.close();
                if (line == null) continue;
                int khz = Integer.parseInt(line.trim());
                int mhz = khz / 1000;
                if (mhz > best) best = mhz;
            } catch (Throwable ignored) { }
        }
        return best;
    }

    /** 识别结果导出成 JSON（验机、求助、发群里都能直接用）。 */
    public static String toJson(Context ctx) {
        SocProbe.Info si = SocProbe.get(ctx, false);
        Result r = check(ctx);
        StringBuilder b = new StringBuilder();
        b.append("{\n");
        b.append("  \"soc_code\": \"").append(esc(si.raw)).append("\",\n");
        b.append("  \"soc_market\": \"").append(esc(si.market)).append("\",\n");
        b.append("  \"soc_vendor\": \"").append(esc(si.vendor)).append("\",\n");
        b.append("  \"prop_source\": \"").append(esc(si.source)).append("\",\n");
        b.append("  \"trust\": \"").append(r.levelText()).append("\",\n");
        b.append("  \"gpu\": \"").append(esc(shortGpu(r.gpu))).append("\",\n");
        b.append("  \"max_freq_mhz\": ").append(r.maxFreqMhz).append(",\n");
        b.append("  \"cores\": ").append(r.cores).append(",\n");
        b.append("  \"sensors\": ").append(r.sensorCount).append(",\n");
        b.append("  \"gyroscope\": ").append(r.hasGyro).append(",\n");
        b.append("  \"build\": {\n");
        b.append("    \"manufacturer\": \"").append(esc(Build.MANUFACTURER)).append("\",\n");
        b.append("    \"model\": \"").append(esc(Build.MODEL)).append("\",\n");
        b.append("    \"device\": \"").append(esc(Build.DEVICE)).append("\",\n");
        b.append("    \"board\": \"").append(esc(Build.BOARD)).append("\",\n");
        b.append("    \"hardware\": \"").append(esc(Build.HARDWARE)).append("\",\n");
        b.append("    \"android\": \"").append(esc(Build.VERSION.RELEASE)).append("\",\n");
        b.append("    \"sdk\": ").append(Build.VERSION.SDK_INT).append(",\n");
        b.append("    \"fingerprint\": \"").append(esc(Build.FINGERPRINT)).append("\"\n");
        b.append("  },\n");
        b.append("  \"notes\": [");
        for (int i = 0; i < r.notes.size(); i++) {
            if (i > 0) b.append(", ");
            b.append("\"").append(esc(r.notes.get(i))).append("\"");
        }
        b.append("]\n}\n");
        return b.toString();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
