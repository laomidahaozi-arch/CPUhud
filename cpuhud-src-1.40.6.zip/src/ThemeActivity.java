package com.dsh.cpuhud;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/** 配色设置：预设主题 + 12 项逐项调色（RGB 滑杆 + #RRGGBB）。只改 App 自己的页面，不动悬浮窗。 */
public class ThemeActivity extends Activity {

    private int sig;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        sig = Theme.sig();
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != sig) { sig = Theme.sig(); recreate(); }
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(28));

        TextView t = text("配色", 24f, Theme.strong(), false, true);
        t.setPadding(0, 0, 0, dp(2));
        root.addView(t);
        root.addView(text("主界面的颜色逐项可改，改完立刻生效。悬浮窗的外观不受这里影响。",
                11.5f, Theme.dim2(), false, false));

        // ---------------- 直接跟手机取色 ----------------
        root.addView(header("从手机取色"));
        final int follow = Theme.follow(this);
        String state;
        if (follow == Theme.FOLLOW_MATERIAL) {
            state = "当前：跟随手机主题色（Material You）· 主色 " + Theme.hex(Theme.accent());
        } else if (follow == Theme.FOLLOW_WALLPAPER) {
            state = "当前：跟随壁纸取色 · 主色 " + Theme.hex(Theme.accent());
        } else {
            state = "当前：手动配色";
        }
        root.addView(text(state, 11.5f, Theme.dim(), false, false));

        LinearLayout frow = new LinearLayout(this);
        frow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams frp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        frp.topMargin = dp(4);
        root.addView(frow, frp);

        Button matBtn = chip((follow == Theme.FOLLOW_MATERIAL ? "手机主题色 ✓" : "手机主题色"));
        matBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SysTheme.invalidate();
                if (!Theme.setFollow(ThemeActivity.this, Theme.FOLLOW_MATERIAL)) {
                    android.widget.Toast.makeText(ThemeActivity.this,
                            "这个系统没提供 Material You 配色（或只给基线紫），试试「壁纸取色」",
                            android.widget.Toast.LENGTH_LONG).show();
                    return;
                }
                sig = -1;
                recreate();
            }
        });
        Button wallBtn = chip((follow == Theme.FOLLOW_WALLPAPER ? "壁纸取色 ✓" : "壁纸取色"));
        wallBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SysTheme.invalidate();
                if (!Theme.setFollow(ThemeActivity.this, Theme.FOLLOW_WALLPAPER)) {
                    android.widget.Toast.makeText(ThemeActivity.this,
                            "读不到壁纸（系统限制），只能用「手机主题色」或手动配色",
                            android.widget.Toast.LENGTH_LONG).show();
                    return;
                }
                sig = -1;
                recreate();
            }
        });
        Button offBtn = chip(follow == Theme.FOLLOW_OFF ? "手动配色 ✓" : "关闭跟随");
        offBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Theme.follow(ThemeActivity.this) == Theme.FOLLOW_OFF) return;
                Theme.setFollow(ThemeActivity.this, Theme.FOLLOW_OFF);
                sig = -1;
                recreate();
            }
        });
        frow.addView(matBtn);
        frow.addView(wallBtn);
        frow.addView(offBtn);

        root.addView(text("· 手机主题色：读系统 Material You 调色板（Android 12+），多数国产 ROM 只给基线紫，取不到会提示\n"
                + "· 壁纸取色：直接从当前壁纸抽主色 —— 国产 ROM 的「主题色」基本都是壁纸取色来的\n"
                + "· 跟随开着时，每次打开 App 自动重取；手动改色或点预设会自动退出跟随",
                10.5f, Theme.dim2(), false, false));

        root.addView(header("预设主题"));
        LinearLayout row = null;
        for (int i = 0; i < Theme.PRESETS.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                rp.topMargin = dp(4);
                root.addView(row, rp);
            }
            final int idx = i;
            final String label = Theme.PRESETS[i] + (sameAsPreset(i) ? "✓" : "");
            Button pb = new Button(this);
            pb.setText(label);
            pb.setAllCaps(false);
            pb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            pb.setTextColor(Theme.PRESET_COLORS[i][Theme.TEXT]);
            GradientDrawable pbg = new GradientDrawable();
            pbg.setColor(Theme.PRESET_COLORS[i][Theme.CARD]);
            pbg.setCornerRadius(dp(12));
            pbg.setStroke(dp(1), Theme.PRESET_COLORS[i][Theme.ACCENT]);
            pb.setBackground(pbg);
            pb.setPadding(0, 0, 0, 0);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            plp.setMargins(dp(3), 0, dp(3), 0);
            pb.setLayoutParams(plp);
            pb.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Theme.applyPreset(ThemeActivity.this, idx);
                    sig = -1;
                    recreate();
                }
            });
            if (row != null) row.addView(pb);
        }

        root.addView(header("逐项自定义"));
        root.addView(text("点一行进调色：三色滑杆，或直接输入 #RRGGBB", 11f, Theme.dim2(), false, false));
        for (int r = 0; r < Theme.NAMES.length; r++) {
            root.addView(roleRow(r));
        }

        Button reset = new Button(this);
        reset.setText(Theme.isDefault() ? "已是出厂配色" : "全部恢复出厂配色");
        reset.setAllCaps(false);
        reset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        reset.setTextColor(Theme.text());
        GradientDrawable rbg = new GradientDrawable();
        rbg.setColor(Theme.card());
        rbg.setCornerRadius(dp(12));
        reset.setBackground(rbg);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Theme.resetAll(ThemeActivity.this);
                sig = -1;
                recreate();
            }
        });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        rlp.topMargin = dp(18);
        root.addView(reset, rlp);

        Button back = new Button(this);
        back.setText("返回");
        back.setAllCaps(false);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        back.setTextColor(Theme.text());
        GradientDrawable bbg = new GradientDrawable();
        bbg.setColor(Theme.card());
        bbg.setCornerRadius(dp(12));
        back.setBackground(bbg);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        blp.topMargin = dp(8);
        root.addView(back, blp);

        sc.addView(root);
        setContentView(sc);
    }

    private Button chip(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        b.setTextColor(Theme.text());
        b.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }

    private boolean sameAsPreset(int idx) {
        int[] p = Theme.PRESET_COLORS[idx];
        for (int i = 0; i < p.length; i++) if (Theme.color(i) != p[i]) return false;
        return true;
    }

    private View roleRow(final int role) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(9), dp(12), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card2());
        bg.setCornerRadius(dp(12));
        row.setBackground(bg);

        View sw = new View(this);
        GradientDrawable swg = new GradientDrawable();
        swg.setShape(GradientDrawable.OVAL);
        swg.setColor(Theme.color(role));
        swg.setStroke(dp(1), Theme.dim2());
        sw.setBackground(swg);
        row.addView(sw, new LinearLayout.LayoutParams(dp(26), dp(26)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = dp(12);
        row.addView(col, clp);
        col.addView(text(Theme.NAMES[role], 13.5f, Theme.text(), false, false));
        col.addView(text(Theme.DESC[role], 10.5f, Theme.dim2(), false, false));

        TextView code = text(Theme.hex(Theme.color(role)), 12f, Theme.dim(), true, false);
        code.setGravity(Gravity.END);
        row.addView(code);

        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pick(role); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(5);
        row.setLayoutParams(lp);
        return row;
    }

    private static int contrast(int c) {
        double l = 0.299 * ((c >> 16) & 0xFF) + 0.587 * ((c >> 8) & 0xFF) + 0.114 * (c & 0xFF);
        return l > 140 ? 0xFF000000 : 0xFFFFFFFF;
    }

    /** 调色对话框：预览 + RGB 三滑杆 + 十六进制输入。 */
    private void pick(final int role) {
        final int[] col = {Theme.color(role)};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(10), dp(18), dp(2));

        final TextView prev = new TextView(this);
        prev.setGravity(Gravity.CENTER);
        prev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        prev.setTypeface(Typeface.MONOSPACE);
        box.addView(prev, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(62)));

        final String[] nm = {"R", "G", "B"};
        final SeekBar[] bars = new SeekBar[3];
        final TextView[] labs = new TextView[3];
        for (int i = 0; i < 3; i++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(2);
            box.addView(r, rlp);
            labs[i] = text(nm[i], 12f, Theme.dim(), true, false);
            labs[i].setWidth(dp(62));
            r.addView(labs[i]);
            SeekBar sb = new SeekBar(this);
            sb.setMax(255);
            bars[i] = sb;
            r.addView(sb, new LinearLayout.LayoutParams(0, dp(40), 1f));
        }

        final EditText hexBox = new EditText(this);
        hexBox.setSingleLine(true);
        hexBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        hexBox.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
        hexBox.setTextColor(Theme.text());
        hexBox.setHintTextColor(Theme.dim2());
        hexBox.setHint("#RRGGBB");
        hexBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        hexBox.setTypeface(Typeface.MONOSPACE);
        box.addView(hexBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));

        final boolean[] sync = {false};
        final Runnable push = new Runnable() {
            @Override public void run() {
                int c = col[0];
                sync[0] = true;
                for (int i = 0; i < 3; i++) {
                    int v = (c >> ((2 - i) * 8)) & 0xFF;
                    bars[i].setProgress(v);
                    labs[i].setText(nm[i] + " " + v);
                }
                hexBox.setText(Theme.hex(c));
                hexBox.setSelection(hexBox.getText().length());
                sync[0] = false;
                GradientDrawable pg = new GradientDrawable();
                pg.setColor(c);
                pg.setCornerRadius(dp(12));
                pg.setStroke(dp(1), Theme.dim2());
                prev.setBackground(pg);
                prev.setTextColor(contrast(c));
                prev.setText(Theme.hex(c) + "   " + String.format(Locale.US, "R%d G%d B%d",
                        (c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF));
            }
        };

        for (int i = 0; i < 3; i++) {
            final int ch = i;
            bars[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int v, boolean fromUser) {
                    if (sync[0]) return;
                    int sh = (2 - ch) * 8;
                    col[0] = (col[0] & ~(0xFF << sh)) | (v << sh) | 0xFF000000;
                    push.run();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { }
                @Override public void onStopTrackingTouch(SeekBar sb) { }
            });
        }

        hexBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                if (sync[0]) return;
                String s = e.toString().trim();
                if (s.startsWith("#")) s = s.substring(1);
                if (!s.matches("[0-9A-Fa-f]{6}")) return;
                col[0] = 0xFF000000 | Integer.parseInt(s, 16);
                push.run();
            }
        });

        push.run();

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("调色 · " + Theme.NAMES[role])
                .setView(box)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Theme.set(ThemeActivity.this, role, col[0]);
                        sig = -1;
                        recreate();
                    }
                })
                .setNeutralButton("恢复默认", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Theme.resetOne(ThemeActivity.this, role);
                        sig = -1;
                        recreate();
                    }
                })
                .setNegativeButton("取消", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                GradientDrawable dbg = new GradientDrawable();
                dbg.setColor(Theme.card2());
                dbg.setCornerRadius(dp(20));
                if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(dbg);
                int titleId = getResources().getIdentifier("alertTitle", "id", "android");
                View tv = dlg.findViewById(titleId);
                if (tv instanceof TextView) ((TextView) tv).setTextColor(Theme.strong());
            }
        });
        dlg.show();
    }

    private TextView header(String s) {
        TextView v = text(s, 15f, Theme.good(), false, true);
        v.setPadding(0, dp(18), 0, dp(4));
        return v;
    }

    private TextView text(String s, float sp, int color, boolean mono, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (mono) v.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL);
        v.setPadding(0, dp(3), 0, dp(3));
        return v;
    }
}
