package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 联网识别芯片：先用型号码搜「这是什么机型」，再用机型名搜「处理器 / CPU 型号」，
 * 从结果页里把 天玑/骁龙/Exynos/麒麟 这些型号名挑出来按出现次数投票。
 *
 * 全程只读 GET，不上传任何设备信息；结果标「网络识别（未校验）」，需要用户手动采用。
 */
public final class SocOnline {

    public static final class Hit {
        public String soc = "";       // 候选芯片名
        public int votes = 0;         // 出现次数
        public String query = "";     // 命中它的搜索词
        public String modelName = ""; // 顺带识别出的机型名（如 Redmi Note 15 Pro）
        public String note = "";      // 失败原因 / 说明
    }

    private static final String PREF = "soc_online";

    /** 芯片名匹配：中文/英文两套，前后加边界，避免把「骁龙 8」这种半截词也算进去。 */
    private static final Pattern[] PATTERNS = {
            Pattern.compile("天玑\\s?\\d{3,4}[A-Za-z0-9\\-+]{0,6}(?:\\s?(?:Ultra|Max|Turbo|Pro|SUPER|Apex))?"),
            Pattern.compile("骁龙\\s?\\d{1,2}\\s?(?:Gen\\s?\\d|s\\s?Gen\\s?\\d)?[A-Za-z0-9\\-+]{0,8}"),
            Pattern.compile("Dimensity\\s?\\d{3,4}[A-Za-z0-9\\-+]{0,6}", Pattern.CASE_INSENSITIVE),
            Pattern.compile("Snapdragon\\s?\\d{1,2}\\s?(?:Gen\\s?\\d)?[A-Za-z0-9\\-+]{0,8}", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(?:麒麟|Kirin)\\s?\\d{3,4}[A-Za-z0-9\\-+]{0,4}", Pattern.CASE_INSENSITIVE),
            Pattern.compile("Exynos\\s?\\d{4}[A-Za-z0-9\\-+]{0,4}", Pattern.CASE_INSENSITIVE),
    };

    private SocOnline() { }

    // ---------------------------------------------------------------- 入口

    /** 阻塞调用（放后台线程）。names 依次尝试：机型名、型号码、代号。 */
    public static Hit lookup(Context ctx, String... names) {
        Hit hit = new Hit();
        List<String> queries = new ArrayList<>();
        for (String n : names) {
            if (n == null || n.trim().isEmpty()) continue;
            n = n.trim();
            queries.add(n + " 处理器");
            queries.add(n + " CPU型号");
        }
        Map<String, Integer> votes = new LinkedHashMap<>();
        Map<String, String> firstQuery = new LinkedHashMap<>();
        String[] urls = {"https://cn.bing.com/search?q=", "https://www.bing.com/search?q="};
        int done = 0;
        for (String q : queries) {
            if (done >= 3) break;                 // 最多 3 次查询，别太慢
            String html = null;
            for (String base : urls) {
                html = get(base + android.net.Uri.encode(q), 8000);
                if (html != null && html.length() > 500) break;
            }
            if (html == null) continue;
            done++;
            String text = stripTags(html);
            for (Pattern p : PATTERNS) {
                Matcher m = p.matcher(text);
                while (m.find()) {
                    String cand = norm(m.group());
                    if (cand.isEmpty() || cand.length() > 24) continue;
                    Integer c = votes.get(cand);
                    votes.put(cand, c == null ? 1 : c + 1);
                    if (!firstQuery.containsKey(cand)) firstQuery.put(cand, q);
                }
            }
            // 顺手从结果标题里认一下机型名（形如 Redmi Note 15 Pro / 一加 Ace 6）
            if (hit.modelName.isEmpty()) hit.modelName = guessModelName(text);
        }
        String best = null;
        int bestVotes = 0;
        for (Map.Entry<String, Integer> e : votes.entrySet()) {
            if (e.getValue() > bestVotes) { bestVotes = e.getValue(); best = e.getKey(); }
        }
        if (best == null) {
            hit.note = "搜索没找到可用的芯片信息（可能是新机型，或网络不通）";
            return hit;
        }
        hit.soc = best;
        hit.votes = bestVotes;
        hit.query = firstQuery.get(best);
        return hit;
    }

    // ---------------------------------------------------------------- 采用 / 读取

    public static String override(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("adopt", "");
    }

    public static void adopt(Context c, String soc) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("adopt", soc == null ? "" : soc.trim()).apply();
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("adopt").apply();
    }

    // ---------------------------------------------------------------- 工具

    /** 统一成「天玑 9500」这种带一个空格的样子，并去掉尾部杂字。 */
    private static String norm(String s) {
        String t = s.replaceAll("\\s+", " ").trim();
        t = t.replaceAll("^(天玑|骁龙|麒麟|Dimensity|Snapdragon|Kirin)\\s?", "$1 ");
        t = t.replaceAll("[\\s,，。;；:：]+$", "");
        return t;
    }

    /** 粗略提取机型名：找「中文品牌 + 型号」或「英文品牌 + Note/数字」。 */
    private static String guessModelName(String text) {
        String[] pats = {
                "(红米|小米|一加|OPPO|vivo|iQOO|真我|realme|荣耀|华为|Redmi|Xiaomi|OnePlus)\\s?[A-Za-z0-9\\s\\-]{1,18}",
        };
        for (String p : pats) {
            Matcher m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(text);
            if (m.find()) {
                String s = norm(m.group());
                if (s.length() >= 4 && s.length() <= 24) return s;
            }
        }
        return "";
    }

    private static String stripTags(String html) {
        String t = html.replaceAll("(?is)<script.*?</script>", " ")
                .replaceAll("(?is)<style.*?</style>", " ")
                .replaceAll("<[^>]+>", " ");
        return t.replace("&nbsp;", " ").replace("&amp;", "&");
    }

    private static String get(String u, int timeout) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(u).openConnection();
            conn.setConnectTimeout(timeout / 2);
            conn.setReadTimeout(timeout);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            if (conn.getResponseCode() != 200) return null;
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
