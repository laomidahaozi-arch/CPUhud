package com.dsh.cpuhud;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** 二级界面：控制悬浮窗显示哪些项、主题、圆角。 */
public class HudConfigActivity extends Activity {
    public static final int SHOW_TEMP = 1, SHOW_FREQ = 2, SHOW_POWER = 4, SHOW_FPS = 8,
            SHOW_LOAD = 16, SHOW_MEM = 32, SHOW_BATT = 64, SHOW_THERM = 128, SHOW_HZ = 256;
    public static final int SHOW_ALL = SHOW_TEMP | SHOW_FREQ | SHOW_POWER | SHOW_FPS
            | SHOW_LOAD | SHOW_MEM | SHOW_BATT | SHOW_THERM | SHOW_HZ;

    private SharedPreferences prefs;
    private LinearLayout root;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int themeSig;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        prefs = getSharedPreferences("hud", MODE_PRIVATE);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(28));

        title("显示项", "悬浮窗只画勾上的东西；「简」档只保留温度 + 曲线");

        final int mask = prefs.getInt("showMask", SHOW_ALL);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        addCheck(grid, "温度 CPU/GPU/SOC", SHOW_TEMP, mask);
        addCheck(grid, "各簇频率", SHOW_FREQ, mask);
        addCheck(grid, "功耗 W", SHOW_POWER, mask);
        addCheck(grid, "帧率 + 曲线", SHOW_FPS, mask);
        addCheck(grid, "CPU 负载", SHOW_LOAD, mask);
        addCheck(grid, "内存", SHOW_MEM, mask);
        addCheck(grid, "电量 / 电流", SHOW_BATT, mask);
        addCheck(grid, "屏温 / 电池温度 / 热状态", SHOW_THERM, mask);
        addCheck(grid, "屏幕刷新率", SHOW_HZ, mask);
        root.addView(grid);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button all = btn("全选");
        all.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("showMask", SHOW_ALL).apply(); recreate(); }
        });
        Button none = btn("只看温度");
        none.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("showMask", SHOW_TEMP).apply(); recreate(); }
        });
        Button onlyFps = btn("只看帧率");
        onlyFps.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("showMask", SHOW_FPS).apply(); recreate(); }
        });
        row.addView(all); row.addView(none); row.addView(onlyFps);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(8);
        root.addView(row, rp);

        title("外观", null);
        final int[] themes = {0, 1, 2};
        String[] names = {"跟随系统", "深色", "浅色"};
        int cur = prefs.getInt("theme", 0);
        LinearLayout trow = new LinearLayout(this);
        trow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int val = themes[i];
            Button tb = btn(names[i] + (cur == val ? " ✓" : ""));
            tb.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { prefs.edit().putInt("theme", val).apply(); recreate(); }
            });
            trow.addView(tb);
        }
        root.addView(trow);

        TextView al = small("强调色");
        root.addView(al);
        String[] acName = {"跟随系统", "青", "紫", "橙", "绿", "粉", "自定义"};
        int acCur = prefs.getInt("accent", 0);
        LinearLayout arow = new LinearLayout(this);
        arow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < acName.length; i++) {
            final int val = i;
            Button ab = new Button(this);
            ab.setText(acName[i] + (acCur == i ? " ✓" : ""));
            ab.setAllCaps(false);
            ab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            ab.setTextColor(Theme.text());
            GradientDrawable abg = new GradientDrawable();
            abg.setColor(Theme.card());
            abg.setCornerRadius(dp(12));
            ab.setBackground(abg);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(38));
            ap.setMargins(dp(4), 0, dp(4), 0);
            ab.setPadding(dp(14), 0, dp(14), 0);
            ab.setLayoutParams(ap);
            ab.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putInt("accent", val).apply();
                    recreate();
                }
            });
            arow.addView(ab);
        }
        android.widget.HorizontalScrollView ahs = new android.widget.HorizontalScrollView(this);
        ahs.setHorizontalScrollBarEnabled(false);
        ahs.addView(arow);
        root.addView(ahs);

        final int rgb0 = prefs.getInt("accentRGB", Theme.accent());
        String[] rgbName = {"红", "绿", "蓝"};
        int[] rgbVal = {(rgb0 >> 16) & 0xFF, (rgb0 >> 8) & 0xFF, rgb0 & 0xFF};
        for (int c = 0; c < 3; c++) {
            final int ch = c;
            final TextView lab = small(rgbName[c] + " " + rgbVal[c]);
            root.addView(lab);
            SeekBar sb = new SeekBar(this);
            sb.setMax(255);
            sb.setProgress(rgbVal[c]);
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int v, boolean fromUser) {
                    int cur = prefs.getInt("accentRGB", Theme.accent());
                    int r = (ch == 0) ? v : ((cur >> 16) & 0xFF);
                    int g = (ch == 1) ? v : ((cur >> 8) & 0xFF);
                    int b = (ch == 2) ? v : (cur & 0xFF);
                    int col = 0xFF000000 | (r << 16) | (g << 8) | b;
                    prefs.edit().putInt("accentRGB", col).putInt("accent", 6).apply();
                    lab.setText(rgbName[ch] + " " + v);
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });
            root.addView(sb);
        }

        TextView fl = small("字号");
        root.addView(fl);
        String[] fName = {"小", "中", "大"};
        int fCur = prefs.getInt("font", 1);
        LinearLayout frow = new LinearLayout(this);
        frow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < fName.length; i++) {
            final int val = i;
            Button fb = btn(fName[i] + (fCur == i ? " ✓" : ""));
            fb.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { prefs.edit().putInt("font", val).apply(); recreate(); }
            });
            frow.addView(fb);
        }
        root.addView(frow);

        LinearLayout brow = new LinearLayout(this);
        brow.setOrientation(LinearLayout.HORIZONTAL);
        final boolean bCur = prefs.getBoolean("border", true);
        Button bb = btn(bCur ? "边框：显示" : "边框：隐藏");
        bb.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putBoolean("border", !bCur).apply();
                recreate();
            }
        });
        brow.addView(bb);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42));
        brp.topMargin = dp(6);
        root.addView(brow, brp);

        int radius = prefs.getInt("radius", 18);
        TextView rl = small("圆角 " + radius + "dp");
        root.addView(rl);
        SeekBar rs = new SeekBar(this);
        rs.setMax(28);
        rs.setProgress(Math.max(0, Math.min(28, radius - 4)));
        final TextView rlRef = rl;
        rs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                int v = 4 + p;
                rlRef.setText("圆角 " + v + "dp");
                prefs.edit().putInt("radius", v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        root.addView(rs);

        Button back = btn("返回");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        bp.topMargin = dp(18);
        root.addView(back, bp);

        // 电流校准入口（双电芯 / 串联电池）
        Button cellBtn = btn("电流校准（双电芯 / 串联电池）");
        cellBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCellDialog(); }
        });
        LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        cellLp.topMargin = dp(14);
        root.addView(cellBtn, cellLp);

        TextView cellHint = new TextView(this);
        cellHint.setText("双电芯机型若功耗差一倍，勾选并联调除数即可校正");
        cellHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        cellHint.setTextColor(Theme.dim2());
        cellHint.setPadding(dp(2), dp(6), 0, 0);
        root.addView(cellHint);

        sc.addView(root);
        setContentView(sc);
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); }
    }

    private void addCheck(LinearLayout parent, final String label, final int bit, int mask) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        cb.setTextColor(Theme.strong());
        cb.setChecked((mask & bit) != 0);
        cb.setPadding(0, dp(4), 0, dp(4));
        cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                int m = prefs.getInt("showMask", SHOW_ALL);
                if (on) m |= bit; else m &= ~bit;
                prefs.edit().putInt("showMask", m).apply();
            }
        });
        parent.addView(cb);
    }

    private void title(String t, String sub) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        v.setTextColor(Theme.good());
        v.setPadding(0, dp(16), 0, dp(6));
        root.addView(v);
        if (sub != null) root.addView(small(sub));
    }

    private TextView small(String s) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        v.setTextColor(Theme.dim2());
        v.setPadding(0, dp(2), 0, dp(6));
        return v;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTextColor(Theme.text());
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }

    /** 双电芯 / 串联电池校准对话框。 */
    private void showCellDialog() {
        final android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("串联双电池");
        cb.setTextColor(Theme.strong());
        cb.setChecked(CellCalib.enabled(this));

        final int[] div = {CellCalib.divisor(this)};
        final android.widget.TextView preview = new android.widget.TextView(this);
        preview.setTextColor(Theme.accent());
        preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        preview.setPadding(dp(8), dp(10), dp(8), 0);

        Button minus = new Button(this);
        minus.setText("\u2212");
        minus.setAllCaps(false);
        Button plus = new Button(this);
        plus.setText("+");
        plus.setAllCaps(false);
        final android.widget.TextView num = new android.widget.TextView(this);
        num.setTextColor(Theme.strong());
        num.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.addView(minus, new LinearLayout.LayoutParams(dp(56), dp(44)));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        num.setGravity(android.view.Gravity.CENTER);
        row.addView(num, nlp);
        row.addView(plus, new LinearLayout.LayoutParams(dp(56), dp(44)));

        final Runnable refresh = new Runnable() {
            @Override public void run() {
                num.setText("-" + div[0]);
                Snapshot now = HudService.lastSnapshot;
                if (now != null) {
                    double ma = now.currentMa, w = now.powerW;
                    if (cb.isChecked()) { ma = ma / div[0]; w = w / div[0]; }
                    preview.setText(String.format(java.util.Locale.US,
                            "当前 %.0f mA / %.2f W → 校准后 %.0f mA / %.2f W",
                            now.currentMa, now.powerW, ma, w));
                } else {
                    preview.setText("（等一帧数据后显示预览）");
                }
            }
        };
        minus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (div[0] > 1) { div[0]--; refresh.run(); } }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (div[0] < 4) { div[0]++; refresh.run(); } }
        });
        cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) { refresh.run(); }
        });
        refresh.run();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        box.addView(cb);
        TextView hint = new TextView(this);
        hint.setText("当前充电速度，除以：");
        hint.setTextColor(Theme.dim());
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        hint.setPadding(dp(8), dp(12), dp(8), 0);
        box.addView(hint);
        box.addView(row);
        box.addView(preview);

        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle("电流校准")
                .setView(box)
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        CellCalib.set(HudConfigActivity.this, cb.isChecked(), div[0]);
                        android.widget.Toast.makeText(HudConfigActivity.this,
                                "已保存，悬浮窗下一帧生效", android.widget.Toast.LENGTH_SHORT).show();
                        recreate();
                    }
                })
                .setNegativeButton("取消", null)
                .create();
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override public void onShow(android.content.DialogInterface d) {
                // 深色圆角背景，避免系统浅色主题把白字吞掉
                GradientDrawable dbg2 = new GradientDrawable();
                dbg2.setColor(Theme.card2());
                dbg2.setCornerRadius(dp(20));
                if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(dbg2);
                int titleId = getResources().getIdentifier("alertTitle", "id", "android");
                android.view.View tv = dlg.findViewById(titleId);
                if (tv instanceof TextView) ((TextView) tv).setTextColor(Theme.strong());
            }
        });
        dlg.show();
    }
}
