package com.dsh.cpuhud;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** 联网检查更新 + 下载 APK。只发 GET，不上传任何信息。 */
public final class UpdateChecker {

    /** 默认版本清单地址（可在页面上改）。 */
    public static final String DEFAULT_JSON =
            "https://cdn.jsdelivr.net/gh/laomidahaOzi-arch/CPUhud@main/version.json";

    public static final class Info {
        public int versionCode = 0;
        public String versionName = "";
        public String url = "";
        public String notes = "";
    }

    public interface Progress {
        void onProgress(int pct, long done, long total);
    }

    private UpdateChecker() { }

    public static synchronized Info check(Context c, String jsonUrl, boolean bust) throws Exception {
        String u = jsonUrl;
        if (bust) u += (u.contains("?") ? "&" : "?") + "t=" + (System.currentTimeMillis() / 60000);
        String body = get(u, 12000);
        if (body == null) throw new Exception("拉不到版本清单（网络不通或被墙）");
        JSONObject o = new JSONObject(body);
        Info i = new Info();
        i.versionCode = o.optInt("versionCode", 0);
        i.versionName = o.optString("versionName", "");
        i.url = o.optString("url", "");
        i.notes = o.optString("notes", "");
        if (i.versionCode <= 0 || i.url.isEmpty()) throw new Exception("清单格式不对（缺 versionCode / url）");
        return i;
    }

    /** 下载到私有目录，返回文件。 */
    public static File download(Context c, Info info, Progress p) throws Exception {
        File dst = new File(c.getFilesDir(), "update.apk");
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(info.url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", "CPUHUD-Updater");
            int code = conn.getResponseCode();
            if (code != 200) throw new Exception("下载失败 HTTP " + code);
            long total = conn.getContentLengthLong();
            InputStream in = conn.getInputStream();
            FileOutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[16384];
            long done = 0;
            int n;
            int lastPct = -1;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (total > 0 && p != null) {
                    int pct = (int) (done * 100 / total);
                    if (pct != lastPct) { lastPct = pct; p.onProgress(pct, done, total); }
                }
            }
            in.close();
            out.close();
            if (dst.length() < 1024) throw new Exception("下载下来的文件太小，可能不是 APK");
            return dst;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String get(String u, int timeout) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(u).openConnection();
            conn.setConnectTimeout(timeout / 2);
            conn.setReadTimeout(timeout);
            conn.setRequestProperty("User-Agent", "CPUHUD-Updater");
            if (conn.getResponseCode() != 200) return null;
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
