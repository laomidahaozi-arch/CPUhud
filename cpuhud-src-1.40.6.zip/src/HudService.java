package com.dsh.cpuhud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.animation.ValueAnimator;
import android.view.Gravity;
import android.view.animation.DecelerateInterpolator;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 悬浮窗。三种尺寸（点击循环）：简 / 标准 / 详细；长按隐藏。
 * 游戏模式（横屏或名单内应用，也可手动强制）：曲线变大，多显示帧时间与卡顿数。
 * 不透明度可在 App 里调，实时生效。
 */
public class HudService extends Service {
    private static final int C_FPS = 0xFF5AD1FF, C_W = 0xFFFFB25A, C_CHG = 0xFF7CFFB2,
            C_TXT = 0xFFDDE5F2, C_DIM = 0xFF9FB0C7;
    private static final int MODE_MINI = 0, MODE_STD = 1, MODE_FULL = 2;
    private static final String PREF = "hud";

    /* 贴边窄条尺寸（dp）。
       DOCK_BAR_W 是看得见的那根竖条；DOCK_WIN_W 是整个窗口，
       比竖条宽出来的一圈是透明区域，专门留作点击热区（竖条太细时手指才不会点空）。
       想让条子更细：只改 DOCK_BAR_W；想连热区一起收窄：再改 DOCK_WIN_W。 */
    private static final int DOCK_BAR_W = 6;
    private static final int DOCK_WIN_W = 18;
    private static final int DOCK_BAR_H = 54;
    private static final int DOCK_WIN_H = 64;

    private WindowManager wm;
    private View card;
    private WindowManager.LayoutParams lp;
    private LinearLayout box;
    private GradientDrawable bgDrawable;
    private TextView l1, l2, l3, l4;
    private SparkChart chart;
    private int mode = MODE_STD;
    private int alphaPercent = 78;
    private boolean gameForce = false;
    private boolean touchLock = false;
    private int showMask = HudConfigActivity.SHOW_ALL;
    private int themeMode = 0;
    private int radiusDp = 18;
    private boolean dark = true;
    private int cText = 0xFFDDE5F2, cDim = 0xFF9FB0C7, cAccent = 0xFF5AD1FF;
    private int accentMode = 0, fontScale = 1;
    private boolean showBorder = true;
    private int dockedSide = 0;   // 0 未贴边, 1 左, 2 右
    private View strip;
    private GradientDrawable stripBg;
    private boolean drawer = false;
    private int drawerSide = 0;
    private int lastMoveX = 0;
    private long lastMoveT = 0;
    private float velocity = 0f;
    private ValueAnimator widthAnim;
    private ValueAnimator slideAnim;
    private boolean gameOn = false;
    private ScheduledExecutorService exec;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Snapshot last;
    /** 供其它界面读取最新一帧（只读）。 */
    public static volatile Snapshot lastSnapshot;
    /** 悬浮窗服务是否在跑（主界面按钮靠它决定显示开还是关）。 */
    public static volatile boolean running = false;
    private boolean online = false;
    private long lastOk = 0;
    private PowerManager pm;

    private long lastTapAt = 0;
    private final Runnable tapAction = new Runnable() {
        @Override public void run() { cycleMode(); }
    };

    private int downX, downY, startX, startY;
    private boolean moved;
    private long downT;

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                    if ("alpha".equals(key)) {
                        alphaPercent = sp.getInt("alpha", 78);
                        applyAlpha();
                    } else if ("gameForce".equals(key)) {
                        gameForce = sp.getBoolean("gameForce", false);
        touchLock = sp.getBoolean("touchLock", false);
        showMask = sp.getInt("showMask", HudConfigActivity.SHOW_ALL);
        themeMode = sp.getInt("theme", 0);
        radiusDp = sp.getInt("radius", 18);
        dark = resolveDark();
                        if (last != null) render(last);
                    }
                }
            };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        DataSource.init(getApplicationContext());
        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        mode = sp.getInt("mode", MODE_STD);
        alphaPercent = sp.getInt("alpha", 78);
        gameForce = sp.getBoolean("gameForce", false);
        touchLock = sp.getBoolean("touchLock", false);
        showMask = sp.getInt("showMask", HudConfigActivity.SHOW_ALL);
        themeMode = sp.getInt("theme", 0);
        radiusDp = sp.getInt("radius", 18);
        dark = resolveDark();
        sp.registerOnSharedPreferenceChangeListener(prefListener);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (card == null) show();
        return START_STICKY;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setIncludeFontPadding(false);
        t.setSingleLine(false);
        return t;
    }

    private void show() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "CPU HUD：还差悬浮窗权限", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);

        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(11), dp(7), dp(11), dp(7));

        bgDrawable = new GradientDrawable();
        bgDrawable.setColor(0xE6101419);
        bgDrawable.setCornerRadius(dp(13));
        bgDrawable.setStroke(dp(1), 0x44FFFFFF);
        box.setBackground(bgDrawable);
        box.setElevation(dp(6));

        l1 = text("正在连接…", 12f, C_TXT, true);
        l2 = text("FPS --", 15.5f, C_TXT, true);
        l3 = text("—", 9.5f, C_DIM, false);
        l4 = text("—", 9f, 0xFF7F8FA3, false);

        chart = new SparkChart(this);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(38));
        clp.topMargin = dp(3);
        clp.bottomMargin = dp(1);

        box.addView(l1);
        box.addView(l2);
        box.addView(chart, clp);
        box.addView(l3);
        box.addView(l4);

        lp = new WindowManager.LayoutParams(
                dp(244), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        lp.x = sp.getInt("x", dp(8));
        lp.y = sp.getInt("y", dp(210));

        strip = new View(this);
        stripBg = new GradientDrawable();
        stripBg.setColor(cAccent);
        stripBg.setCornerRadius(dp(DOCK_BAR_W / 2));
        strip.setBackground(stripBg);
        strip.setVisibility(View.GONE);

        FrameLayout holder = new FrameLayout(this);
        holder.addView(box, new FrameLayout.LayoutParams(dp(244), FrameLayout.LayoutParams.WRAP_CONTENT));
        holder.setClipChildren(true);
        FrameLayout.LayoutParams stripLp = new FrameLayout.LayoutParams(dp(DOCK_BAR_W), dp(DOCK_BAR_H));
        stripLp.gravity = Gravity.CENTER;
        holder.addView(strip, stripLp);

        card = holder;
        card.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: {
                        android.util.Log.i("CPUHUD", "down docked=" + dockedSide + " w=" + lp.width);
                        downX = (int) e.getRawX();
                        downY = (int) e.getRawY();
                        downT = System.currentTimeMillis();
                        lastMoveT = downT;
                        lastMoveX = downX;
                        velocity = 0;
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    }
                    case MotionEvent.ACTION_MOVE: {
                        int dx = (int) e.getRawX() - downX;
                        int dy = (int) e.getRawY() - downY;
                        long now = System.currentTimeMillis();
                        if (now - lastMoveT > 10) {
                            velocity = (e.getRawX() - lastMoveX) / (float) (now - lastMoveT);   // px/ms
                            lastMoveT = now;
                            lastMoveX = (int) e.getRawX();
                        }
                        if (dockedSide != 0) return true;      // 贴边时只有单击，不跟手拖
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            lp.x = startX + dx;
                            lp.y = startY + dy;
                            try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        long dt = System.currentTimeMillis() - downT;
                        if (!moved && dockedSide != 0) {
                            expandDock(dockedSide);            // 点一下自动伸展
                            return true;
                        }
                        if (!moved) {
                            if (dt >= 550) {
                                hide();
                            } else {
                                long now = System.currentTimeMillis();
                                if (now - lastTapAt < 300) {
                                    lastTapAt = 0;
                                    ui.removeCallbacks(tapAction);
                                    cycleAlpha();
                                } else {
                                    lastTapAt = now;
                                    ui.postDelayed(tapAction, 320);
                                }
                            }
                        } else {
                            android.util.Log.i("CPUHUD", "up drag x=" + lp.x + " w=" + lp.width);
                            if (dockedSide != 0) {
                                dockedSide = 0;
                                getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("dock", 0).apply();
                            }
                            getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                    .putInt("x", lp.x).putInt("y", lp.y).apply();
                            int screenW = getResources().getDisplayMetrics().widthPixels;
                            int cx = lp.x + cardW() / 2;
                            if (cx < screenW / 7) dockTo(1);
                            else if (cx > screenW * 6 / 7) dockTo(2);
                        }
                        return true;
                    }
                }
                return false;
            }
        });

        try {
            wm.addView(card, lp);
            android.util.Log.i("CPUHUD", "addView ok w=" + lp.width + " h=" + lp.height);
        } catch (Exception ex) {
            android.util.Log.e("CPUHUD", "addView failed: " + ex);
            Toast.makeText(this, "悬浮窗失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        card.post(new Runnable() {
            @Override public void run() {
                int d = getSharedPreferences(PREF, MODE_PRIVATE).getInt("dock", 0);
                if (d == 1 || d == 2) dockTo(d);
            }
        });
        applyAlpha();
        applyPalette();
        applyMode();
        applyTouchLock();
        goForeground();
        startPolling();
        android.util.Log.i("CPUHUD", "show done");
    }

    /** 防误触：整块悬浮窗变成「不可点」，手势全部穿透给下面的游戏。 */
    private void applyTouchLock() {
        if (lp == null || card == null) return;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        if (touchLock) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        lp.flags = flags;
        try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
        updateBorder();
    }

    private void updateBorder() {
        applyPalette();
    }

    /** 侧滑贴边 / 回弹动画。 */
    private void animateTo(final int targetX, final int targetY) {
        if (lp == null || card == null) return;
        if (slideAnim != null) slideAnim.cancel();
        final int sx = lp.x, sy = lp.y;
        slideAnim = ValueAnimator.ofFloat(0f, 1f);
        slideAnim.setDuration(240);
        slideAnim.setInterpolator(new DecelerateInterpolator());
        slideAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float f = (Float) a.getAnimatedValue();
                lp.x = sx + (int) ((targetX - sx) * f);
                lp.y = sy + (int) ((targetY - sy) * f);
                try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
            }
        });
        slideAnim.start();
    }

    private int cardW() {
        return card != null && card.getWidth() > 0 ? card.getWidth() : dp(244);
    }

    /** 贴到屏幕左/右边缘，只留一条窄边在外面。 */
    /** 贴边时把整块卡片换成一条窄条，视觉上“收成边缘把手”。 */
    private void applyDockVisual(int side) {
        if (box == null || strip == null || lp == null) return;
        if (side == 0) {
            box.setVisibility(View.VISIBLE);
            strip.setVisibility(View.GONE);
            lp.width = dp(244);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            box.setVisibility(View.GONE);
            strip.setVisibility(View.VISIBLE);
            lp.width = dp(DOCK_WIN_W);
            lp.height = dp(DOCK_WIN_H);
        }
        try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
    }

    /** 抽屉起点：窄条宽度、边缘对齐、内容可见（靠裁切露出）。 */
    private void applyDrawerStart(int side) {
        int screen = getResources().getDisplayMetrics().widthPixels;
        strip.setVisibility(View.GONE);
        box.setVisibility(View.VISIBLE);
        lp.width = dp(DOCK_WIN_W);
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.x = side == 1 ? dp(14) : screen - dp(DOCK_WIN_W) - dp(14);
        try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
        card.setAlpha(0.62f);
    }

    private void setDrawerWidth(int w, int side) {
        int screen = getResources().getDisplayMetrics().widthPixels;
        lp.width = w;
        lp.x = side == 1 ? dp(14) : screen - w - dp(14);
        try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
        float p = (w - dp(DOCK_WIN_W)) / (float) Math.max(1, dp(244) - dp(DOCK_WIN_W));
        card.setAlpha((0.62f + 0.38f * p) * Math.max(20, Math.min(100, alphaPercent)) / 100f);
    }

    /** 点窄条 → 自动伸展成完整卡片（带轻微回弹）。 */
    private void expandDock(final int side) {
        if (widthAnim != null) widthAnim.cancel();
        final int screen = getResources().getDisplayMetrics().widthPixels;
        final int fromW = lp.width;
        final int toW = dp(244);
        final int fromX = lp.x;
        final int toX = side == 1 ? dp(14) : screen - dp(244) - dp(14);
        final float baseAlpha = Math.max(20, Math.min(100, alphaPercent)) / 100f;

        strip.setVisibility(View.GONE);
        box.setVisibility(View.VISIBLE);
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        widthAnim = ValueAnimator.ofFloat(0f, 1f);
        widthAnim.setDuration(260);
        widthAnim.setInterpolator(new android.view.animation.OvershootInterpolator(0.12f));
        widthAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float raw = (Float) a.getAnimatedValue();
                float f = Math.max(0f, Math.min(1f, raw));
                lp.width = fromW + (int) ((toW - fromW) * f);
                lp.x = fromX + (int) ((toX - fromX) * f);
                try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
                // 展开过程中先压到完全不透明（加深突出），伸展完再回落
                card.setAlpha((0.62f + 0.48f * f) * baseAlpha);
            }
        });
        widthAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                dockedSide = 0;
                applyDockVisual(0);
                // 完全展开后再淡回用户设定的透明度
                final float from = Math.max(20, Math.min(100, alphaPercent)) / 100f;
                ValueAnimator back = ValueAnimator.ofFloat(1f, from);
                back.setDuration(220);
                back.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(ValueAnimator b) {
                        card.setAlpha((Float) b.getAnimatedValue());
                    }
                });
                back.start();
                getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("dock", 0).apply();
            }
        });
        widthAnim.start();
    }

    /** 吸附收起：宽度/透明度/位置一起过渡，末尾才切成窄条，避免“啪”一下变细。 */
    private void dockTo(final int side) {
        final int screen = getResources().getDisplayMetrics().widthPixels;
        final int inset = dp(14);
        final int fromW = lp.width;
        final int toW = dp(DOCK_WIN_W);
        final int fromX = lp.x;
        final int toX = side == 1 ? inset : screen - toW - inset;
        final float baseAlpha = Math.max(20, Math.min(100, alphaPercent)) / 100f;
        dockedSide = side;
        if (widthAnim != null) widthAnim.cancel();
        widthAnim = ValueAnimator.ofFloat(0f, 1f);
        widthAnim.setDuration(240);
        widthAnim.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        widthAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float f = (Float) a.getAnimatedValue();
                lp.width = fromW + (int) ((toW - fromW) * f);
                lp.x = fromX + (int) ((toX - fromX) * f);
                try { wm.updateViewLayout(card, lp); } catch (Throwable ignored) { }
                card.setAlpha((1f - 0.38f * f) * baseAlpha);
            }
        });
        widthAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                applyDockVisual(side);
                applyAlpha();
            }
        });
        widthAnim.start();
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("dock", side).putInt("x", toX).apply();
    }

    /** 从贴边状态滑回屏内。 */
    private void undock() {
        int screen = getResources().getDisplayMetrics().widthPixels;
        int side = dockedSide;
        dockedSide = 0;
        applyDockVisual(0);
        int targetX = side == 1 ? dp(8) : screen - cardW() - dp(8);
        animateTo(targetX, lp == null ? dp(220) : lp.y);
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("dock", 0).putInt("x", targetX).apply();
    }

    private void goForeground() {
        try {
            String ch = "hud";
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(ch) == null) {
                NotificationChannel c = new NotificationChannel(ch, "CPU HUD", NotificationManager.IMPORTANCE_MIN);
                c.setShowBadge(false);
                c.setSound(null, null);
                nm.createNotificationChannel(c);
            }
            Intent toApp = new Intent(this, MainActivity.class);
            toApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, toApp, PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(this, ch)
                    .setContentTitle("CPU HUD 运行中")
                    .setContentText("点按打开设置：透明度 / 游戏模式")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            startForeground(1, n);
        } catch (Throwable ignored) { }
    }

    /** 有的机型上 SharedPreferences 监听不触发，这里每秒兜一次。 */
    private long lastSampleAt = 0;
    private long lastCpuTicks = -1;

    /** 诊断：记录采样耗时与本进程 CPU 占用，写进 logcat（tag=CPUHUD）。 */
    private void logDiag() {
        long now = System.currentTimeMillis();
        long ticks = -1;
        try (java.io.BufferedReader r = new java.io.BufferedReader(
                new java.io.FileReader("/proc/self/stat"))) {
            String line = r.readLine();
            if (line != null) {
                int p = line.lastIndexOf(')');
                String[] f = line.substring(p + 2).split(" ");
                ticks = Long.parseLong(f[11]) + Long.parseLong(f[12]);  // utime + stime
            }
        } catch (Throwable ignored) { }
        String cpu = "";
        if (lastCpuTicks >= 0 && ticks >= 0 && lastSampleAt > 0) {
            double secs = (now - lastSampleAt) / 1000.0;
            double pct = (ticks - lastCpuTicks) / secs / 100.0 / Runtime.getRuntime().availableProcessors() * 100;
            cpu = String.format(java.util.Locale.US, " cpu=%.1f%%", pct);
        }
        lastCpuTicks = ticks;
        lastSampleAt = now;
        android.util.Log.i("CPUHUD", "sample " + DataSource.diag() + cpu + " src=" + DataSource.lastSource() + " | " + DataSource.fpsDebug() + " | " + DataSource.pwrDebug());
    }

    private void syncPrefs() {
        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        int a = sp.getInt("alpha", 78);
        if (a != alphaPercent) { alphaPercent = a; applyAlpha(); }
        boolean lock = sp.getBoolean("touchLock", false);
        if (lock != touchLock) { touchLock = lock; applyTouchLock(); }
        boolean gf = sp.getBoolean("gameForce", false);
        if (gf != gameForce) { gameForce = gf; applyMode(); }
        int m = sp.getInt("showMask", HudConfigActivity.SHOW_ALL);
        int t = sp.getInt("theme", 0);
        int rd = sp.getInt("radius", 18);
        int ac = sp.getInt("accent", 0);
        int fs = sp.getInt("font", 1);
        boolean bd = sp.getBoolean("border", true);
        if (m != showMask || t != themeMode || rd != radiusDp || ac != accentMode || fs != fontScale || bd != showBorder) {
            accentMode = ac; fontScale = fs; showBorder = bd;
            showMask = m; themeMode = t; radiusDp = rd;
            dark = resolveDark();
            applyPalette();
            applyMode();
            if (last != null) render(last);
        }
    }

    private boolean resolveDark() {
        if (themeMode == 1) return true;
        if (themeMode == 2) return false;
        int ui = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return ui == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    /** 跟随系统主题：深色/浅色用两套底色与文字色，强调色尽量取系统主题色。 */
    private void applyPalette() {
        if (bgDrawable == null) return;
        int bg = dark ? 0xE6101419 : 0xF2F6F8FB;
        int stroke = dark ? 0x44FFFFFF : 0x33000000;
        cText = dark ? 0xFFDDE5F2 : 0xFF16202C;
        cDim = dark ? 0xFF9FB0C7 : 0xFF5B6B7C;
        cAccent = presetAccent();
        applyFont();
        bgDrawable.setColor(bg);
        bgDrawable.setCornerRadius(dp(radiusDp));
        bgDrawable.setStroke(dp(showBorder ? 1 : 0), touchLock ? 0xAAFFB25A : (isGame() ? (cAccent & 0x00FFFFFF | 0x88000000) : stroke));
        if (l1 != null) l1.setTextColor(cText);
        if (l2 != null) l2.setTextColor(cText);
        if (l3 != null) l3.setTextColor(cDim);
        if (l4 != null) l4.setTextColor(cDim);
        if (chart != null) chart.setPalette(dark, cAccent);
    }

    private int presetAccent() {
        switch (accentMode) {
            case 1: return dark ? 0xFF5AD1FF : 0xFF0E7C99;   // 青
            case 2: return dark ? 0xFFC9A7FF : 0xFF6C4BD1;   // 紫
            case 3: return dark ? 0xFFFFB25A : 0xFFB26100;   // 橙
            case 4: return dark ? 0xFF7CFFB2 : 0xFF1F8A4C;   // 绿
            case 5: return dark ? 0xFFFF9EC4 : 0xFFB03060;   // 粉
            case 6: return getSharedPreferences(PREF, MODE_PRIVATE).getInt("accentRGB", 0xFF5AD1FF);   // 自定义
            default: return systemAccent();                   // 跟随系统
        }
    }

    private void applyFont() {
        float k = fontScale == 0 ? 0.88f : (fontScale == 2 ? 1.16f : 1f);
        if (l1 != null) l1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f * k);
        if (l2 != null) l2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f * k);
        if (l3 != null) l3.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f * k);
        if (l4 != null) l4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f * k);
    }

    private int systemAccent() {
        try {
            return getColor(dark ? android.R.color.system_accent1_300 : android.R.color.system_accent1_500);
        } catch (Throwable t) {
            return dark ? 0xFF5AD1FF : 0xFF0E7C99;
        }
    }

    private void applyAlpha() {
        if (card != null) card.setAlpha(Math.max(20, Math.min(100, alphaPercent)) / 100f);
    }

    private boolean isGame() {
        return gameOn || gameForce;
    }

    private void applyMode() {
        if (card == null) return;
        l1.setVisibility(View.VISIBLE);
        l2.setVisibility(mode == MODE_MINI ? View.GONE : View.VISIBLE);
        chart.setVisibility(View.VISIBLE);               // 简版也保留曲线
        l3.setVisibility(mode == MODE_MINI ? View.GONE : View.VISIBLE);
        l4.setVisibility(mode == MODE_FULL ? View.VISIBLE : View.GONE);

        LinearLayout.LayoutParams clp = (LinearLayout.LayoutParams) chart.getLayoutParams();
        int h = mode == MODE_MINI ? dp(20) : (isGame() ? dp(58) : dp(36));
        if (clp.height != h) {
            clp.height = h;
            chart.setLayoutParams(clp);
        }
        updateBorder();
        if (last != null) render(last);
    }

    private void cycleAlpha() {
        final int[] seq = {100, 78, 55, 35};
        int idx = 0;
        for (int i = 0; i < seq.length; i++) if (seq[i] == alphaPercent) { idx = i; break; }
        alphaPercent = seq[(idx + 1) % seq.length];
        applyAlpha();
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("alpha", alphaPercent).apply();
        Toast.makeText(this, "不透明度 " + alphaPercent + "%", Toast.LENGTH_SHORT).show();
    }

    private void cycleMode() {
        mode = (mode + 1) % 3;
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("mode", mode).apply();
        applyMode();
    }

    private void hide() {
        Toast.makeText(this, "CPU HUD 已隐藏", Toast.LENGTH_SHORT).show();
        stopSelf();
    }

    private void startPolling() {
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleWithFixedDelay(new Runnable() {
            @Override public void run() {
                PowerManager p = pm;
                if (p != null && p.isInteractive()) {
                    try {
                        final Snapshot s = DataSource.fetch();
                        lastOk = System.currentTimeMillis();
                        ui.post(new Runnable() { @Override public void run() {
                            last = s;
        lastSnapshot = s; online = true;
                            syncPrefs();      // 每秒兜一次：透明度/防误触/游戏模式
                            render(s);
                            if ((System.currentTimeMillis() / 1000) % 5 == 0) logDiag();
                        } });
                    } catch (final Exception e) {
                        ui.post(new Runnable() { @Override public void run() { online = false; renderStatusOnly(); } });
                    }
                } else {
                    ui.post(new Runnable() { @Override public void run() { if (card != null && last == null) l1.setText("正在连接…"); } });
                }
            }
        }, 0, 1000, TimeUnit.MILLISECONDS);
    }

    private void renderStatusOnly() {
        if (last == null) {
            l1.setText("等待采样…");
            l2.setText(Shell.hasRoot() ? "Root 直读，采样重试中" : (ShizukuShell.granted() ? "Shizuku 已授权，采样重试中" : "请先授予 Shizuku 权限"));
            return;
        }
        l3.setText("⚠ 数据已停 " + ((System.currentTimeMillis() - lastOk) / 1000) + "s");
    }

    private void render(Snapshot s) {
        boolean wasGame = gameOn;
        gameOn = s.gameOn;
        if (wasGame != gameOn) applyMode();

        final boolean showTemp = (showMask & HudConfigActivity.SHOW_TEMP) != 0;
        final boolean showFreq = (showMask & HudConfigActivity.SHOW_FREQ) != 0;
        final boolean showPower = (showMask & HudConfigActivity.SHOW_POWER) != 0;
        final boolean showFps = (showMask & HudConfigActivity.SHOW_FPS) != 0;
        final boolean showLoad = (showMask & HudConfigActivity.SHOW_LOAD) != 0;
        final boolean showMem = (showMask & HudConfigActivity.SHOW_MEM) != 0;
        final boolean showBatt = (showMask & HudConfigActivity.SHOW_BATT) != 0;
        final boolean showTherm = (showMask & HudConfigActivity.SHOW_THERM) != 0;
        final boolean showHz = (showMask & HudConfigActivity.SHOW_HZ) != 0;
        final int cWarm = 0xFFFFB25A, cCold = 0xFF7CFFB2;

        if (stripBg != null) {
            stripBg.setColor(Fmt.tempColor(s.cpu));
        }
        if (showFps || showPower) {
            chart.setVisibility(View.VISIBLE);
            chart.setData(s.histFps, s.histW, (float) s.dispRate);
        } else {
            chart.setVisibility(View.GONE);
        }

        if (mode == MODE_MINI) {
            SpannableStringBuilder m = new SpannableStringBuilder();
            if (showTemp) appendTemp(m, "CPU ", s.cpu);
            if (showFps) {
                if (m.length() > 0) m.append("  ");
                int st = m.length();
                m.append(s.fps >= 0 ? String.valueOf((int) Math.round(s.fps)) : "--").append("fps");
                m.setSpan(new ForegroundColorSpan(fpsColor(s.fps, fpsTarget(s))), st, m.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (showPower) {
                if (m.length() > 0) m.append("  ");
                int st = m.length();
                m.append(powerText(s));
                m.setSpan(new ForegroundColorSpan(s.powerCharging ? cCold : cWarm), st, m.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (m.length() == 0) m.append("—");
            l1.setText(m);
            l1.setVisibility(View.VISIBLE);
            l2.setVisibility(View.GONE);
            l3.setVisibility(View.GONE);
            l4.setVisibility(View.GONE);
            return;
        }

        SpannableStringBuilder a = new SpannableStringBuilder();
        if (showTemp) {
            appendTemp(a, "CPU ", s.cpu);
            appendTemp(a, "  GPU ", s.gpu);
            appendTemp(a, "  SOC ", s.soc);
        }
        l1.setText(a);
        l1.setVisibility(a.length() > 0 ? View.VISIBLE : View.GONE);

        SpannableStringBuilder b = new SpannableStringBuilder();
        if (showFps) {
            b.append("FPS ");
            int x = b.length();
            b.append(s.fps >= 0 ? String.valueOf((int) Math.round(s.fps)) : "--");
            b.setSpan(new ForegroundColorSpan(fpsColor(s.fps, fpsTarget(s))), x, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (showPower) {
            if (b.length() > 0) b.append("   ");
            int x = b.length();
            b.append(powerText(s));
            b.setSpan(new ForegroundColorSpan(s.powerCharging ? cCold : cWarm), x, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (showLoad) {
            if (b.length() > 0) b.append("   ");
            int x = b.length();
            b.append(String.valueOf((int) Math.round(s.load))).append("%");
            b.setSpan(new ForegroundColorSpan(cDim), x, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        l2.setText(b);
        l2.setVisibility(b.length() > 0 ? View.VISIBLE : View.GONE);

        String third = null;
        if (showFreq) {
            StringBuilder f = new StringBuilder();
            int n = Math.min(s.cur.length, 3);
            for (int i = 0; i < n; i++) {
                if (i > 0) f.append("  ");
                f.append(Fmt.ghz(s.cur[i])).append('/').append(Fmt.ghz(s.max[i]));
            }
            if (n > 0) f.append(" GHz");
            third = f.toString();
        } else if (isGame()) {
            String jankTxt = "global".equals(s.fpsSrc) ? "卡顿 —" : "卡顿 " + (int) Math.round(s.fpsJank) + "/s";
            third = "FT " + String.format(java.util.Locale.US, "%.1f", s.fpsFt) + "ms   " + jankTxt
                    + "   峰值 " + Fmt.ghz(s.freqMax) + "G";
        }
        if (third != null && third.length() > 0) {
            l3.setText(third);
            l3.setVisibility(View.VISIBLE);
        } else {
            l3.setVisibility(View.GONE);
        }

        // 第三、四行小字：内存 / 电量 / 屏温 / 电池 / 电流 / 刷新率 / 热状态
        // 标准模式也显示 —— 这两行信息密度最高，藏起来反而可惜
        StringBuilder d = new StringBuilder();
        if (showMem) {
            d.append("内存").append(Fmt.g1(s.memUsed)).append('/').append(Fmt.g1(s.memTotal)).append('G');
        }
        if (showBatt) {
            if (d.length() > 0) d.append("  ");
            d.append("电").append((int) s.battLevel).append('%').append(s.powerCharging ? "⚡" : "");
        }
        StringBuilder e = new StringBuilder();
        if (showTherm) {
            e.append("屏").append(Fmt.t1(s.skin)).append("°  电池").append(Fmt.t1(s.battTemp)).append('°');
        }
        if (showBatt) {
            if (e.length() > 0) e.append("  ");
            e.append((int) Math.abs(s.currentMa)).append("mA");
        }
        if (showHz) {
            if (e.length() > 0) e.append("  ");
            e.append((int) s.dispRate).append("Hz");
        }
        if (showTherm) {
            if (e.length() > 0) e.append("  热:").append(s.thermalLabel);
        }
        if (e.length() > 0) {
            if (d.length() > 0) d.append('\n');
            d.append(e);
        }
        // 游戏模式下多给一行帧时间 / 卡顿
        if (mode == MODE_FULL && isGame() && showFps) {
            d.append('\n').append("帧时间 ").append(String.format(java.util.Locale.US, "%.1f", s.fpsFt)).append("ms")
                    .append("  卡顿 ").append((int) Math.round(s.fpsJank)).append("/s");
        }
        l4.setText(d.toString());
        l4.setVisibility(d.length() > 0 ? View.VISIBLE : View.GONE);
    }

    private String powerText(Snapshot s) {
        if (s.voltV <= 0) return "--";          // 电压没读到，功率也标未知
        return String.format(java.util.Locale.US, "%+.2f", s.powerW) + "W";
    }

    /**
     * 目标帧率：很多游戏自己封顶 60（哪怕屏幕 120Hz），拿屏幕刷新率当基准会把正常的 60 帧标成黄色。
     * 用最近曲线的 90 分位当基准，既能反映「掉帧」，又不会因为游戏自身封顶而误报。
     */
    private double fpsTarget(Snapshot s) {
        double rate = s.dispRate > 0 ? s.dispRate : 60;
        float[] h = s.histFps;
        if (h == null || h.length < 8) return rate;
        float[] c = h.clone();
        java.util.Arrays.sort(c);
        double p90 = c[(int) ((c.length - 1) * 0.9)];
        return Math.max(30, Math.min(rate, Math.max(p90, 30)));
    }

    private int fpsColor(double fps, double target) {
        if (fps < 1) return C_DIM;
        if (fps >= target * 0.92) return C_FPS;
        if (fps >= target * 0.7) return 0xFFBFFA5A;
        if (fps >= target * 0.5) return 0xFFFFE066;
        return 0xFFFF7A6B;
    }

    private void appendTemp(SpannableStringBuilder sb, String label, double v) {
        sb.append(label);
        int start = sb.length();
        if (v <= 0) sb.append("--");            // 这一轮没读到就当未知，不要显示 0.0°
        else sb.append(Fmt.t1(v)).append("°");
        sb.setSpan(new ForegroundColorSpan(Fmt.tempColor(v)), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    @Override public void onDestroy() {
        running = false;
        if (exec != null) exec.shutdownNow();
        // 关掉悬浮窗就把 TimeStats 关了 —— 别给系统留后台开销
        try {
            new Thread(new Runnable() {
                @Override public void run() {
                    try { Shell.exec("dumpsys SurfaceFlinger --timestats -disable >/dev/null 2>&1", 3000); }
                    catch (Throwable ignored) { }
                }
            }).start();
        } catch (Throwable ignored) { }
        try { getSharedPreferences(PREF, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener); } catch (Exception ignored) { }
        if (wm != null && card != null) {
            try { wm.removeView(card); } catch (Exception ignored) { }
            card = null;
        }
        super.onDestroy();
    }
}
