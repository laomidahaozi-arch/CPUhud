package com.dsh.cpuhud;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** CPU-Z 风格的硬件信息采集。需要 shell 的项目优先走 Shizuku，拿不到就直读 /sys，再不行显示 —。 */
public final class HwInfo {

    private HwInfo() { }

    /** 走 Shizuku 执行；没授权返回 null。 */
    private static String sh(String cmd) {
        try {
            if (!ShizukuShell.granted()) return null;
            String out = Shell.exec(cmd, 1200);
            return out == null ? null : out.trim();
        } catch (Throwable t) {
            return null;
        }
    }

    /** 直读文件（没 root 时多数 /sys 会被 SELinux 拒绝）。 */
    private static String cat(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return r.readLine();
        } catch (Throwable t) {
            return null;
        }
    }

    /** 高通平台代号 → SM 型号（很多骁龙机器的 ro.board.platform 是代号，不是 SM 号）。 */
    private static final String[][] QC_CODENAMES = {
        {"sun", "SM8750"},        // 骁龙 8 Elite
        {"pineapple", "SM8650"},  // 骁龙 8 Gen3
        {"kalama", "SM8550"},     // 骁龙 8 Gen2
        {"kailua", "SM8475"},     // 骁龙 8+ Gen1
        {"taro", "SM8450"},       // 骁龙 8 Gen1
        {"cape", "SM8550"},       // 8 Gen2 衍生
        {"crow", "SM7550"},       // 骁龙 7 Gen3
        {"parrot", "SM6450"},     // 骁龙 6 Gen1 系列
        {"volcano", "SM6350"},    // 骁龙 6 系
    };

    /** 把平台代号规范化成 SM 型号；不是高通则原样返回。 */
    public static String normalizeSoc(String soc) {
        if (soc == null) return "";
        String u = soc.trim().toLowerCase(Locale.US);
        for (String[] m : QC_CODENAMES) {
            if (u.equals(m[0]) || u.startsWith(m[0])) return m[1];
        }
        return soc;
    }

    private static String first(String... vals) {
        for (String v : vals) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "—";
    }

    private static String fmtG(long bytes) {
        if (bytes <= 0) return "—";
        double g = bytes / 1073741824.0;
        return String.format(Locale.US, "%.1f GB", g);
    }

    /** 返回「标题 → 若干 [标签, 值]」。 */
    public static Map<String, List<String[]>> collect(Context ctx) {
        Map<String, List<String[]>> out = new LinkedHashMap<>();

        // ---------------- 设备 ----------------
        List<String[]> dev = new ArrayList<>();
        dev.add(new String[]{"厂商", first(Build.MANUFACTURER)});
        dev.add(new String[]{"型号", first(Build.MODEL)});
        dev.add(new String[]{"品牌 / 代号", first(Build.BRAND) + " / " + first(Build.DEVICE)});
        dev.add(new String[]{"系统", "Android " + Build.VERSION.RELEASE + "（SDK " + Build.VERSION.SDK_INT + "）"});
        if (Build.VERSION.SDK_INT >= 23)
            dev.add(new String[]{"安全补丁", first(Build.VERSION.SECURITY_PATCH)});
        dev.add(new String[]{"内核", first(kernelVersion())});
        dev.add(new String[]{"架构", first(Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : null)});
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        android.view.Display d = ctx.getDisplay();
        String rate = "—";
        try {
            if (d != null) {
                float r = d.getRefreshRate();
                rate = r > 0 ? Math.round(r) + " Hz" : "—";
                if (Build.VERSION.SDK_INT >= 23) {
                    android.view.Display.Mode m = d.getMode();
                    if (m != null) rate = Math.round(m.getRefreshRate()) + " Hz";
                }
            }
        } catch (Throwable ignored) { }
        dev.add(new String[]{"屏幕", dm.widthPixels + " × " + dm.heightPixels + " @ " + dm.densityDpi + " dpi"});
        dev.add(new String[]{"刷新率", rate});
        long up = SystemClock.elapsedRealtime();
        dev.add(new String[]{"开机时长", String.format(Locale.US, "%d 天 %d 小时 %d 分",
                up / 86400000L, (up / 3600000L) % 24, (up / 60000L) % 60)});
        out.put("设备", dev);

        // ---------------- 处理器 ----------------
        List<String[]> cpu = new ArrayList<>();
        String soc = null;
        try {
            if (Build.VERSION.SDK_INT >= 31) soc = Build.SOC_MODEL;
        } catch (Throwable ignored) { }
        if (soc == null || soc.isEmpty() || "unknown".equals(soc)) {
            String hw = sh("grep -m1 -i 'Hardware' /proc/cpuinfo");
            if (hw != null && hw.contains(":")) hw = hw.substring(hw.indexOf(':') + 1).trim();
            soc = hw;
        }
        SocProbe.Info si = SocProbe.get(ctx, false);
        String socRaw = si.raw;
        String socNorm = normalizeSoc(socRaw);
        if (socNorm.equals(socRaw)) {
            String byBoard = normalizeSoc(socRaw);
            if (!byBoard.equals(socRaw)) socNorm = byBoard;
        }
        cpu.add(new String[]{"SoC", first(socNorm, soc, Build.HARDWARE)});
        String market = si.market;
        if (market != null && !market.isEmpty() && !market.equals(socNorm)) {
            cpu.add(new String[]{"型号名", market});
        }
        if (si.vendor != null && !si.vendor.isEmpty()) cpu.add(new String[]{"芯片厂商", si.vendor});
        if (si.deviceMarket != null && !si.deviceMarket.isEmpty()) {
            cpu.add(new String[]{"手机市场名", si.deviceMarket});
        }
        if (si.source != null && !si.source.isEmpty()) cpu.add(new String[]{"识别来源", si.source});
        String socMfr = cat("/sys/devices/soc0/vendor");
        if (socMfr != null) cpu.add(new String[]{"SoC 厂商", socMfr});
        cpu.add(new String[]{"核心数", String.valueOf(Runtime.getRuntime().availableProcessors())});
        String arch = sh("grep -m1 -i 'CPU architecture' /proc/cpuinfo");
        if (arch != null && arch.contains(":")) arch = arch.substring(arch.indexOf(':') + 1).trim();
        // /proc/cpuinfo 的 CPU architecture 是 ARM 架构编号（8/9），不是架构名
        if (arch != null && arch.matches("\\d+")) arch = null;
        cpu.add(new String[]{"架构", first(arch, Build.SUPPORTED_ABIS[0])});
        String gov = sh("for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do v=$(cat $p 2>/dev/null); [ -n \"$v\" ] && echo $v && break; done");
        if (gov == null || gov.isEmpty()) {
            for (int i = 0; i < 8 && (gov == null || gov.isEmpty()); i++) {
                gov = cat("/sys/devices/system/cpu/cpufreq/policy" + i + "/scaling_governor");
                if (gov == null || gov.isEmpty()) gov = cat("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_governor");
            }
        }
        if (gov == null || gov.isEmpty()) {
            String drv = sh("for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_driver /sys/devices/system/cpu/cpu*/cpufreq/scaling_driver; do v=$(cat $p 2>/dev/null); [ -n \"$v\" ] && echo $v && break; done");
            if (drv != null && !drv.isEmpty()) gov = drv + "（驱动）";
        }
        cpu.add(new String[]{"调速器", first(gov)});
        String maxs = sh("for f in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq; do echo -n \"$(cat $f 2>/dev/null) \"; done");
        if (maxs != null && maxs.contains(" ")) {
            String[] parts = maxs.trim().split("\\s+");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length && i < 8; i++) {
                try { sb.append(String.format(Locale.US, "核%d %.2fG\n", i, Long.parseLong(parts[i]) / 1000000.0)); }
                catch (Exception ignored) { }
            }
            if (sb.length() > 0) cpu.add(new String[]{"各核最大频率", sb.toString().trim()});
        }
        out.put("处理器", cpu);

        // ---------------- 图形 ----------------
        List<String[]> gpu = new ArrayList<>();
        String[] gl = glInfo();
        gpu.add(new String[]{"GPU", first(gl[0])});
        gpu.add(new String[]{"厂商", first(gl[1])});
        gpu.add(new String[]{"OpenGL ES", first(gl[2])});
        String gf = sh("cat /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null; "
                + "cat /sys/class/devfreq/gpufreq/max_freq 2>/dev/null; "
                + "cat /sys/class/devfreq/*.gpu/max_freq 2>/dev/null; "
                + "cat /proc/gpufreq/gpufreq_opp_max_freq 2>/dev/null");
        String gcur = sh("cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null; "
                + "cat /proc/gpufreq/gpufreq_var_dump 2>/dev/null | grep -m1 cur_volt");
        if (gf != null && !gf.isEmpty()) {
            try {
                long v = Long.parseLong(gf.split("\\s+")[0]);
                gpu.add(new String[]{"最大频率", String.format(Locale.US, "%.0f MHz", v > 1000000 ? v / 1000000.0 : v / 1000.0)});
            } catch (Exception ignored) { }
        }
        out.put("图形", gpu);

        // ---------------- 温度 ----------------
        List<String[]> tmp = new ArrayList<>();
        String zones = sh("for z in /sys/class/thermal/thermal_zone*; do "
                + "echo \"$(cat $z/type 2>/dev/null)|$(cat $z/temp 2>/dev/null)\"; done");
        double cpuT = -1, gpuT = -1, socT = -1, batT = -1, skinT = -1, maxT = -1;
        if (zones != null) {
            for (String line : zones.split("\n")) {
                String[] f = line.trim().split("\\|");
                if (f.length < 2) continue;
                double v;
                try { v = Double.parseDouble(f[1].trim()); } catch (Exception e) { continue; }
                if (v > 1000) v /= 1000.0;
                if (v < 15 || v > 95) continue;
                maxT = Math.max(maxT, v);
                String t = f[0].toLowerCase();
                if ((t.contains("cpu") || t.contains("tsens") || t.contains("mtkts") || t.contains("cpuss"))
                        && cpuT < 0) cpuT = v;
                else if ((t.contains("gpu") || t.contains("kgsl") || t.contains("adreno")) && gpuT < 0) gpuT = v;
                else if ((t.contains("soc") || t.contains("qti") || t.contains("modem")) && socT < 0) socT = v;
                else if ((t.contains("batt") || t.contains("chg")) && batT < 0) batT = v;
                else if ((t.contains("skin") || t.contains("quiet") || t.contains("xo_therm")
                        || t.contains("pa_therm") || t.contains("shell")) && skinT < 0) skinT = v;
            }
        }
        if (cpuT > 0) tmp.add(new String[]{"CPU", String.format(Locale.US, "%.1f °C", cpuT)});
        if (gpuT > 0) tmp.add(new String[]{"GPU", String.format(Locale.US, "%.1f °C", gpuT)});
        if (socT > 0) tmp.add(new String[]{"SOC", String.format(Locale.US, "%.1f °C", socT)});
        if (batT > 0) tmp.add(new String[]{"电池", String.format(Locale.US, "%.1f °C", batT)});
        if (skinT > 0) tmp.add(new String[]{"机身", String.format(Locale.US, "%.1f °C", skinT)});
        if (cpuT < 0 && maxT > 0) {
            tmp.add(new String[]{"CPU（全区最高）", String.format(Locale.US, "%.1f °C", maxT)});
        }
        if (tmp.isEmpty()) {
            tmp.add(new String[]{"sysfs", "读不到 thermal_zone（" + (Shell.hasRoot() ? "已 root 仍失败" : "需 root 才能读") + "）"});
            String hal = Shell.exec("dumpsys thermalservice 2>/dev/null | grep -m3 'mName=CPU\\|mName=GPU\\|mName=SOC'", 4000);
            if (hal != null && !hal.trim().isEmpty()) {
                for (String line : hal.split("\n")) {
                    Matcher hm = Pattern.compile("mValue=([-0-9.]+).*mName=(\\w+)").matcher(line);
                    if (hm.find()) tmp.add(new String[]{hm.group(2), hm.group(1) + " °C（HAL）"});
                }
            }
        }
        out.put("温度", tmp);

        // ---------------- 内存 ----------------
        List<String[]> mem = new ArrayList<>();
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            mem.add(new String[]{"总容量", fmtG(mi.totalMem)});
            mem.add(new String[]{"可用", fmtG(mi.availMem)});
            mem.add(new String[]{"已用", fmtG(mi.totalMem - mi.availMem)});
            mem.add(new String[]{"占用率", String.format(Locale.US, "%.0f%%", (mi.totalMem - mi.availMem) * 100.0 / mi.totalMem)});
        } catch (Throwable ignored) { }
        String swap = sh("grep -i SwapTotal /proc/meminfo");
        if (swap != null && swap.contains(":")) {
            try {
                long kb = Long.parseLong(swap.substring(swap.indexOf(':') + 1).replaceAll("[^0-9]", ""));
                mem.add(new String[]{"虚拟内存", fmtG(kb * 1024)});
            } catch (Exception ignored) { }
        }
        out.put("内存", mem);

        // ---------------- 存储 ----------------
        List<String[]> rom = new ArrayList<>();
        try {
            StatFs data = new StatFs("/data");
            rom.add(new String[]{"内部存储", fmtG(data.getTotalBytes())});
            rom.add(new String[]{"可用", fmtG(data.getAvailableBytes())});
        } catch (Throwable ignored) { }
        try {
            File ext = Environment.getExternalStorageDirectory();
            if (ext != null) {
                StatFs sd = new StatFs(ext.getAbsolutePath());
                rom.add(new String[]{"共享存储", fmtG(sd.getTotalBytes()) + "（可用 " + fmtG(sd.getAvailableBytes()) + "）"});
            }
        } catch (Throwable ignored) { }
        String mounts = sh("grep -m1 ' /data ' /proc/mounts");
        if (mounts == null) mounts = cat("/proc/mounts");
        if (mounts != null) {
            for (String line : mounts.split("\n")) {
                if (line.contains(" /data ")) {
                    String[] f = line.split("\\s+");
                    if (f.length >= 4) {
                        rom.add(new String[]{"文件系统", f[2]});
                        if (f[3].contains("inlinecrypt")) rom.add(new String[]{"加密", "inline 加密"});
                        if (f[3].contains("discard")) rom.add(new String[]{"TRIM", "支持"});
                    }
                    break;
                }
            }
        }
        String ufs = sh("cat /sys/block/sda/device/model 2>/dev/null");
        rom.add(new String[]{"闪存型号", ufs != null && !ufs.isEmpty() ? ufs.trim() : "需 root（SELinux 限制）"});
        out.put("存储", rom);

        // ---------------- 电池 ----------------
        List<String[]> bat = new ArrayList<>();
        try {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            Intent st = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (st != null) {
                int temp = st.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                int volt = st.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                int health = st.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                String tech = st.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
                bat.add(new String[]{"温度", temp > 0 ? String.format(Locale.US, "%.1f °C", temp / 10.0) : "—"});
                bat.add(new String[]{"电压", volt > 0 ? String.format(Locale.US, "%.3f V", volt / 1000.0) : "—"});
                bat.add(new String[]{"健康", healthLabel(health)});
                if (tech != null) bat.add(new String[]{"技术", tech});
            }
            if (bm != null) {
                long cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                if (cur != 0 && cur != Long.MIN_VALUE) {
                    double ma = Math.abs(cur) > 20000 ? Math.abs(cur) / 1000.0 : Math.abs(cur);
                    bat.add(new String[]{"电流", String.format(Locale.US, "%.0f mA", ma)});
                }
                long cnt = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                if (cnt > 0) bat.add(new String[]{"当前电量", String.format(Locale.US, "%.0f mAh", cnt / 1000.0)});
            }
        } catch (Throwable ignored) { }
        String design = sh("cat /sys/class/power_supply/battery/charge_full_design 2>/dev/null || cat /sys/class/power_supply/bms/charge_full_design 2>/dev/null");
        if (design != null && !design.isEmpty()) {
            try {
                long v = Long.parseLong(design.trim());
                bat.add(new String[]{"设计容量", String.format(Locale.US, "%.0f mAh", v / 1000.0)});
            } catch (Exception ignored) { }
        }
        String cycles = sh("cat /sys/class/power_supply/battery/cycle_count 2>/dev/null");
        if (cycles != null && !cycles.isEmpty()) bat.add(new String[]{"循环次数", cycles.trim()});
        String battType = sh("cat /sys/class/power_supply/battery/technology 2>/dev/null");
        if (battType != null && !battType.isEmpty()) bat.add(new String[]{"电芯类型", battType.trim()});
        out.put("电池", bat);

        // ---------------- 传感器 ----------------
        List<String[]> sen = new ArrayList<>();
        try {
            SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            List<Sensor> list = sm.getSensorList(Sensor.TYPE_ALL);
            sen.add(new String[]{"数量", String.valueOf(list.size())});
            int shown = 0;
            for (Sensor s : list) {
                if (shown++ >= 30) {
                    sen.add(new String[]{"…", "还有 " + (list.size() - 30) + " 个传感器未显示"});
                    break;
                }
                sen.add(new String[]{s.getName(), s.getVendor() + " · v" + s.getVersion()});
            }
        } catch (Throwable ignored) { }
        out.put("传感器", sen);

        return out;
    }

    private static String kernelVersion() {
        String v = System.getProperty("os.version");
        if (v != null) return v;
        String p = cat("/proc/version");
        return p;
    }

    private static String healthLabel(int h) {
        switch (h) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "良好";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "过热";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "损坏";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "过压";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "异常";
            case BatteryManager.BATTERY_HEALTH_COLD: return "过冷";
            default: return "未知";
        }
    }

    /** 供可信度校验使用：只取 GL_RENDERER。 */
    public static String gpuRenderer() {
        try { return glInfo()[0]; } catch (Throwable t) { return "—"; }
    }

    /** EGL 拿 GPU 型号（GL_RENDERER / VENDOR / VERSION）。 */
    private static String[] glInfo() {
        String[] out = new String[]{"—", "—", "—"};
        EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
        EGLContext ctx = EGL14.EGL_NO_CONTEXT;
        EGLSurface surf = EGL14.EGL_NO_SURFACE;
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return out;
            int[] cfgAttr = {EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE};
            EGLConfig[] cfgs = new EGLConfig[1];
            int[] num = new int[1];
            if (!EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfgs, 0, 1, num, 0) || num[0] < 1) return out;
            int[] ctxAttr = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
            ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0);
            int[] sAttr = {EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE};
            surf = EGL14.eglCreatePbufferSurface(dpy, cfgs[0], sAttr, 0);
            if (ctx == null || surf == null) return out;
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) return out;
            String r = GLES20.glGetString(GLES20.GL_RENDERER);
            String v = GLES20.glGetString(GLES20.GL_VENDOR);
            String g = GLES20.glGetString(GLES20.GL_VERSION);
            out[0] = r != null ? r : "—";
            out[1] = v != null ? v : "—";
            out[2] = g != null ? g : "—";
        } catch (Throwable ignored) {
        } finally {
            try {
                if (dpy != EGL14.EGL_NO_DISPLAY && surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
                if (dpy != EGL14.EGL_NO_DISPLAY && ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
                if (dpy != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(dpy);
            } catch (Throwable ignored) { }
        }
        return out;
    }
}
