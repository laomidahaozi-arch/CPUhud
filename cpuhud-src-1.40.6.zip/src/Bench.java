package com.dsh.cpuhud;

import android.util.Log;

import java.util.Arrays;

/**
 * 类 Geekbench 结构的多子项基准（自定义 Workload，不是 GB 本身，分数不可直接对比）：
 *   整数：压缩(字典匹配) / 加密(流密码) / 哈希(整数混合)
 *   浮点：矩阵乘 / N 体(N-Body)
 *   内存：STREAM 式 triad 带宽
 * 每项跑固定迭代数、预热一次、三轮取中位数，最后按参考值归一化成「分」。
 */
public final class Bench {
    private Bench() { }

    public static class Result {
        public double intScore, fpScore, memScore;
        public double single, multi, speedup;
        public double intRate, fpRate, memRate;      // 原始速率（用于标定）
        public double spread;                        // 本次波动（0~1）
    }

    // ---------- 工作负载 ----------
    private static long wCompress(int n) {          // 字典匹配 + 复制，整数为主
        byte[] src = new byte[n], dst = new byte[n];
        for (int i = 0; i < n; i++) src[i] = (byte) ((i * 31 + (i >> 3)) & 0x7F);
        int op = 0;
        for (int i = 0; i < n - 4; i++) {
            if (src[i] == src[i + 1] && src[i + 1] == src[i + 2]) {
                dst[op++] = src[i];
                dst[op++] = 0x55;
                i += 2;
            } else {
                dst[op++] = src[i];
            }
            if (op >= n - 1) op = 0;
        }
        return (long) n + op;
    }

    private static long wCrypto(int n) {            // 流密码式字节加扰
        long x = 0x2545F4914F6CDD1DL, y = 0x9E3779B97F4A7C15L;
        byte[] buf = new byte[4096];
        long sum = 0;
        for (int i = 0; i < n; i++) {
            x ^= x << 13; x ^= x >>> 7; x ^= x << 17;
            y += x * 0x100000001B3L;
            buf[i & 4095] = (byte) (y >>> 24);
            sum += buf[(i * 7) & 4095];
        }
        if (sum == 12345678L) System.out.print("");
        return (long) n * 3;
    }

    private static long wHash(int n) {              // 整数混合（类似 SHA 轮）
        int a = 0x9E3779B9, b = 0x85EBCA6B, c = 0xC2B2AE35, d = 0x27D4EB2F;
        for (int i = 0; i < n; i++) {
            a += b; a ^= a >>> 15; a += c;
            b += c; b ^= b >>> 13; b += d;
            c += d; c ^= c >>> 17; c += a;
            d += a; d ^= d >>> 11; d += b;
        }
        if ((a ^ b ^ c ^ d) == 0x12345678) System.out.print("");
        return (long) n * 4;
    }

    private static double wMatrix(int n) {          // 浮点矩阵乘
        int sz = 24;
        float[][] A = new float[sz][sz], B = new float[sz][sz], C = new float[sz][sz];
        for (int i = 0; i < sz; i++)
            for (int j = 0; j < sz; j++) { A[i][j] = i * 0.5f + j; B[i][j] = i - j * 0.25f; }
        double sink = 0;
        for (int r = 0; r < n; r++) {
            for (int i = 0; i < sz; i++) {
                for (int j = 0; j < sz; j++) {
                    float s = 0;
                    for (int k = 0; k < sz; k++) s += A[i][k] * B[k][j];
                    C[i][j] = s;
                }
            }
            sink += C[r % sz][r % sz];
        }
        if (sink == 123456.789) System.out.print("");
        return n * (double) sz * sz * sz;
    }

    private static double wNBody(int n) {           // N 体：开方 + 乘加
        int bodies = 40;
        double[] x = new double[bodies], y = new double[bodies], z = new double[bodies];
        for (int i = 0; i < bodies; i++) { x[i] = i * 0.1; y[i] = i * -0.07; z[i] = i * 0.03; }
        double sink = 0;
        for (int r = 0; r < n; r++) {
            for (int i = 0; i < bodies; i++) {
                for (int j = i + 1; j < bodies; j++) {
                    double dx = x[i] - x[j], dy = y[i] - y[j], dz = z[i] - z[j];
                    double d2 = dx * dx + dy * dy + dz * dz + 1e-9;
                    double inv = 1.0 / Math.sqrt(d2);
                    x[i] += dx * inv * 1e-3;
                    y[j] += dy * inv * 1e-3;
                    z[i] += dz * inv * 1e-3;
                }
            }
            sink += x[r % bodies];
        }
        if (sink == 123456.789) System.out.print("");
        return (double) n * bodies * bodies * 6;
    }

    private static double wStreamLarge(int n) {     // 大数组 triad（DRAM 级）
        int len = 512 * 1024;                        // 2MB float/线程，越过缓存
        float[] a = new float[len], b = new float[len], c = new float[len];
        for (int i = 0; i < len; i++) { a[i] = i * 0.001f; b[i] = i * 0.0005f; c[i] = 1.0f; }
        double sink = 0;
        float s = 1.0001f;
        for (int r = 0; r < n; r++) {
            for (int i = 0; i < len; i++) b[i] = a[i] + s * c[i];
            sink += b[(r * 97) % len];
        }
        if (sink == 123456.789) System.out.print("");
        return (double) n * len * 8;
    }

    private static double wStream(int n) {          // 内存 triad
        int len = 16384;
        float[] a = new float[len], b = new float[len], c = new float[len];
        for (int i = 0; i < len; i++) { a[i] = i; b[i] = i * 0.5f; c[i] = 0; }
        double sink = 0;
        float s = 1.0001f;
        for (int r = 0; r < n; r++) {
            for (int i = 0; i < len; i++) a[i] = b[i] + s * c[i];
            sink += a[(r * 37) % len];
        }
        if (sink == 123456.789) System.out.print("");
        return (double) n * len * 8;                 // 每次读写约 8 字节
    }

    // ---------- 计时 ----------
    private interface Job { double run(int iters); }

    /** 本轮波动（(max-min)/median），供稳定性判断。 */
    public static double spread = 0;

    /** 按时间跑满 durationMs，返回「单位/秒」（5 轮取中位数）。 */
    private static int curRounds = 5;
    private static int lastRounds = 5;

    private static double rate(Job job, int durationMs) {
        job.run(2000);                                        // 预热
        double[] v = new double[Math.max(3, curRounds)];
        for (int i = 0; i < v.length; i++) {
            long t0 = System.nanoTime();
            long deadline = t0 + durationMs * 1000000L;
            double units = 0;
            int n = 4000;
            while (System.nanoTime() < deadline) {
                units += job.run(n);
            }
            long dt = System.nanoTime() - t0;
            v[i] = dt <= 0 ? 0 : units * 1.0e9 / dt;
        }
        Arrays.sort(v);
        double med = v[v.length / 2];
        if (med > 0) {
            double sp = (v[v.length - 1] - v[0]) / med;
            if (sp > spread) spread = sp;                     // 取最不稳定那一项
        }
        return med;
    }

    public interface Progress { void onProgress(int pct, String label); }
    private static Progress progress;

    public static void setProgress(Progress p) { progress = p; }

    private static void report(int pct, String label) {
        if (progress != null) progress.onProgress(pct, label);
    }

    public static Result measure(boolean multi) { return measure(multi, 150, 5); }

    public static Result measure(boolean multi, int durationMs, int rounds) {
        lastRounds = rounds;
        Result r = new Result();
        int threads = multi ? Runtime.getRuntime().availableProcessors() : 1;
        Log.i("CPUHUD", "bench start multi=" + multi + " threads=" + threads);

        spread = 0;
        String tag = multi ? "多核" : "单核";
        report(multi ? 50 : 5, tag + " 整数…");
        r.intRate = parallel(threads, new Job[]{Bench::wCompress, Bench::wCrypto, Bench::wHash}, durationMs, rounds);
        report(multi ? 70 : 35, tag + " 浮点…");
        r.fpRate = parallel(threads, new Job[]{Bench::wMatrix, Bench::wNBody}, durationMs, rounds);
        report(multi ? 88 : 60, tag + " 内存…");
        r.memRate = parallel(threads, new Job[]{Bench::wStream, Bench::wStreamLarge}, durationMs, rounds);
        report(multi ? 98 : 72, tag + " 完成");

        // 归一化（参考值按本机标定，量级参照 GB6）
        // 标定：让本机单核总分落在 2000~3000（GB6 量级），多核 ~4.5 倍
        r.intScore = r.intRate * 1.925e-6;
        r.fpScore = r.fpRate * 2.4e-6;
        r.memScore = r.memRate * 2.96e-8;
        r.single = Math.pow(r.intScore, 0.5) * Math.pow(r.fpScore, 0.3) * Math.pow(r.memScore, 0.2);
        r.spread = spread;
        Log.i("CPUHUD", String.format(java.util.Locale.US,
                "bench rates int=%.0f fp=%.0f mem=%.0f -> scores %.0f/%.0f/%.0f total=%.0f",
                r.intRate, r.fpRate, r.memRate, r.intScore, r.fpScore, r.memScore, r.single));
        return r;
    }

    /** 多线程跑同一组负载，返回总速率。 */
    private static double parallel(int threads, Job[] jobs, int iters, int rounds) {
        curRounds = rounds;
        if (threads <= 1) {
            double sum = 0;
            for (Job j : jobs) sum += rate(j, iters);
            sum /= jobs.length;
            return sum;
        }
        final double[] part = new double[threads];
        Thread[] ts = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            final int idx = t;
            ts[t] = new Thread(new Runnable() {
                @Override public void run() {
                    double sum = 0;
                    for (Job j : jobs) sum += rate(j, iters);
                    part[idx] = sum / jobs.length;
                }
            });
        }
        for (Thread t : ts) t.start();
        for (Thread t : ts) { try { t.join(); } catch (InterruptedException ignored) { } }
        double sum = 0;
        for (double v : part) sum += v;
        return sum;
    }
}
