package com.dsh.cpuhud;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.os.BatteryManager;
import android.os.Build;
import android.view.Display;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 基础模式：完全不用 Shizuku / root，只用系统公开 API。
 * 能拿到：电量、电池温度/电压/电流、充电状态、内存、刷新率；
 * 另外尽力直接读 /sys（部分机型对应用开放）拿 CPU 温度和各簇频率，读不到就留空。
 * 拿不到：整机帧率（需要 SurfaceFlinger）、GPU/SOC 温度。
 */
public class BasicSampler {
    private final long[] prevFps = new long[0];
    private long lastSysRead = 0;
    private long prevChargeUah = -1;
    private long prevChargeTs = 0;
    private double chargeDerivedMa = 0;
    private final float[] histFps = new float[90];
    private final float[] histW = new float[90];
    private int histLen = 0, histPos = 0;

    /** 用系统 API 补齐 Shizuku 采样缺失的电压/电流/温度（高通机型常见）。 */
    public static void fillPower(Context ctx, Snapshot s) {
        if (ctx == null || s == null) return;
        try {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            Intent st = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (st != null) {
                if (s.battLevel <= 0) {
                    int lv = st.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    if (lv > 0) s.battLevel = lv;
                }
                if (s.battTemp <= 0) {
                    int t = st.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                    if (t > 0) s.battTemp = t / 10.0;
                }
                if (s.voltV <= 0) {
                    int v = st.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                    if (v > 0) s.voltV = Math.round(v / 1000.0 * 1000) / 1000.0;
                }
                int status = st.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                s.charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
                s.powerCharging = s.charging;
            }
            // 合理性校验：电压必须是 3~5.5V，否则说明 sysfs 单位不对，用框架值覆盖
            if (s.voltV > 0 && (s.voltV < 3.0 || s.voltV > 5.5) && st != null) {
                int v = st.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                if (v > 3000 && v < 5500) s.voltV = Math.round(v / 1000.0 * 1000) / 1000.0;
            }
            if (s.battTemp > 0 && (s.battTemp < 0 || s.battTemp > 70)) s.battTemp = -1;
            if (s.currentMa == 0 && bm != null) {
                long cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                if (cur != 0 && cur != Long.MIN_VALUE) {
                    double ma = Math.abs(cur) > 20000 ? Math.abs(cur) / 1000.0 : Math.abs(cur);
                    s.currentMa = s.charging ? ma : -ma;
                    if (s.powerW == 0 && s.voltV > 0) {
                        s.powerW = Math.round(s.voltV * ma / 1000.0 * 100) / 100.0;
                    }
                }
            }
        } catch (Throwable ignored) { }
    }

    public Snapshot sample(Context ctx) {
        Snapshot s = new Snapshot();
        s.ts = System.currentTimeMillis();

        BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
        Intent st = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int level = -1, tempTenth = -1, voltMv = -1, status = -1;
        if (st != null) {
            level = st.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            tempTenth = st.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            voltMv = st.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            status = st.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        }
        s.battLevel = level;
        s.battTemp = tempTenth > 0 ? tempTenth / 10.0 : -1;
        s.voltV = voltMv > 0 ? Math.round(voltMv / 1000.0 * 1000) / 1000.0 : -1;
        s.charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        s.powerCharging = s.charging;

        double ma = 0;
        if (bm != null && Build.VERSION.SDK_INT >= 21) {
            long cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (cur != 0 && cur != Long.MIN_VALUE) {
                ma = Math.abs(cur) > 20000 ? Math.abs(cur) / 1000.0 : Math.abs(cur);   // µA → mA
            }
            long counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER); // µAh
            long now = System.currentTimeMillis();
            if (counter > 0 && prevChargeUah > 0 && now > prevChargeTs) {
                double dh = (now - prevChargeTs) / 3600000.0;
                double dUah = Math.abs(counter - prevChargeUah);
                double derived = dUah / 1000.0 / dh;             // mA
                chargeDerivedMa = chargeDerivedMa == 0 ? derived : chargeDerivedMa * 0.7 + derived * 0.3;
            }
            if (counter > 0) { prevChargeUah = counter; prevChargeTs = now; }
            if (ma == 0 && chargeDerivedMa > 0 && chargeDerivedMa < 5000) ma = chargeDerivedMa;
        }
        s.currentMa = s.charging ? ma : -ma;
        s.powerW = s.voltV > 0 && ma > 0 ? Math.round(s.voltV * s.currentMa / 1000.0 * 100) / 100.0 : 0;

        // 内存
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            s.memTotal = Math.round(mi.totalMem / 1073741824.0 * 10) / 10.0;
            s.memUsed = Math.round((mi.totalMem - mi.availMem) / 1073741824.0 * 10) / 10.0;
            s.memPct = mi.totalMem > 0 ? Math.round((mi.totalMem - mi.availMem) * 1000.0 / mi.totalMem) / 10.0 : 0;
        } catch (Throwable ignored) { }

        // 刷新率
        try {
            DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
            Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
            if (d != null) {
                float r = d.getRefreshRate();
                s.dispRate = r > 0 ? Math.round(r) : 0;
            }
        } catch (Throwable ignored) { }

        // 尽力读 /sys（部分机型允许）
        long now = System.currentTimeMillis();
        if (now - lastSysRead > 5000) {
            lastSysRead = now;
            readSysfs(s);
        } else {
            s.cpu = lastCpu; s.gpu = lastGpu; s.soc = lastSoc; s.skin = lastSkin;
            s.cores = lastCores; s.cur = lastCur; s.max = lastMax;
        }

        s.fps = -1;          // 没有 SurfaceFlinger 拿不到整机帧率
        s.fpsFt = 0;
        s.thermalStatus = 0;
        s.thermalLabel = "";
        histFps[histPos] = 0; histW[histPos] = (float) s.powerW;
        histPos = (histPos + 1) % histFps.length;
        histLen = Math.min(histLen + 1, histFps.length);
        s.histFps = ordered(histFps, histLen, histPos);
        s.histW = ordered(histW, histLen, histPos);
        return s;
    }

    private static float[] ordered(float[] a, int len, int pos) {
        float[] out = new float[len];
        for (int i = 0; i < len; i++) out[i] = a[(pos - len + i + a.length * 2) % a.length];
        return out;
    }

    private double lastCpu = -1, lastGpu = -1, lastSoc = -1, lastSkin = -1;
    private String[] lastCores = new String[0];
    private double[] lastCur = new double[0], lastMax = new double[0];

    private void readSysfs(Snapshot s) {
        // 温度
        try {
            File dir = new File("/sys/class/thermal");
            File[] zones = dir.listFiles();
            if (zones != null) {
                for (File z : zones) {
                    if (!z.getName().startsWith("thermal_zone")) continue;
                    String type = read(z.getPath() + "/type");
                    double v = parseDouble(read(z.getPath() + "/temp"));
                    if (type == null || v == Double.NaN) continue;
                    if (v > 1000) v = v / 1000.0;
                    if (v <= -20 || v >= 200) continue;
                    String t = type.toLowerCase();
                    if (t.contains("cpu") && lastCpu < 0) lastCpu = v;
                    else if (t.contains("gpu") && lastGpu < 0) lastGpu = v;
                    else if (t.contains("soc") && lastSoc < 0) lastSoc = v;
                    else if (t.contains("skin") && lastSkin < 0) lastSkin = v;
                }
            }
        } catch (Throwable ignored) { }
        s.cpu = lastCpu;
        s.gpu = lastGpu;
        s.soc = lastSoc;
        s.skin = lastSkin;

        // 频率
        try {
            List<String> cores = new ArrayList<>();
            List<Double> curs = new ArrayList<>(), maxs = new ArrayList<>();
            for (int i = 0; i < 16; i++) {
                String base = "/sys/devices/system/cpu/cpu" + i + "/cpufreq";
                double cur = parseDouble(read(base + "/scaling_cur_freq"));
                double max = parseDouble(read(base + "/cpuinfo_max_freq"));
                if (cur > 0) {
                    cores.add(String.valueOf(i));
                    curs.add(cur / 1000.0);
                    maxs.add(max > 0 ? max / 1000.0 : 0);
                }
            }
            if (!cores.isEmpty()) {
                lastCores = cores.toArray(new String[0]);
                lastCur = new double[curs.size()];
                lastMax = new double[maxs.size()];
                for (int i = 0; i < curs.size(); i++) { lastCur[i] = curs.get(i); lastMax[i] = maxs.get(i); }
                double mx = 0, sum = 0;
                for (double v : lastCur) { mx = Math.max(mx, v); sum += v; }
                s.freqMax = mx;
                s.freqAvg = sum / lastCur.length;
            }
        } catch (Throwable ignored) { }
        s.cores = lastCores; s.cur = lastCur; s.max = lastMax;
    }

    private static String read(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return r.readLine();
        } catch (Throwable t) {
            return null;
        }
    }

    private static double parseDouble(String s) {
        if (s == null) return Double.NaN;
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return Double.NaN; }
    }
}
