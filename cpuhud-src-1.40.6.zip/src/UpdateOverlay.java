package com.dsh.cpuhud;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * 更新进度「悬浮窗」：下载/检查时浮在屏幕上，能看见百分比；
 * 下载完成后变成「点此安装」，点了就拉起系统安装器。
 */
public final class UpdateOverlay {

    private final Context ctx;
    private WindowManager wm;
    private LinearLayout card;
    private TextView title, sub;
    private ProgressBar bar;
    private Runnable onTap;

    public UpdateOverlay(Context c) {
        this.ctx = c;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.getResources().getDisplayMetrics());
    }

    private boolean ensure() {
        if (card != null) return true;
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(ctx)) return false;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE121A22);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFF2FD07A);
        card.setBackground(bg);

        title = new TextView(ctx);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(title);

        sub = new TextView(ctx);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        sub.setTextColor(0xFF8FA3B8);
        sub.setPadding(0, dp(2), 0, dp(6));
        card.addView(sub);

        bar = new ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        card.addView(bar, new LinearLayout.LayoutParams(dp(190), dp(6)));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(12);
        lp.y = dp(90);
        try {
            wm.addView(card, lp);
        } catch (Throwable t) {
            card = null;
            return false;
        }
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (onTap != null) onTap.run();
            }
        });
        return true;
    }

    /** 显示「进行中」状态。pct < 0 表示不确定进度。 */
    public void progress(String t, String s, int pct) {
        if (!ensure()) return;
        title.setText(t);
        sub.setText(s);
        bar.setVisibility(pct < 0 ? View.GONE : View.VISIBLE);
        if (pct >= 0) bar.setProgress(pct);
        onTap = null;
        card.setClickable(false);
    }

    /** 显示「就绪」状态，点一下执行 tap。 */
    public void ready(String t, String s, Runnable tap) {
        if (!ensure()) return;
        title.setText(t);
        sub.setText(s);
        bar.setVisibility(View.GONE);
        onTap = tap;
        card.setClickable(true);
    }

    public void error(String msg) {
        if (!ensure()) return;
        title.setText("更新失败");
        sub.setText(msg);
        bar.setVisibility(View.GONE);
        onTap = new Runnable() {
            @Override public void run() { hide(); }
        };
        card.setClickable(true);
    }

    public void hide() {
        if (card == null || wm == null) return;
        try { wm.removeView(card); } catch (Throwable ignored) { }
        card = null;
        onTap = null;
    }
}
