package com.dsh.cpuhud;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** CPU-Z 风格的硬件信息页。 */
public class HardwareActivity extends Activity {
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private TextView hint;
    private ChipCard gpuCard;
    private ChipArt hero;
    private TextView benchText;
    private LinearLayout content;
    private String heroSoc = "";
    private double benchSingle = 0, benchMulti = 0;
    private Bench.Result benchR;
    private double benchTemp = -1, benchGhz = -1, benchGhzCap = 0;
    private boolean benchThrottled = false;
    private boolean downloading = false;
    private boolean benchRunning = false;
    private boolean benchStrict = false;
    private volatile int benchPct = 0;
    private volatile String benchStage = "";
    private java.util.List<float[]> benchCurve;
    private android.widget.ProgressBar progressBar;
    private TextView progressText;
    private int themeSig;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();
        benchStrict = getSharedPreferences("hud", MODE_PRIVATE).getBoolean("benchStrict", false);
        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(30));

        TextView title = new TextView(this);
        title.setText("硬件信息");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        title.setTextColor(Theme.strong());
        root.addView(title);

        hero = new ChipArt(this);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(132));
        hp.bottomMargin = dp(8);
        root.addView(hero, hp);
        hero.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { showImageMenu(); return true; }
        });
        hero.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String soc = heroSoc == null ? "" : heroSoc;
                String url = ChipCard.socUrl(soc);
                if (url.isEmpty()) return;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
                } catch (Throwable ignored) { }
            }
        });

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.bottomMargin = dp(8);

        gpuCard = new ChipCard(this, Theme.hot(), true);
        root.addView(gpuCard, cp);

        hint = new TextView(this);
        hint.setText("读取中…");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        hint.setTextColor(Theme.dim2());
        hint.setPadding(0, dp(4), 0, dp(10));
        root.addView(hint);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content);

        Button back = new Button(this);
        back.setText("返回");
        back.setAllCaps(false);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        back.setTextColor(Theme.text());
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(Theme.card());
        bgd.setCornerRadius(dp(12));
        back.setBackground(bgd);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42));
        blp.topMargin = dp(16);
        root.addView(back, blp);

        sc.addView(root);
        setContentView(sc);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); return; }
        ui.postDelayed(new Runnable() {
            @Override public void run() { refresh(); }
        }, 600);
    }

    /** 长按：相册 / 内置列表 / 联网。 */
    private void showImageMenu() {
        final String[] items = {"从相册选择", "从内置芯片列表选择（" + ChipArt.BUILTIN.length + " 款）",
                "从图片链接获取",
                ChipArt.isDrawMode(this) ? "自绘芯片图：已启用（点击恢复自动）" : "改用自绘芯片图（不加载图片）",
                "恢复默认芯片图（清掉自定义）"};
        new android.app.AlertDialog.Builder(this)
                .setTitle("更换芯片图")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) pickChipImage();
                        else if (which == 1) showBuiltinPicker();
                        else if (which == 2) chipImageFromUrl();
                        else if (which == 3) {
                            boolean on = !ChipArt.isDrawMode(HardwareActivity.this);
                            ChipArt.setDrawMode(HardwareActivity.this, on);
                            if (on) {                                  // 自绘时清掉其它覆盖
                                getSharedPreferences("chipdl", MODE_PRIVATE).edit()
                                        .putString("localKey", "").putString("localName", "").apply();
                            }
                            ChipArt.clearRenderCache();
                            refresh();
                        } else {
                            resetChipImage();
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showBuiltinPicker() {
        String[] names = new String[ChipArt.BUILTIN.length + 1];
        names[0] = "自动识别（推荐）";
        for (int i = 0; i < ChipArt.BUILTIN.length; i++) names[i + 1] = ChipArt.BUILTIN[i][0];
        new android.app.AlertDialog.Builder(this)
                .setTitle("选择芯片")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        String key = which == 0 ? "" : ChipArt.BUILTIN[which - 1][1];
                        String name = which == 0 ? "" : ChipArt.BUILTIN[which - 1][0];
                        getSharedPreferences("chipdl", MODE_PRIVATE).edit()
                                .putString("localKey", key).putString("localName", name).apply();
                        ChipArt.setLocal(key);
                        refresh();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 清掉所有自定义 / 缓存图，回到「按型号自动匹配」。 */
    private void resetChipImage() {
        try {
            new File(getFilesDir(), "chip_custom.png").delete();
            File[] fs = getFilesDir().listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName();
                    if (n.startsWith("chip_remote_") || n.startsWith("chip_custom_tmp")) f.delete();
                }
            }
            getSharedPreferences("chipdl", MODE_PRIVATE).edit()
                    .putString("localKey", "").putString("localName", "").apply();
            ChipArt.clearRenderCache();
            android.widget.Toast.makeText(this, "已恢复默认（按型号自动匹配）",
                    android.widget.Toast.LENGTH_SHORT).show();
            refresh();
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "清除失败：" + t.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    /** 长按芯片图 → 从相册选一张存成自定义芯片图。 */
    private void pickChipImage() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "选择芯片图片"), 7001);
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "没有可用的文件选择器", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 7001 || res != RESULT_OK || data == null || data.getData() == null) return;
        java.io.InputStream in = null;
        try {
            android.net.Uri uri = data.getData();
            try {
                in = getContentResolver().openInputStream(uri);
            } catch (Throwable t1) {
                android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
                if (pfd != null) in = new java.io.FileInputStream(pfd.getFileDescriptor());
            }
            if (in == null) throw new java.io.IOException("打不开这个文件");
            Bitmap bm = BitmapFactory.decodeStream(in);
            if (bm == null) throw new java.io.IOException("不是有效图片");

            float scale = Math.min(1f, 640f / Math.max(bm.getWidth(), 1));
            if (scale < 1f) bm = Bitmap.createScaledBitmap(bm, (int) (bm.getWidth() * scale), (int) (bm.getHeight() * scale), true);

            saveCustomBitmap(bm);
        } catch (Throwable t) {
            android.util.Log.e("CPUHUD", "custom chip image failed: " + t);
            android.widget.Toast.makeText(this, "换图失败：" + t.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
        }
    }

    /** 把一张图存成当前这台机器的自定义芯片图。 */
    private void saveCustomBitmap(Bitmap bm) throws java.io.IOException {
        // 先写临时文件再替换，避免写一半导致图坏掉
        File tmp = new File(getFilesDir(), "chip_custom_tmp.png");
        File dst = new File(getFilesDir(), "chip_custom.png");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            if (!bm.compress(Bitmap.CompressFormat.PNG, 92, out)) throw new java.io.IOException("编码失败");
        }
        if (dst.exists() && !dst.delete()) { /* 忽略，后面 rename 会覆盖 */ }
        if (!tmp.renameTo(dst)) {
            // rename 失败就退回逐字节复制
            try (FileOutputStream out = new FileOutputStream(dst);
                 java.io.FileInputStream fin = new java.io.FileInputStream(tmp)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = fin.read(buf)) > 0) out.write(buf, 0, n);
            }
            tmp.delete();
        }
        ChipArt.clearRenderCache();
        android.util.Log.i("CPUHUD", "custom chip image saved " + bm.getWidth() + "x" + bm.getHeight());
        android.widget.Toast.makeText(this, "已换成你的芯片图（长按可再换）", android.widget.Toast.LENGTH_SHORT).show();
        refresh();
    }

    /**
     * 从任意图片链接取图。
     * 比「抓厂商官网」可靠得多：官网的页面结构会变，链接不会 —— 你在浏览器里看到的图长按复制地址，
     * 粘进来就行，不管它来自官网、图床还是贴吧。
     */
    private void chipImageFromUrl() {
        final android.widget.EditText et = new android.widget.EditText(this);
        et.setHint("https://…/chip.png");
        et.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f);
        new android.app.AlertDialog.Builder(this)
                .setTitle("从图片链接获取")
                .setMessage("粘贴图片地址（长按图片 → 复制图片地址）。下载后存成你的芯片图，之后一直用它。")
                .setView(et)
                .setPositiveButton("下载", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String u = et.getText().toString().trim();
                        if (u.isEmpty()) return;
                        fetchRemoteImage(u);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void fetchRemoteImage(final String url) {
        android.widget.Toast.makeText(this, "正在下载…", android.widget.Toast.LENGTH_SHORT).show();
        bg.execute(new Runnable() {
            @Override public void run() {
                Bitmap bm = null;
                String err = null;
                java.net.HttpURLConnection conn = null;
                try {
                    conn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(10000);
                    conn.setInstanceFollowRedirects(true);
                    conn.setRequestProperty("User-Agent",
                            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
                    int code = conn.getResponseCode();
                    if (code / 100 != 2) throw new java.io.IOException("HTTP " + code);
                    java.io.InputStream in = conn.getInputStream();

                    // 先量尺寸再按需降采样，避免大图把内存打爆
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        bo.write(buf, 0, n);
                        if (bo.size() > 8 * 1024 * 1024) throw new java.io.IOException("图片太大");
                    }
                    in.close();
                    byte[] data = bo.toByteArray();
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    if (o.outWidth <= 0) throw new java.io.IOException("不是有效图片");
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    int scale = 1;
                    while (o.outWidth / (scale * 2) >= 640) scale *= 2;
                    o2.inSampleSize = scale;
                    bm = BitmapFactory.decodeByteArray(data, 0, data.length, o2);
                    if (bm == null) throw new java.io.IOException("解码失败");
                } catch (Throwable t) {
                    err = t.getMessage();
                } finally {
                    if (conn != null) try { conn.disconnect(); } catch (Throwable ignored2) { }
                }
                final Bitmap out = bm;
                final String e = err;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (out == null) {
                            android.widget.Toast.makeText(HardwareActivity.this,
                                    "下载失败：" + e, android.widget.Toast.LENGTH_LONG).show();
                            return;
                        }
                        try {
                            saveCustomBitmap(out);
                        } catch (Throwable t) {
                            android.widget.Toast.makeText(HardwareActivity.this,
                                    "保存失败：" + t.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private void refresh() {
        bg.execute(new Runnable() {
            @Override public void run() {
                final Map<String, List<String[]>> data = HwInfo.collect(HardwareActivity.this);
                ui.post(new Runnable() {
                    @Override public void run() { render(data); }
                });
            }
        });
    }

    /** 从「各核最大频率」文本里取最大值（GHz），用于区分 9300/9300+。 */
    private static float maxFreqFrom(Map<String, List<String[]>> data) {
        String t = pick(data, "处理器", "各核最大频率");
        float mx = 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)G").matcher(t);
        while (m.find()) {
            try { mx = Math.max(mx, Float.parseFloat(m.group(1))); } catch (Exception ignored) { }
        }
        return mx;
    }

    private static String pick(Map<String, List<String[]>> data, String section, String label) {
        List<String[]> rows = data.get(section);
        if (rows == null) return "—";
        for (String[] kv : rows) if (label.equals(kv[0])) return kv[1];
        return "—";
    }

    private Map<String, List<String[]>> lastData;

    private void render(Map<String, List<String[]>> data) {
        lastData = data;
        content.removeAllViews();
        String soc = pick(data, "处理器", "SoC");
        String cores = pick(data, "处理器", "核心数");
        String gov = pick(data, "处理器", "调速器");
        heroSoc = soc;
        int coreCount = 0;
        try { coreCount = Integer.parseInt(cores); } catch (Exception ignored) { }
        hero.setMaxGhz(maxFreqFrom(data));
        hero.bind(soc, pick(data, "图形", "GPU"), coreCount);

        String gpu = pick(data, "图形", "GPU");
        String gles = pick(data, "图形", "OpenGL ES");
        String gv = pick(data, "图形", "厂商");
        gpuCard.bind(gpu, gv + " · " + gles, ChipCard.gpuUrl(gpu));

        String localKey = getSharedPreferences("chipdl", MODE_PRIVATE).getString("localKey", "");
        String manualNote = "";
        if (localKey != null && !localKey.isEmpty()) {
            manualNote = "手动指定芯片图：" + localKey + "（长按可改回自动） · ";
        }
        hint.setText(manualNote + "长按上方芯片图可换成自己的图 · 数据源：Shizuku" + (ShizukuShell.granted() ? " 已授权" : " 未授权（/sys 项可能读不到）")
                + " · 拉取时间 " + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                .format(new java.util.Date()));

        for (Map.Entry<String, List<String[]>> e : data.entrySet()) {
            TextView h = new TextView(this);
            h.setText(e.getKey());
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
            h.setTextColor(Theme.good());
            h.setPadding(0, dp(12), 0, dp(4));
            content.addView(h);

            for (String[] kv : e.getValue()) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, dp(3), 0, dp(3));

                TextView k = new TextView(this);
                k.setText(kv[0]);
                k.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                k.setTextColor(Theme.dim());
                k.setSingleLine(false);
                row.addView(k, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.38f));

                TextView v = new TextView(this);
                v.setText(kv[1]);
                v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                v.setTextColor(Theme.text());
                v.setGravity(Gravity.END);
                row.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.62f));
                content.addView(row);
            }
        }

        // ---------- 跑分 ----------
        TextView bh = new TextView(this);
        bh.setText("跑分");
        bh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        bh.setTextColor(Theme.good());
        bh.setPadding(0, dp(14), 0, dp(4));
        content.addView(bh);

        if (benchRunning) {
            progressBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setMax(100);
            progressBar.setProgress(benchPct);
            content.addView(progressBar, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(8)));
            progressText = new TextView(this);
            progressText.setText(benchPct + "% · " + benchStage);
            progressText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            progressText.setTextColor(Theme.dim());
            progressText.setPadding(0, dp(2), 0, dp(6));
            content.addView(progressText);
        } else {
            progressBar = null;
            progressText = null;
        }

        content.addView(kvRow("单核总分", benchRunning ? "跑分中…"
                : benchSingle > 0 ? String.format(java.util.Locale.US, "%.0f", benchSingle) : "未测试"));
        content.addView(kvRow("多核总分", benchRunning ? "跑分中…"
                : benchMulti > 0 ? String.format(java.util.Locale.US, "%.0f", benchMulti) : "未测试"));
        content.addView(kvRow("加速比", benchMulti > 0 && benchSingle > 0
                ? String.format(java.util.Locale.US, "%.2f×", benchMulti / benchSingle) : "—"));
        if (benchR != null) {
            content.addView(kvRow("　整数子项", String.format(java.util.Locale.US, "%.0f", benchR.intScore)));
            content.addView(kvRow("　浮点子项", String.format(java.util.Locale.US, "%.0f", benchR.fpScore)));
            content.addView(kvRow("　内存子项", String.format(java.util.Locale.US, "%.0f", benchR.memScore)));
        }
        if (benchR != null && benchR.spread > 0) {
            double sp = benchR.spread * 100;
            content.addView(kvRow("本次波动", String.format(java.util.Locale.US, "%.1f%%", sp)
                    + (sp > 8 ? "（偏大，建议重跑）" : "")));
        }
        if (!benchRunning && benchTemp > 0) {
            content.addView(kvRow("跑分时温度", String.format(java.util.Locale.US, "%.1f °C", benchTemp)));
            content.addView(kvRow("最高频率", String.format(java.util.Locale.US, "%.2f GHz", benchGhz)));
            content.addView(kvRow("是否降频", benchThrottled
                    ? String.format(java.util.Locale.US, "是（只到峰值的 %.0f%%）",
                        benchGhzCap > 0 ? benchGhz / benchGhzCap * 100 : 0)
                    : "否"));
        }

        // 历史趋势
        java.util.List<float[]> hist = loadBenchHistory();
        if (hist.size() >= 2) {
            TextView th = new TextView(this);
            th.setText("历史趋势（" + hist.size() + " 次 · 青=单核 橙=多核）");
            th.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            th.setTextColor(Theme.dim());
            th.setPadding(0, dp(10), 0, dp(2));
            content.addView(th);
            TrendChart chart = new TrendChart(this);
            chart.setData(hist, Theme.accent());
            LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(86));
            content.addView(chart, chp);
        }

        TextView note = new TextView(this);
        note.setText("子项：整数（压缩/加密/哈希）、浮点（矩阵/N体）、内存（STREAM triad）。每项预热+三轮取中位数，按参考值归一化。\n量级参照 Geekbench 6，但 Workload 与标定完全不同，分数不可直接对比。");
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        note.setTextColor(Theme.dim2());
        note.setPadding(0, dp(4), 0, dp(6));
        content.addView(note);

        // 从图片链接换芯片图
        Button dl = new Button(this);
        dl.setText("从图片链接换芯片图");
        dl.setAllCaps(false);
        dl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        dl.setTextColor(Theme.accent());
        GradientDrawable bgd3 = new GradientDrawable();
        bgd3.setColor(Theme.card2());
        bgd3.setCornerRadius(dp(12));
        dl.setBackground(bgd3);
        dl.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { chipImageFromUrl(); }
        });
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42));
        dlp.topMargin = dp(10);
        content.addView(dl, dlp);

        // 严格模式开关
        Button strict = new Button(this);
        strict.setText(benchStrict ? "严格模式：开（7 轮 × 500ms，约 40 秒）" : "严格模式：关（5 轮 × 150ms，约 15 秒）");
        strict.setAllCaps(false);
        strict.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        strict.setTextColor(Theme.accent());
        GradientDrawable bgdS = new GradientDrawable();
        bgdS.setColor(Theme.card2());
        bgdS.setCornerRadius(dp(12));
        strict.setBackground(bgdS);
        strict.setEnabled(!benchRunning);
        strict.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // 只切一个开关，没必要重新采集整机数据（那要 1~2 秒，手感像卡住）
                benchStrict = !benchStrict;
                strict.setText(benchStrict
                        ? "严格模式：开（7 轮 × 500ms，约 40 秒）"
                        : "严格模式：关（5 轮 × 150ms，约 15 秒）");
                getSharedPreferences("hud", MODE_PRIVATE).edit()
                        .putBoolean("benchStrict", benchStrict).apply();
            }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        slp.topMargin = dp(8);
        content.addView(strict, slp);

        // 跑分过程曲线
        if (benchCurve != null && benchCurve.size() >= 2) {
            TextView ch = new TextView(this);
            ch.setText("跑分过程（" + benchCurve.size() + " 个采样 · 青=温度 橙=频率）");
            ch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            ch.setTextColor(Theme.dim());
            ch.setPadding(0, dp(10), 0, dp(2));
            content.addView(ch);
            TrendChart rc = new TrendChart(this);
            java.util.List<float[]> pts = new java.util.ArrayList<>();
            for (float[] p2 : benchCurve) if (p2[1] > 0) pts.add(new float[]{p2[1], p2[2] * 20f});
            if (pts.size() >= 2) {
                rc.setData(pts, Theme.accent());
                content.addView(rc, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(80)));
            }
        }

        Button run = new Button(this);
        run.setText(benchRunning ? "跑分中…" : "开始跑分");
        run.setAllCaps(false);
        run.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        run.setTextColor(Theme.text());
        GradientDrawable bgd2 = new GradientDrawable();
        bgd2.setColor(Theme.card());
        bgd2.setCornerRadius(dp(12));
        run.setBackground(bgd2);
        run.setEnabled(!benchRunning);
        run.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { runBench(); }
        });
        content.addView(run, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));
    }

    private LinearLayout kvRow(String k, String v) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(3), 0, dp(3));
        TextView kt = new TextView(this);
        kt.setText(k);
        kt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        kt.setTextColor(Theme.dim());
        row.addView(kt, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.38f));
        TextView vt = new TextView(this);
        vt.setText(v);
        vt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        vt.setTextColor(Theme.text());
        vt.setGravity(Gravity.END);
        row.addView(vt, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.62f));
        return row;
    }

    private void runBench() {
        if (benchRunning) return;
        benchRunning = true;
        benchPct = 0;
        benchStage = "冷却中（2 秒）";
        render(lastData == null ? new java.util.LinkedHashMap<String, java.util.List<String[]>>() : lastData);
        bg.execute(new Runnable() {
            @Override public void run() {
                // 1) 静置冷却，避免上一轮余热影响
                try { Thread.sleep(2000); } catch (InterruptedException ignored) { }
                updateProgress(2, "采样基线…");

                // 2) 开始采样（单进程流式，开销很小）
                RunSampler sampler = new RunSampler();
                sampler.start();

                double[] st = sampleState();
                double ghzCap = st[2];
                double tempPeak = st[0];

                int dur = benchStrict ? 500 : 150;
                int rounds = benchStrict ? 7 : 5;

                Bench.setProgress(new Bench.Progress() {
                    @Override public void onProgress(int pct, String label) { updateProgress(pct, label); }
                });

                // 3) 跑分
                updateProgress(5, "单核…");
                final Bench.Result single = Bench.measure(false, dur, rounds);
                double[] midState = sampleState();
                final Bench.Result multi = Bench.measure(true, dur, rounds);
                tempPeak = Math.max(tempPeak, midState[0]);

                double[] st2 = sampleState();
                sampler.stop();
                java.util.List<float[]> curve = sampler.data();
                float tempMax = sampler.maxTemp();
                tempPeak = Math.max(tempPeak, st2[0]);
                if (tempMax <= 0) tempMax = (float) tempPeak;       // 回落：HAL 快照温度
                float ghzMin = sampler.minGhz();
                float ghzMax = 0;
                for (float[] pt : curve) ghzMax = Math.max(ghzMax, pt[2]);

                benchCurve = curve;
                benchTemp = tempMax;
                benchGhz = ghzMax;
                benchGhzCap = ghzCap;
                benchThrottled = ghzCap > 0 && ghzMax > 0 && ghzMax < ghzCap * 0.85;
                saveBenchHistory(single.single, multi.single, tempMax, ghzMax);
                android.util.Log.i("CPUHUD", String.format(java.util.Locale.US,
                        "bench single=%.0f multi=%.0f temp=%.1f ghzMax=%.2f ghzMin=%.2f cap=%.2f samples=%d strict=%b",
                        single.single, multi.single, tempMax, ghzMax, ghzMin, ghzCap, curve.size(), benchStrict));

                ui.post(new Runnable() {
                    @Override public void run() {
                        benchSingle = single.single;
                        benchMulti = multi.single;
                        benchR = single;
                        benchRunning = false;
                        benchPct = 100;
                        benchStage = "";
                        refresh();
                    }
                });
            }
        });
    }

    private void updateProgress(final int pct, final String label) {
        benchPct = pct;
        benchStage = label;
        ui.post(new Runnable() {
            @Override public void run() {
                if (progressBar != null) progressBar.setProgress(pct);
                if (progressText != null) progressText.setText(pct + "% · " + label);
            }
        });
    }

    /** 返回 [CPU 温度, 当前最高频 GHz, 理论最高频 GHz]。 */
    private double[] sampleState() {
        double[] out = new double[]{-1, 0, 0};
        try {
            Snapshot snap = DataSource.fetch();
            if (snap == null) return out;
            // 温度过滤：温控 HAL 不可用时会返回 99.9 之类的哨兵值，只接受合理区间
            if (snap.cpu >= 15 && snap.cpu <= 95) out[0] = snap.cpu;
            for (double v : snap.cur) out[1] = Math.max(out[1], v / 1000.0);
            for (double v : snap.max) out[2] = Math.max(out[2], v / 1000.0);
        } catch (Throwable ignored) { }
        return out;
    }

    /** 存一条跑分历史（最多 20 条）：ts,single,multi,temp,ghz */
    private void saveBenchHistory(double single, double multi, double temp, double ghz) {
        try {
            String old = getSharedPreferences("chipdl", MODE_PRIVATE).getString("benchHist", "");
            StringBuilder sb = new StringBuilder();
            sb.append(System.currentTimeMillis()).append(',').append(Math.round(single)).append(',')
                    .append(Math.round(multi)).append(',').append(Math.round(temp * 10)).append(',')
                    .append(Math.round(ghz * 100));
            if (!old.isEmpty()) sb.append(';').append(old);
            String[] parts = sb.toString().split(";");
            StringBuilder keep = new StringBuilder();
            for (int i = 0; i < Math.min(parts.length, 20); i++) {
                if (keep.length() > 0) keep.append(';');
                keep.append(parts[i]);
            }
            getSharedPreferences("chipdl", MODE_PRIVATE).edit().putString("benchHist", keep.toString()).apply();
        } catch (Throwable ignored) { }
    }

    /** 读历史：[[single, multi], ...] 按时间正序 */
    private java.util.List<float[]> loadBenchHistory() {
        java.util.List<float[]> out = new java.util.ArrayList<>();
        try {
            String raw = getSharedPreferences("chipdl", MODE_PRIVATE).getString("benchHist", "");
            if (raw == null || raw.isEmpty()) return out;
            String[] parts = raw.split(";");
            for (int i = parts.length - 1; i >= 0; i--) {     // 存的是最新在前，反转成时间正序
                String[] f = parts[i].split(",");
                if (f.length >= 3) out.add(new float[]{Float.parseFloat(f[1]), Float.parseFloat(f[2])});
            }
        } catch (Throwable ignored) { }
        return out;
    }
}
