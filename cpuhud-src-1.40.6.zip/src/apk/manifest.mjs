// AndroidManifest 的 XML 树（由 axml.mjs 编译成二进制）
const A = (name, type, value) => ({ name, ns: 'android', type, value });

export const manifestRoot = {
  name: 'manifest',
  attrs: [
    { name: 'package', type: 'string', value: 'com.dsh.cpuhud' },
    A('versionCode', 'int', 118),
    A('versionName', 'string', '1.40.6'),
  ],
  children: [
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.INTERNET')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.SYSTEM_ALERT_WINDOW')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.FOREGROUND_SERVICE')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.ACCESS_WIFI_STATE')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.ACCESS_NETWORK_STATE')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.VIBRATE')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.MODIFY_AUDIO_SETTINGS')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.RECORD_AUDIO')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'android.permission.REQUEST_INSTALL_PACKAGES')] },
    { name: 'uses-permission', attrs: [A('name', 'string', 'moe.shizuku.manager.permission.API_V23')] },
    // 预测性返回的跨页面动画在 targetSdk 33+ 才完整
    { name: 'uses-sdk', attrs: [A('minSdkVersion', 'int', 26), A('targetSdkVersion', 'int', 33)] },
    {
      name: 'application',
      attrs: [
        A('label', 'string', 'CPU HUD'),
        A('allowBackup', 'bool', false),
        A('usesCleartextTraffic', 'bool', true),
        A('hardwareAccelerated', 'bool', true),
        A('enableOnBackInvokedCallback', 'bool', true),   // 交给系统的预测性返回（ColorOS 侧滑跟手动画靠它）
      ],
      children: [
        {
          name: 'activity',
          attrs: [A('name', 'string', '.MainActivity'), A('exported', 'bool', true), A('label', 'string', 'CPU HUD')],
          children: [{
            name: 'intent-filter',
            children: [
              { name: 'action', attrs: [A('name', 'string', 'android.intent.action.MAIN')] },
              { name: 'category', attrs: [A('name', 'string', 'android.intent.category.LAUNCHER')] },
            ],
          }],
        },
        { name: 'activity', attrs: [A('name', 'string', '.HudConfigActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 显示设置')] },
        { name: 'activity', attrs: [A('name', 'string', '.SysInfoActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 系统信息')] },
        { name: 'activity', attrs: [A('name', 'string', '.VersionActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 更新日志')] },
        { name: 'activity', attrs: [A('name', 'string', '.HardwareActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 硬件信息')] },
        { name: 'activity', attrs: [A('name', 'string', '.ThemeActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 配色')] },
        { name: 'activity', attrs: [A('name', 'string', '.MoreActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 更多设置')] },
        { name: 'activity', attrs: [A('name', 'string', '.DeviceInfoActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 设备信息')] },
        { name: 'activity', attrs: [A('name', 'string', '.SelfTestActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 设备自检')] },
        { name: 'activity', attrs: [A('name', 'string', '.ScreenTestActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 屏幕自检')] },
        { name: 'activity', attrs: [A('name', 'string', '.TouchTestActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 触摸自检')] },
        { name: 'activity', attrs: [A('name', 'string', '.SpeakerTestActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 扬声器自检')] },
        { name: 'activity', attrs: [A('name', 'string', '.SensorTestActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 传感器自检')] },
        { name: 'activity', attrs: [A('name', 'string', '.AudioLoopActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 频响失真')] },
        { name: 'activity', attrs: [A('name', 'string', '.UpdateActivity'), A('exported', 'bool', false), A('label', 'string', 'CPU HUD 更新与安装')] },
        { name: 'receiver', attrs: [A('name', 'string', '.InstallReceiver'), A('exported', 'bool', false)] },
        { name: 'service', attrs: [A('name', 'string', '.HudService'), A('exported', 'bool', false)] },
        {
          name: 'provider',
          attrs: [
            A('name', 'string', 'com.dsh.cpuhud.HudShizukuProvider'),
            A('authorities', 'string', 'com.dsh.cpuhud.shizuku'),
            A('permission', 'string', 'android.permission.INTERACT_ACROSS_USERS_FULL'),
            A('enabled', 'bool', true),
            A('exported', 'bool', true),
            A('multiprocess', 'bool', false),
          ],
        },
        { name: 'meta-data', attrs: [A('name', 'string', 'moe.shizuku.client.V3_SUPPORT'), A('value', 'string', 'true')] },
      ],
    },
  ],
};
