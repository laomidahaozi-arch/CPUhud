package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * 远端映射表：型号代码 → 市场名。
 *
 * 内置表写死在 ChipArt.friendly() 里，新芯片得等 App 更新。
 * 这里再从用户指定的地址拉一份 JSON 覆盖，做到「加一行数据就支持新芯片」。
 *
 * 只读不写：GET 一个静态 JSON，不上传任何东西。
 * 拉不到 / 格式不对 / 没网，一律静默退回内置表。
 */
public final class SocMap {

    private static final String PREF = "socmap";
    private static final long TTL_MS = 24L * 3600 * 1000;

    private static Map<String, String> cache;      // 已解析的远端表
    private static String cacheJson;               // 解析这份表的原始 JSON，避免重复解析

    private SocMap() { }

    public static String url(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("url", "");
    }

    public static void setUrl(Context c, String u) {
        String v = u == null ? "" : u.trim();
        SharedPreferences.Editor e = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("url", v);
        if (v.isEmpty()) e.remove("json").remove("ts");     // 清空地址 = 回到内置表
        e.apply();
        synchronized (SocMap.class) { cache = null; cacheJson = null; }
    }

    /** 远端表里的人话名称；没有就返回空串（调用方回落到内置表）。 */
    public static String lookup(String code) {
        if (code == null || code.isEmpty()) return "";
        ensureCache();
        if (cache == null || cache.isEmpty()) return "";
        String v = cache.get(code.trim().toUpperCase(Locale.US));
        return v == null ? "" : v;
    }

    private static synchronized void ensureCache() {
        if (cache != null) return;
        cache = new HashMap<>();
        Context c = DataSource.appContext();
        if (c == null) return;
        String j = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("json", "");
        if (j.isEmpty()) return;
        Map<String, String> m = parse(j);
        cacheJson = j;
        cache = m;
    }

    /** 解析 {"entries": {"SM8650": {"market": "骁龙 8 Gen3"}}}，也接受扁平的 {"SM8650": "骁龙 8 Gen3"}。 */
    private static Map<String, String> parse(String json) {
        Map<String, String> out = new HashMap<>();
        try {
            JSONObject root = new JSONObject(json);
            JSONObject ent = root.optJSONObject("entries");
            if (ent == null) ent = root;
            Iterator<String> it = ent.keys();
            while (it.hasNext()) {
                String k = it.next();
                Object v = ent.opt(k);
                String market = "";
                if (v instanceof JSONObject) market = ((JSONObject) v).optString("market", "");
                else if (v instanceof String) market = (String) v;
                if (!market.isEmpty()) out.put(k.trim().toUpperCase(Locale.US), market);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private static int currentSize(Context c) {
        ensureCache();
        return cache == null ? 0 : cache.size();
    }

    private static int jsonVersion(String j) {
        try { return new JSONObject(j).optInt("version", 0); } catch (Throwable t) { return 0; }
    }

    /** 从已配置的地址里反推 owner/repo，用于「提交新机型」跳 GitHub Issue。 */
    public static String repoSlug(Context c) {
        for (String u : urls(c)) {
            try {
                java.util.regex.Matcher m = java.util.regex.Pattern
                        .compile("jsdelivr\\.net/gh/([^/]+)/([^@/]+)").matcher(u);
                if (m.find()) return m.group(1) + "/" + m.group(2);
                m = java.util.regex.Pattern
                        .compile("githubusercontent\\.com/([^/]+)/([^/]+)/").matcher(u);
                if (m.find()) return m.group(1) + "/" + m.group(2);
            } catch (Throwable ignored) { }
        }
        return "";
    }

    private static String host(String u) {
        try { return new URL(u).getHost(); } catch (Throwable t) { return "?"; }
    }

    /** 当前表的状态描述，给界面用。 */
    public static String status(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String j = sp.getString("json", "");
        if (j.isEmpty()) return url(c).isEmpty() ? "内置" : "内置（尚未同步）";
        String ver = "";
        try {
            JSONObject o = new JSONObject(j);
            ver = o.optString("version", "");
        } catch (Throwable ignored) { }
        ensureCache();
        int n = cache == null ? 0 : cache.size();
        long ts = sp.getLong("ts", 0);
        String when = ts == 0 ? "" : new java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US)
                .format(new java.util.Date(ts));
        return "远端" + (ver.isEmpty() ? "" : " v" + ver) + " · " + n + " 条"
                + (when.isEmpty() ? "" : " · " + when);
    }

    /** 超过 24 小时就静默同步一次（后台线程调用）。 */
    public static void refreshIfStale(Context c) {
        String u = url(c);
        if (u.isEmpty()) return;
        long ts = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("ts", 0);
        if (System.currentTimeMillis() - ts < TTL_MS) return;
        fetch(c);
    }

    /**
     * 多个地址按顺序试（每行一个）。国内 raw.githubusercontent.com 常年被重置，
     * 所以推荐配一条 jsDelivr 镜像兜底。
     */
    private static String[] urls(Context c) {
        String raw = url(c).trim();
        if (raw.isEmpty()) return new String[0];
        String[] parts = raw.split("[\\s,]+");
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String p : parts) if (!p.isEmpty()) out.add(p);
        return out.toArray(new String[0]);
    }

    /** 真正去拉一次（阻塞）。返回结果描述，给 Toast 用。 */
    public static String fetch(Context c) { return fetch(c, false); }

    /**
     * @param bust true = 手动同步，给 URL 加时间戳参数，绕过 jsDelivr 的分支缓存。
     */
    public static String fetch(Context c, boolean bust) {
        String[] us = urls(c);
        if (us.length == 0) return "未设置映射表地址";
        StringBuilder err = new StringBuilder();
        for (String u : us) {
            String real = bust ? bustUrl(u) : u;
            String r = fetchOne(c, real);
            if (r.startsWith("已更新")) return r;
            if (err.length() > 0) err.append(" / ");
            err.append(r);
        }
        return "同步失败: " + err;
    }

    /** jsDelivr / raw 都会忽略查询串，但 CDN 的缓存键会变，等于强制回源。 */
    private static String bustUrl(String u) {
        return u + (u.contains("?") ? "&" : "?") + "t=" + (System.currentTimeMillis() / 60000);
    }

    private static String fetchOne(Context c, String u) {
        HttpURLConnection conn = null;
        try {
            android.util.Log.i("CPUHUD", "socmap fetch " + u);
            conn = (HttpURLConnection) new URL(u).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(8000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "CPUHUD");
            int code = conn.getResponseCode();
            if (code != 200) return "HTTP " + code + " (" + host(u) + ")";
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > 512 * 1024) break;
            }
            in.close();
            String j = bo.toString("UTF-8");
            Map<String, String> m = parse(j);
            if (m.isEmpty()) return "内容不是有效的映射表";

            // 防误伤：新表比旧表少一半以上时，只有版本号确实更大才接受
            int prev = currentSize(c);
            int newVer = jsonVersion(j);
            int oldVer = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("ver", 0);
            if (prev >= 10 && m.size() < prev / 2 && newVer <= oldVer) {
                return "远端只剩 " + m.size() + " 条（本地 " + prev + " 条），已拒绝覆盖";
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString("json", j).putLong("ts", System.currentTimeMillis())
                    .putInt("ver", newVer).apply();
            synchronized (SocMap.class) { cache = m; cacheJson = j; }
            return "已更新 " + m.size() + " 条";
        } catch (Throwable t) {
            return t.getClass().getSimpleName() + " (" + host(u) + ")";
        } finally {
            if (conn != null) try { conn.disconnect(); } catch (Throwable ignored) { }
        }
    }
}
