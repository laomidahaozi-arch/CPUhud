package com.dsh.cpuhud;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

/** 屏幕自检：纯色 → 灰阶 → 渐变 → 色块，点一下换一张，返回结束。 */
public class ScreenTestActivity extends Activity {

    private static final int[] SOLID = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF,
            0xFFFFFFFF, 0xFF000000, 0xFF808080};
    private static final String[] NAMES = {"红", "绿", "蓝", "白", "黑", "50% 灰"};

    private TestView view;
    private int step = 0;      // 0..5 纯色, 6 灰阶, 7 渐变, 8 色块
    private static final int TOTAL = 9;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new TestView();
        setContentView(view);
        hideSystemUi();
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::finishWithResult);
        }
    }

    @Override public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) hideSystemUi();
    }

    private void hideSystemUi() {
        try {
            Window win = getWindow();
            win.setStatusBarColor(0x00000000);
            win.setNavigationBarColor(0x00000000);
            // 让画面铺到摄像头挖孔后面：否则顶部会被留成黑边
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = win.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                win.setAttributes(lp);
            }
            View decor = win.getDecorView();
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                win.setDecorFitsSystemWindows(false);
                android.view.WindowInsetsController c = win.getInsetsController();
                if (c != null) {
                    c.hide(android.view.WindowInsets.Type.statusBars()
                            | android.view.WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                decor.setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        } catch (Throwable ignored) { }
    }

    private void finishWithResult() {
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle("屏幕自检")
                .setMessage("刚才那几张画面看下来：\n· 有坏点（常亮的点）、亮点、暗点？\n· 黑色画面有没有发灰漏光？\n· 灰阶/渐变有没有明显色带或偏色？")
                .setPositiveButton("都正常", (d, w) -> save("screen", "pass", "无坏点 / 无漏光 / 无色带"))
                .setNeutralButton("有异常", (d, w) -> save("screen", "fail", "发现坏点或色带，建议截图留证"))
                .setNegativeButton("稍后再测", (d, w) -> finish())
                .setOnCancelListener(d -> finish())
                .create();
        dlg.setOnShowListener(d -> {
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(Theme.card2());
            bg.setCornerRadius(getResources().getDisplayMetrics().density * 20);
            if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(bg);
            int id = getResources().getIdentifier("alertTitle", "id", "android");
            View v = dlg.findViewById(id);
            if (v instanceof android.widget.TextView) ((android.widget.TextView) v).setTextColor(Theme.strong());
            View mv = dlg.findViewById(android.R.id.message);
            if (mv instanceof android.widget.TextView) ((android.widget.TextView) mv).setTextColor(Theme.text());
        });
        dlg.show();
    }

    private void save(String key, String value, String note) {
        SharedPreferences p = getSharedPreferences("selftest", MODE_PRIVATE);
        p.edit().putString(key, value).putString(key + "_note", note)
                .putLong(key + "_ts", System.currentTimeMillis()).apply();
        Toast.makeText(this, "已记录：" + (("pass".equals(value)) ? "正常" : "有异常"), Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override public void onBackPressed() {
        finishWithResult();
    }

    private class TestView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean showHint = true;
        private final Runnable hideHint = new Runnable() {
            @Override public void run() {
                showHint = false;
                invalidate();
            }
        };

        TestView() {
            super(ScreenTestActivity.this);
            postDelayed(hideHint, 3200);      // 先展示 3 秒，之后自动消失，不挡画面
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(Color.BLACK);
            if (step < 6) {
                c.drawColor(SOLID[step]);
                hint(c, "点一下：下一张（" + (step + 1) + "/" + TOTAL + "）   " + NAMES[step]);
            } else if (step == 6) {
                // 灰阶：16 级
                for (int i = 0; i < 16; i++) {
                    p.setColor(Color.rgb(i * 17, i * 17, i * 17));
                    c.drawRect(i * w / 16f, 0, (i + 1) * w / 16f, h, p);
                }
                hint(c, "灰阶 16 级：相邻两格应该都看得出差别");
            } else if (step == 7) {
                android.graphics.LinearGradient lg = new android.graphics.LinearGradient(
                        0, 0, w, 0, Color.BLACK, Color.WHITE, android.graphics.Shader.TileMode.CLAMP);
                p.setShader(lg);
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                hint(c, "黑→白渐变：不该看到竖条纹/色带");
            } else {
                String[] cols = {"#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF",
                        "#00FFFF", "#FF8000", "#8000FF", "#00FF80", "#808080", "#FFFFFF", "#000000"};
                int cell = w / 3;
                for (int i = 0; i < 12; i++) {
                    p.setColor(Color.parseColor(cols[i]));
                    int cx = (i % 3) * cell, cy = (i / 3) * (h / 4);
                    c.drawRect(cx, cy, cx + cell, cy + h / 4f, p);
                }
                hint(c, "色块：每块颜色应该纯粹，不偏");
            }
        }

        private void hint(Canvas c, String s) {
            if (!showHint) {
                // 收起后只留一条极淡的小字，几乎不挡画面
                p.setColor(0x55FFFFFF);
                p.setTextSize(26);
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText((step + 1) + "/" + TOTAL + "  点一下换图 · 返回键结束",
                        getWidth() / 2f, getHeight() - 28, p);
                return;
            }
            p.setColor(0x99000000);
            p.setStyle(Paint.Style.FILL);
            float y = getHeight() - 110;
            c.drawRect(0, y - 62, getWidth(), y + 58, p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(32);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(s, getWidth() / 2f, y + 8, p);
            p.setColor(0x99FFFFFF);
            p.setTextSize(24);
            c.drawText("返回键结束自检 · 提示 3 秒后自动收起", getWidth() / 2f, y + 42, p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) {
                step++;
                if (step >= TOTAL) step = TOTAL - 1;
                showHint = true;
                removeCallbacks(hideHint);
                postDelayed(hideHint, 1800);
                invalidate();
            }
            return true;
        }
    }
}
