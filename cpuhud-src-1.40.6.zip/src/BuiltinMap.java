package com.dsh.cpuhud;

import android.content.Context;
import android.content.res.AssetManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * 内置芯片表（assets/soc_builtin.json，约 1000 条）。
 *
 * 数据整理自开源项目 YAWAsau/backup_script 的 tools/soc.json（GPL-3.0），
 * 已做中文名归一（Snapdragon→骁龙、Dimensity→天玑、Gen 5→Gen5）并人工校正关键型号。
 * 只用「型号代码 → 市场名 / 厂商」这一层事实，供识别与选图使用。
 */
public final class BuiltinMap {

    private static Map<String, String> names;
    private static Map<String, String> vendors;

    private BuiltinMap() { }

    private static synchronized void load(Context c) {
        if (names != null) return;
        names = new HashMap<>();
        vendors = new HashMap<>();
        if (c == null) return;
        try {
            AssetManager am = c.getAssets();
            InputStream in = am.open("soc_builtin.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            JSONObject root = new JSONObject(bo.toString("UTF-8"));
            JSONObject ent = root.optJSONObject("entries");
            if (ent == null) return;
            Iterator<String> it = ent.keys();
            while (it.hasNext()) {
                String key = it.next();
                JSONArray arr = ent.optJSONArray(key);
                if (arr == null) continue;
                String name = arr.optString(0, "");
                String ven = arr.optString(1, "");
                String k = key.trim().toUpperCase(Locale.US);
                if (!name.isEmpty()) names.put(k, name);
                if (!ven.isEmpty()) vendors.put(k, ven);
            }
            android.util.Log.i("CPUHUD", "builtin soc table: " + names.size() + " entries");
        } catch (Throwable t) {
            android.util.Log.i("CPUHUD", "builtin soc table load failed: " + t);
        }
    }

    /** 型号代码 → 市场名；找不到返回空串。 */
    public static String name(Context c, String code) {
        String k = findKey(c, code);
        return k == null ? "" : names.get(k);
    }

    /** 型号代码 → 芯片厂商（Qualcomm / MediaTek / …）；找不到返回空串。 */
    public static String vendor(Context c, String code) {
        String k = findKey(c, code);
        return k == null ? "" : vendors.get(k);
    }

    /**
     * 逐级放宽匹配：精确 → 去掉 -AC 之类的后缀 → 去掉 /CZA 之类 →
     * 去掉尾部字母（MT6985W → MT6985）。任一级命中即返回。
     */
    private static String findKey(Context c, String code) {
        load(c);
        if (code == null) return null;
        String s = code.trim().toUpperCase(Locale.US);
        if (s.isEmpty()) return null;
        if (names.containsKey(s)) return s;

        int i = s.indexOf('-');
        while (i > 0) {
            s = s.substring(0, i);
            if (names.containsKey(s)) return s;
            i = s.indexOf('-');
        }
        s = code.trim().toUpperCase(Locale.US);
        i = s.indexOf('/');
        while (i > 0) {
            s = s.substring(0, i);
            if (names.containsKey(s)) return s;
            i = s.indexOf('/');
        }
        s = code.trim().toUpperCase(Locale.US);
        while (s.length() > 3 && Character.isLetter(s.charAt(s.length() - 1))) {
            s = s.substring(0, s.length() - 1);
            if (names.containsKey(s)) return s;
        }
        return null;
    }

    public static int size(Context c) {
        load(c);
        return names == null ? 0 : names.size();
    }
}
