package com.dsh.cpuhud;

import android.content.pm.PackageManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

/** 用 Shizuku 借 shell 身份跑命令（等价 adb shell），不再依赖容器里的 Node 服务。 */
public final class ShizukuShell {
    public static final int REQ_CODE = 4096;
    private static String lastError = "";

    private ShizukuShell() { }

    public static String err() { return lastError; }

    public static boolean ping() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { lastError = t.toString(); return false; }
    }

    /** PackageManager.PERMISSION_GRANTED / DENIED，-1 = Shizuku 没连上。 */
    public static int perm() {
        try {
            if (!Shizuku.pingBinder()) return -1;
            return Shizuku.checkSelfPermission();
        } catch (Throwable t) { lastError = t.toString(); return -1; }
    }

    public static boolean granted() { return perm() == PackageManager.PERMISSION_GRANTED; }

    public static void request() {
        try { Shizuku.requestPermission(REQ_CODE); } catch (Throwable t) { lastError = t.toString(); }
    }

    /** 跑一条命令，返回 stdout；不可用/出错返回 null。 */
    public static String exec(String cmd, long timeoutMs) {
        if (!granted()) { lastError = "no permission"; return null; }
        ShizukuRemoteProcess p = null;
        try {
            p = Shizuku.newProcess(new String[]{"/system/bin/sh", "-c", cmd}, null, null);
            InputStream in = p.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16384];
            long deadline = System.currentTimeMillis() + timeoutMs;
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (System.currentTimeMillis() > deadline) break;
            }
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            lastError = t.toString();
            return null;
        } finally {
            if (p != null) {
                try { p.destroy(); } catch (Throwable ignored) { }
            }
        }
    }
}
