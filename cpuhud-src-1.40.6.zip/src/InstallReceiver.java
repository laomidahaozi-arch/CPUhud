package com.dsh.cpuhud;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

/** 接收 PackageInstaller 的安装结果（成功 / 取消 / 失败原因）。 */
public class InstallReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -100);
        String msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        String text;
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            // 需要用户确认：把系统安装界面拉起来
            Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { c.startActivity(confirm); } catch (Throwable t) {
                    Toast.makeText(c, "无法打开安装界面：" + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            return;
        } else if (status == PackageInstaller.STATUS_SUCCESS) {
            text = "安装成功";
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            text = "已取消安装";
        } else if (status == PackageInstaller.STATUS_FAILURE_INCOMPATIBLE) {
            text = "安装失败：与已装版本不兼容（签名不同？）";
        } else {
            text = "安装失败（" + status + "）" + (msg == null ? "" : "：" + msg);
        }
        Toast.makeText(c, text, Toast.LENGTH_LONG).show();
    }
}
