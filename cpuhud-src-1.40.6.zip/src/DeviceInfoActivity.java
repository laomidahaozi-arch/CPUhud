package com.dsh.cpuhud;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 设备信息：12 个分区 + 实测/标称对照，能联网补全的项都给了「查 ↗」。 */
public class DeviceInfoActivity extends Activity {

    private int themeSig;
    private LinearLayout body;
    private volatile boolean loading = false;
    private DeviceInfo.Result last;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);   // 去掉系统 ActionBar（我们自己画标题）
        Theme.load(this);
        themeSig = Theme.sig();

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(Theme.bg());
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(24), dp(18), dp(28));

        body.addView(text("设备信息", 24f, Theme.strong(), true, false));
        body.addView(text("能读到的都读，读不到的标 n/a —— 不猜。带「查 ↗」的分区可以直接联网搜这台机器的参数。",
                11f, Theme.dim2(), false, false));

        sc.addView(body);
        setContentView(sc);
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.sig() != themeSig) { themeSig = Theme.sig(); recreate(); }
    }

    private void load() {
        if (loading) return;
        loading = true;
        final Button refresh = findRefresh();
        body.post(new Runnable() {
            @Override public void run() { if (refresh != null) refresh.setEnabled(false); }
        });
        new Thread(new Runnable() {
            @Override public void run() {
                DeviceInfo.Result res = null;
                try {
                    SpecMap.refreshIfStale(DeviceInfoActivity.this);
                    res = DeviceInfo.collect(DeviceInfoActivity.this);
                } catch (Throwable t) {
                    final String msg = String.valueOf(t.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            loading = false;
                            if (refresh != null) refresh.setEnabled(true);
                            Toast.makeText(DeviceInfoActivity.this, "读取失败：" + msg, Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                final DeviceInfo.Result r = res;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        render(r);
                        if (refresh != null) refresh.setEnabled(true);
                    }
                });
            }
        }).start();
    }

    private Button findRefresh() {
        int n = body.getChildCount();
        for (int i = n - 1; i >= 0; i--) {
            View v = body.getChildAt(i);
            if (v instanceof Button && "refreshBtn".equals(v.getTag())) return (Button) v;
        }
        return null;
    }

    private void render(DeviceInfo.Result r) {
        // 只清掉上次渲染的内容（保留标题两行）
        while (body.getChildCount() > 2) body.removeViewAt(body.getChildCount() - 1);

        boolean shellOk = Shell.hasRoot() || ShizukuShell.granted();
        TextView sub = text((r.market.isEmpty() ? r.model : r.market + " · " + r.model)
                + "   ·   " + r.specStatus
                + (shellOk ? "" : "   ·   仅系统 API"), 11.5f,
                shellOk ? Theme.dim() : Theme.warn(), true, false);
        sub.setPadding(0, dp(6), 0, dp(2));
        body.addView(sub);

        if (!shellOk) {
            Button grant = wideBtn("未授权 Shizuku —— 点这里授权（能多读一堆数据）", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ShizukuShell.request();
                    Toast.makeText(DeviceInfoActivity.this,
                            "已发起授权，去 Shizuku 弹窗点允许；授权后回到本页点「重新读取」",
                            Toast.LENGTH_LONG).show();
                }
            });
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
            gp.topMargin = dp(8);
            body.addView(grant, gp);
        }

        last = r;
        body.addView(socVerifyRow(r));
        if (!r.compare.isEmpty()) body.addView(compareCard(r));

        for (DeviceInfo.Section sec : r.sections) {
            body.addView(sectionCard(sec, r));
        }

        body.addView(text("· 标称参数来自内置库 / 远端库，来源见每款机型的 sources 字段\n"
                + "· 标不出来表示系统没开放这个节点，不代表硬件没有\n"
                + "· 想补机型：把 device_builtin.json 里加一行，或配远端地址（和芯片映射表同一套机制）",
                10.5f, Theme.dim2(), false, false));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = wideBtn("重新读取", new View.OnClickListener() {
            @Override public void onClick(View v) { load(); }
        });
        refresh.setTag("refreshBtn");
        Button test = wideBtn("设备自检", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DeviceInfoActivity.this, SelfTestActivity.class));
            }
        });
        Button back = wideBtn("返回", new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        row.addView(refresh);
        row.addView(test);
        row.addView(back);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = wideBtn("复制诊断到剪贴板", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Toast.makeText(DeviceInfoActivity.this, "正在生成诊断（约 10 秒）…", Toast.LENGTH_SHORT).show();
                new Thread(new Runnable() {
                    @Override public void run() {
                        final int len;
                        try {
                            len = DiagExport.copyToClipboard(DeviceInfoActivity.this, "");
                        } catch (final Throwable t) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    Toast.makeText(DeviceInfoActivity.this, "失败：" + t.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                            return;
                        }
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                Toast.makeText(DeviceInfoActivity.this,
                                        "已复制 " + len + " 字符，直接粘贴发出去即可", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }).start();
            }
        });
        row2.addView(copy);
        LinearLayout.LayoutParams rp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp2.topMargin = dp(8);
        body.addView(row2, rp2);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(18);
        body.addView(row, rp);
    }

    /** 「交叉验证」：自动比对型号码 / GPU / 主频 / 网页结果，直接给结论，不让用户选。 */
    private View socVerifyRow(final DeviceInfo.Result r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final SocProbe.Info soc = SocProbe.get(this, false);
        SocVerify.Verdict v = SocVerify.cached(this, soc.raw);
        boolean fresh = v != null && System.currentTimeMillis() - v.ts < 24L * 3600 * 1000;
        String label = v == null ? "交叉验证芯片（型号码 + GPU + 主频 + 网页）"
                : ("结论：" + v.name + "（" + v.confidence + "）· 重新验证");
        Button b = wideBtn(label, new View.OnClickListener() {
            @Override public void onClick(View v2) { runVerify(r, true); }
        });
        row.addView(b);
        if (v != null) {
            Button clear = wideBtn("清空", new View.OnClickListener() {
                @Override public void onClick(View v2) {
                    SocVerify.clear(DeviceInfoActivity.this);
                    SocProbe.clear(DeviceInfoActivity.this);
                    recreate();
                }
            });
            row.addView(clear);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        row.setLayoutParams(lp);
        if (!fresh && !verifying) {          // 没有新鲜结论就自动在后台验一遍
            body.postDelayed(new Runnable() {
                @Override public void run() { runVerify(r, true); }
            }, 1200);
        }
        return row;
    }

    private volatile boolean verifying = false;

    private void runVerify(final DeviceInfo.Result r, final boolean network) {
        if (verifying) return;
        verifying = true;
        Toast.makeText(this, network ? "正在交叉验证（约 5~15 秒）…" : "正在验证…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                final SocVerify.Verdict v;
                try {
                    SocProbe.Info soc = SocProbe.get(DeviceInfoActivity.this, false);
                    v = SocVerify.verify(DeviceInfoActivity.this, soc, r.market, network);
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            verifying = false;
                            Toast.makeText(DeviceInfoActivity.this, "验证失败：" + t.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        verifying = false;
                        SocProbe.get(DeviceInfoActivity.this, true);   // 让识别结果跟着新结论刷新
                        Toast.makeText(DeviceInfoActivity.this,
                                "验证完成：" + v.name + "（" + v.confidence + "）", Toast.LENGTH_LONG).show();
                        load();
                    }
                });
            }
        }).start();
    }

    /** 实测 vs 标称。 */
    private View compareCard(DeviceInfo.Result r) {
        LinearLayout card = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("实测 vs 标称", 14f, Theme.good(), true, false);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView go = text("在线查这台机器 ↗", 11f, Theme.accent(), false, false);
        go.setPadding(dp(8), 0, 0, 0);
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(r.searchUrl); }
        });
        head.addView(go);
        card.addView(head);

        for (String[] row : r.compare) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(0, dp(4), 0, dp(4));
            TextView k = text(row[0], 11.5f, Theme.dim2(), false, false);
            k.setWidth(dp(84));
            line.addView(k);
            TextView v = text("实测 " + row[1] + "    标称 " + row[2], 11.5f, Theme.text(), true, false);
            line.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            TextView st = text(row[3], 12f,
                    "✔".equals(row[3]) ? Theme.good() : "⚠".equals(row[3]) ? Theme.warn() : Theme.dim(), false, false);
            line.addView(st);
            card.addView(line);
        }
        return card;
    }

    private View sectionCard(final DeviceInfo.Section sec, final DeviceInfo.Result r) {
        LinearLayout card = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(sec.title, 14f, Theme.good(), true, false);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView go = text("查 ↗", 11.5f, Theme.accent(), false, false);
        go.setPadding(dp(8), 0, 0, 0);
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(DeviceInfo.searchUrl(sec.query)); }
        });
        head.addView(go);
        card.addView(head);

        for (String[] row : sec.rows) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setPadding(0, dp(3), 0, dp(3));
            TextView k = text(row[0], 11.5f, Theme.dim2(), false, false);
            k.setWidth(dp(96));
            line.addView(k);
            TextView v = text(row[1], 12f, Theme.text(), true, false);
            line.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            card.addView(line);
        }
        return card;
    }

    private void open(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "没有可用浏览器", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card2());
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Theme.card());
        c.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        c.setLayoutParams(p);
        return c;
    }

    private Button wideBtn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTextColor(Theme.text());
        b.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card());
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Theme.dim2());
        b.setBackground(bg);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String s, float sp, int color, boolean mono, boolean underline) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (mono) v.setTypeface(Typeface.MONOSPACE);
        v.setPadding(0, dp(2), 0, dp(2));
        return v;
    }
}
