package com.dsh.cpuhud;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** 从容器里的采集服务拉一帧数据。 */
public class MetricsClient {
    public static final String BASE = "http://127.0.0.1:8790";

    /** 维护游戏名单（服务端 games.json）。 */
    public static void gameCmd(String op, String pkg) throws Exception {
        String url = BASE + "/games?op=" + op + "&pkg=" + java.net.URLEncoder.encode(pkg, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(1500);
        c.setReadTimeout(1500);
        try { c.getResponseCode(); } finally { c.disconnect(); }
    }

    public static Snapshot fetch() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/metrics").openConnection();
        c.setConnectTimeout(1500);
        c.setReadTimeout(1500);
        c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(2048);
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return Snapshot.parse(bo.toString("UTF-8"));
        } finally {
            c.disconnect();
        }
    }
}
