package com.dsh.cpuhud;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * 机型标称参数库。
 *
 * <p>两级来源：内置 {@code assets/device_builtin.json}（随包发布）+ 可选远端 JSON（同一个仓库，加机型不用发版）。
 * 只读不写，不发任何设备信息；拉不到 / 格式不对一律静默退回内置表。
 */
public final class SpecMap {

    private static final String PREF = "specmap";
    private static final long TTL_MS = 24L * 3600 * 1000;

    private static JSONObject builtin;
    private static JSONObject remote;

    private SpecMap() { }

    // ------------------------------------------------------------------ 偏好

    public static String url(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("url", "");
    }

    public static void setUrl(Context c, String u) {
        String v = u == null ? "" : u.trim();
        SharedPreferences.Editor e = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("url", v);
        if (v.isEmpty()) e.remove("json").remove("ts");
        e.apply();
        synchronized (SpecMap.class) { remote = null; }
    }

    public static String status(Context c) {
        ensureRemote(c);
        int n = count(remote);
        if (n > 0) return "远端库 " + n + " 条";
        int b = count(builtin(c));
        return b > 0 ? "内置库 " + b + " 条" : "未收录";
    }

    // ------------------------------------------------------------------ 查询

    /** 机型码（PMB110）→ 标称参数；没有返回 null。 */
    public static JSONObject entry(Context c, String code) {
        if (code == null || code.trim().isEmpty()) return null;
        String key = code.trim().toUpperCase(Locale.US);
        ensureRemote(c);
        JSONObject r = sub(remote, "entries", key);
        if (r != null) return r;
        return sub(builtin(c), "entries", key);
    }

    /** SoC 码（MT6993 / MT6993W/CZA）→ 工艺/架构等。精确查不到就退回基础码。 */
    public static JSONObject soc(Context c, String code) {
        if (code == null || code.trim().isEmpty()) return null;
        ensureRemote(c);
        for (String key : variants(code)) {
            JSONObject r = sub(remote, "socs", key);
            if (r != null) return r;
            r = sub(builtin(c), "socs", key);
            if (r != null) return r;
        }
        return null;
    }

    /**
     * 料号变体：MT6993W/CZA → MT6993W/CZA、MT6993W、MT6993。
     * 换用「完整料号」识别后，规格表里只有基础码，不逐级退回就查不到工艺 / 核心构成。
     */
    private static java.util.List<String> variants(String code) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        String k = code.trim().toUpperCase(Locale.US);
        out.add(k);
        java.util.List<String> bases = new java.util.ArrayList<>();
        bases.add(k);
        int slash = k.indexOf('/');
        if (slash > 0) bases.add(k.substring(0, slash));
        int us = k.indexOf('_');
        if (us > 0) bases.add(k.substring(0, us));
        for (String b0 : new java.util.ArrayList<>(bases)) {
            String b = b0;
            while (b.length() > 3) {
                char last = b.charAt(b.length() - 1);
                if (last >= 'A' && last <= 'Z') { b = b.substring(0, b.length() - 1); bases.add(b); }
                else break;
            }
        }
        for (String b : bases) if (b.length() > 2) out.add(b);
        return new java.util.ArrayList<>(out);
    }

    private static JSONObject sub(JSONObject root, String group, String key) {
        if (root == null) return null;
        JSONObject g = root.optJSONObject(group);
        return g == null ? null : g.optJSONObject(key);
    }

    private static int count(JSONObject root) {
        if (root == null) return 0;
        JSONObject e = root.optJSONObject("entries");
        return e == null ? 0 : e.length();
    }

    // ------------------------------------------------------------------ 加载

    private static synchronized JSONObject builtin(Context c) {
        if (builtin != null) return builtin;
        try {
            InputStream in = c.getAssets().open("device_builtin.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            builtin = new JSONObject(bo.toString("UTF-8"));
        } catch (Throwable t) {
            builtin = new JSONObject();
        }
        return builtin;
    }

    private static synchronized void ensureRemote(Context c) {
        if (remote != null) return;
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String j = p.getString("json", "");
        if (j.isEmpty()) { remote = new JSONObject(); return; }
        try { remote = new JSONObject(j); } catch (Throwable t) { remote = new JSONObject(); }
    }

    /** 远端超过 24 小时就静默拉一次（调用方放后台线程）。 */
    public static void refreshIfStale(Context c) {
        String u = url(c);
        if (u == null || u.trim().isEmpty()) return;
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        long ts = p.getLong("ts", 0);
        if (System.currentTimeMillis() - ts < TTL_MS) return;
        fetch(c, true);
    }

    /** 手动同步：从配置地址拉一份。成功返回拉到的条数，失败返回 -1。 */
    public static int fetch(Context c, boolean bust) {
        String urls = url(c);
        if (urls == null || urls.trim().isEmpty()) return -1;
        for (String raw : urls.trim().split("\\s+")) {
            String u = raw;
            if (u.isEmpty()) continue;
            if (bust) u = u + (u.contains("?") ? "&" : "?") + "t=" + (System.currentTimeMillis() / 60000);
            String body = get(u);
            if (body == null) continue;
            try {
                JSONObject o = new JSONObject(body);
                JSONObject ent = o.optJSONObject("entries");
                if (ent == null) continue;
                int n = ent.length();
                if (n == 0) continue;
                SharedPreferences.Editor e = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                        .putString("json", body).putLong("ts", System.currentTimeMillis());
                e.apply();
                synchronized (SpecMap.class) { remote = o; }
                return n;
            } catch (Throwable ignored) { }
        }
        return -1;
    }

    private static String get(String u) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(u).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(8000);
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) return null;
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
